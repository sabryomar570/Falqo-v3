# تقرير التدقيق الشامل لمشروع FALQO

**نوع التدقيق:** Product Audit + Functional Audit + Security Audit + UX Audit + Performance Audit + Architecture Audit  
**نطاق الأدلة:** جميع ملفات المشروع المرفقة، شيفرة الواجهة والخادم، migrations الخاصة بـ Supabase، إعدادات البناء، وسجلات `build` و`lint`.  
**تاريخ التدقيق:** 12 سبتمبر 2026  
**المراجع:** Manus AI

> **الخلاصة التنفيذية:** المشروع ليس جاهزًا للإطلاق الإنتاجي بعد. البناء ينجح، لكن `lint` يفشل، والأهم أن هناك مخاطر عالية في صلاحيات تحديث سجل التطبيق، قبول الملفات دون تحقق خادمي كافٍ، ومسار الفحص الأمني الذي قد يترك التطبيق في حالة قابلة للالتباس أو يسمح بتجاوزات تشغيلية. الواجهة متقدمة بصريًا وتحتوي على وظائف حقيقية كثيرة، لكنها ما زالت أقرب إلى MVP قوي منها إلى منصة نشر ملفات وتطبيقات production-ready.

## 1. Executive Summary

FALQO عبارة عن منصة عربية تجمع ثلاثة منتجات في نظام واحد: متجر تطبيقات، مشاركة ملفات، ومجتمع نقاش. تستخدم الواجهة React 19 وTanStack Start وTanStack Router وReact Query وTailwind/Radix. يعتمد التخزين والهوية وقاعدة البيانات على Supabase، بينما يمر تنزيل التطبيقات وملفات المشاركة عبر Server Functions تنشئ روابط موقعة وتسجل عمليات التنزيل. يوجد مسار اختياري للفحص عبر VirusTotal، ولوحة للناشر، ولوحة للمشرف، ونظام بلاغات وإشعارات وتقييمات وقائمة رغبات.

النتيجة العامة هي **MVP متكامل نسبيًا من ناحية المسارات والواجهات، لكنه غير صالح للإطلاق غير المراقب**. أهم سبب ليس وجود كود تجريبي واضح، بل وجود فجوة بين صلاحيات العميل وسياسات قاعدة البيانات وبين ما يجب أن تسمح به عملية النشر الآمنة. البناء الناجح لا يثبت أن العمليات الخارجية أو RLS أو التخزين أو الفحص الأمني تعمل فعليًا في بيئة Supabase المرتبطة.

### قرار الإطلاق

**هل المشروع جاهز للإطلاق؟ NO.**

يمكن إطلاقه في بيئة staging أو closed beta بعد تقييد الوصول، لكن لا أوصي بإطلاق عام قبل إغلاق الثغرات عالية الخطورة، إضافة التحقق الخادمي للملفات، وإثبات إعدادات Supabase والتخزين والفحص end-to-end.

### أقوى نقاط المشروع

| المجال | الملاحظة |
|---|---|
| المنتج | عرض واضح لقيمة المتجر والملفات والمجتمع، مع صفحات عربية وRTL. |
| الواجهة | تصميم متسق نسبيًا، حالات تحميل وفراغ متعددة، وتجاوب أساسي جيد. |
| البنية | فصل مقبول بين routes وcomponents وlib وintegrations. |
| الهوية | وجود Supabase Auth وطبقة `requireSupabaseAuth` لـ Server Functions الحساسة. |
| قاعدة البيانات | وجود RLS وفهارس ومفاتيح خارجية وtriggers للتقييم والإشعارات والعدادات. |
| البناء | `npm run build` نجح، وتم توليد مخرجات TanStack/Nitro وPWA. |

### أضعف نقاط المشروع

| المجال | المشكلة الأساسية |
|---|---|
| الصلاحيات | سياسة تحديث `apps` للناشر تسمح للمالك بتحديث أعمدة حساسة مثل الحالة والفحص والعدادات ما لم تُقيد الخوادم أو تُعاد صياغة السياسة. |
| الملفات | لا يوجد تحقق خادمي ظاهر من الحجم أو MIME الحقيقي أو الامتداد أو نوع الملف، والحد الأقصى 50MB موجود كنص واجهة فقط. |
| الفحص | مسار VirusTotal اختياري، وفشل إطلاق الفحص يُبتلع في الواجهة، ولا يوجد worker أو retry أو webhook ظاهر لإكمال الفحص تلقائيًا. |
| الجودة | `npm run lint` يفشل بسبب أخطاء Prettier متعددة، مع تحذيرات Fast Refresh. |
| التشغيل | لا توجد اختبارات آلية أو خطة migrations/rollback أو توثيق تشغيل production كافٍ. |
| التوسع | بعض الاستعلامات تجمع بيانات ثم ترشحها في المتصفح، وبعض القوائم محدودة ثابتًا بلا pagination حقيقي. |

## 2. Project Understanding

### التدفق الوظيفي العام

1. يفتح الزائر الصفحة الرئيسية أو التصفح أو الملفات أو المجتمع.
2. يستعلم العميل مباشرة من Supabase باستخدام المفتاح publishable، وتطبق RLS على الجداول.
3. يسجل المستخدم الدخول عبر Supabase Auth، ثم ينشئ `handle_new_user` ملف profile ودور `user`.
4. يرفع الناشر أيقونة ولقطات وملف التطبيق إلى Storage ثم ينشئ سجلًا في `apps`.
5. يستدعي العميل `submitAppScan` لطلب الفحص، ثم ينتظر قرار المشرف أو تحديث الفحص.
6. يراجع المشرف التطبيق ويغير `status` و`scan_status` من لوحة الإدارة.
7. عند التنزيل، ينشئ الخادم رابطًا موقّعًا قصير العمر ويسجل التنزيل عبر RPC ذات صلاحية service role.
8. يرفع المستخدم ملفًا عامًا أو خاصًا إلى `shared-files`، ثم ينشأ سجل `files` ورابط مشاركة.
9. يعمل المجتمع عبر `forum_categories` و`forum_topics` و`forum_replies` و`forum_topic_votes`.

### المكونات الخارجية

| المكوّن | الاستخدام | حالة التحقق |
|---|---|---|
| Supabase Auth | تسجيل الدخول والجلسات والأدوار | **Partially Verified**: الشيفرة موجودة، لكن لم تُنفذ جلسة حقيقية في البيئة المرتبطة. |
| Supabase Postgres | الجداول وRLS وRPC وtriggers | **Partially Verified**: migrations موجودة، لكن لم يُنفذ اختبار اتصال/سياسات على المشروع الخارجي. |
| Supabase Storage | `app-icons`, `app-screenshots`, `app-files`, `shared-files` | **Not Verified**: تعريف buckets الفعلي وخصائص public/private غير موجودين كاملًا في المستودع. |
| VirusTotal | فحص ملف التطبيق | **Partially Verified**: HTTP integration موجودة، لكن المفتاح، الحصص، polling، والـ production workflow غير مثبتة. |
| Lovable telemetry | الإبلاغ عن أخطاء preview | **Not Verified for production**: تعتمد على globals خاصة بالبيئة. |
| Google Fonts | Inter/Cairo من CDN | **Working by code / operationally unverified**. |

## 3. Architecture Analysis

### التقييم

البنية الحالية مناسبة لحجم MVP، ولا يوجد سبب تقني لإعادة كتابة المشروع بالكامل. أقوى قرار معماري هو وضع عمليات التنزيل والفحص التي تحتاج service role في Server Functions بدل كشف المفتاح السري للمتصفح. أضعف قرار هو السماح لطبقات العميل بالتعامل مباشرة مع جداول حساسة من دون API domain layer يفرض انتقالات الحالة والتحقق من المدخلات.

### نقاط coupling

- routes تقوم بدور العرض، وجلب البيانات، والتحقق، والتنفيذ mutation في الملف نفسه.
- قواعد العمل الخاصة بالنشر موزعة بين React route، سياسات RLS، وعمليات update مباشرة على `apps`.
- الفحص الأمني ليس نظام حالات مستقلًا؛ هو Server Function تستدعى مرة واحدة من واجهة الرفع.
- لوحة المشرف تعدّل `apps` مباشرة، ما يجعل schema mutation هو واجهة الإدارة بدل endpoint مقيد.

### إعادة التصميم المقترحة

لا تعِد كتابة المشروع. أضف طبقة domain server صغيرة تحتوي على عمليات: `createAppSubmission`, `approveApp`, `rejectApp`, `setScanVerdict`, `createSignedDownload`. اجعل كل عملية تتحقق من المدخلات وتسمح فقط بتغيير الأعمدة المسموح بها. أبقِ استعلامات القراءة العامة في Supabase/RLS حيث تكون مناسبة.

## 4. Feature Inventory

| Feature | الحالة | الملفات الأساسية | الملاحظات للوصول إلى Production Ready |
|---|---|---|---|
| الصفحة الرئيسية | Partially Working | `src/routes/index.tsx`, `src/lib/marketplace.ts` | تعتمد على اتصال Supabase، ولا تعرض كل حالات الخطأ بوضوح. |
| تصفح التطبيقات | Partially Working | `browse.tsx`, `marketplace.ts` | فلترة الفئة تتم بعد جلب الصفوف في العميل، ولا توجد pagination حقيقية. |
| صفحة التطبيق | Partially Working | `app.$slug.tsx` | صفحة حقيقية مع تقييم وتنزيل، لكن مسار التنزيل والفحص يحتاجان إثباتًا خارجيًا. |
| تسجيل الدخول | Partially Working | `auth.tsx`, `useAuth.tsx`, Supabase integrations | التدفق موجود؛ البريد/مزودو الهوية والإعدادات الفعلية غير متحقق منها. |
| حماية المسارات | Partially Working | `_authenticated.tsx`, `auth-middleware.ts` | الحماية في العميل للمسارات، وServer Function middleware لبعض العمليات؛ لا تكفي وحدها لصلاحيات البيانات. |
| رفع تطبيق | Partially Working | `publisher/upload.tsx`, `storage.ts`, `scan.functions.ts` | يرفع ملفات فعلية، لكن بلا حدود خادمية واضحة وبلا transaction/cleanup مؤكد. |
| فحص VirusTotal | Incomplete | `scan.functions.ts` | لا يوجد worker/retry/webhook ظاهر، وفشل `startScan` يُخفى من الواجهة. |
| مراجعة المشرف | Partially Working | `admin/index.tsx`, `apps` RLS | الواجهة موجودة، لكن السماح بتحديث الأعمدة الحساسة يجب تقليله. |
| تنزيل التطبيق | Partially Working | `downloads.functions.ts`, `record_download` | رابط موقّع وتسجيل RPC موجودان؛ صلاحيات التخزين والإعداد الفعلي غير متحققين. |
| التقييمات | Working by code | `app.$slug.tsx`, `reviews`, rating trigger | uniqueness وtrigger موجودان؛ اختبار المستخدم الحقيقي غير منفذ. |
| قائمة الرغبات | Working by code | `community.ts`, `wishlist.tsx`, RLS | delete مقيد بـ `app_id` فقط، لكن RLS يفترض حماية user_id؛ يستحسن تقييد الشرطين. |
| سجل التنزيلات | Working by code | `downloads.tsx`, `community.ts`, RLS | القراءة مقيدة للمستخدم/الناشر/المشرف حسب السياسات؛ يحتاج اختبار RLS. |
| مشاركة الملفات | Partially Working | `files.upload.tsx`, `files.ts`, `files.functions.ts` | الرفع والرابط موجودان؛ لا يوجد scan فعلي ظاهر للملفات العامة، ولا limit خادمي. |
| خصوصية الملف الخاص | Partially Working | `files.functions.ts`, `files` RLS, Storage policies | فحص المالك موجود في server function، لكن إعداد Storage الفعلي غير مثبت. |
| المجتمع | Working by code | `forum.ts`, community routes, migrations | CRUD وتصويت وقفل الموضوع موجودة؛ moderation/rate limit وanti-spam ناقصة. |
| البلاغات | Partially Working | `ReportAppDialog`, `admin/index.tsx`, `app_reports` | إنشاء البلاغ وحالته موجودان؛ لا توجد سياسة abuse prevention أو workflow تصعيد واضح. |
| الإشعارات | Working by code | `notifications`, trigger, route | trigger ينشئ إشعارات؛ لا يوجد دليل على realtime أو email/push. |
| PWA/offline | Partially Working | `vite.config.ts`, `pwa.ts`, `offline.tsx` | build أنشأ service worker، لكنه أعلن `precache 0 entries` وحذرًا في glob. |
| الصفحات القانونية | Incomplete | `privacy.tsx`, `terms.tsx`, `LegalPage.tsx` | صفحات موجودة، لكن يلزم تدقيق قانوني ومحتوى نهائي ومعلومات مالك/احتفاظ بالبيانات. |
| البحث | Partially Working | `search.tsx`, `browse.tsx`, home search | يحول لمسار التصفح؛ لا يوجد بحث موحد للتطبيقات والملفات مع ranking أو pagination. |

## 5. Missing Features

### Critical Missing

| ما الناقص؟ | لماذا؟ | مكان الإضافة | أثر الغياب | الأولوية |
|---|---|---|---|---|
| تحقق خادمي من انتقالات حالة التطبيق | لا يجوز أن يقرر العميل وحده أن التطبيق approved أو clean | Server domain functions وRLS | نشر ملف غير مفحوص أو تجاوز دورة المراجعة | Critical |
| سياسة واضحة لفشل/تأخر الفحص | التطبيق قد يبقى queued/scanning دون مسار إكمال تلقائي | worker/cron/webhook + `scan_jobs` | ملفات عالقة أو قرار يدوي غير موثق | Critical |
| تحقق خادمي من حجم ونوع الملفات | `accept` وواجهة النص ليست حماية | upload endpoint/Storage policy | رفع ملفات ضخمة أو غير متوقعة أو مكلفة | Critical |
| إثبات إعداد buckets الخاصة | المستودع لا يثبت public/private وقيود MIME/size الفعلية | Supabase config/migrations/runbook | تسريب أو فشل روابط التنزيل | Critical |
| اختبارات صلاحيات RLS وServer Functions | لا يوجد test suite ظاهر | `tests/` أو CI staging | لا يمكن إثبات IDOR/ownership | Critical |

### Important Missing

| ما الناقص؟ | مكان الإضافة | الأثر | الأولوية |
|---|---|---|---|
| pagination/cursor للمنتجات والملفات والمنتدى | lib queries + UI | تراجع الأداء ونقص النتائج بعد النمو | High |
| rate limiting وanti-spam للتنزيل والبلاغات والمنتدى | server edge/function | abuse وتكلفة واستنزاف | High |
| retry/idempotency لتنزيلات وفحص الملفات | server functions | عدادات مكررة وحالات متضاربة | High |
| اختبارات E2E للتسجيل والرفع والتنزيل والخروج | Playwright/Cypress أو بديل | regressions غير مرئية | High |
| مراقبة production وalerting للفشل | deployment/observability | بطء اكتشاف الأعطال | High |
| cleanup للملفات المرفوعة جزئيًا | upload workflow | orphan objects وتكلفة تخزين | High |
| توثيق نشر وتشغيل ومفاتيح البيئة | README/runbook/CI | أخطاء إعداد production | Medium |
| validation مشتركة بين الواجهة والخادم | schema package/server | اختلاف قبول البيانات | Medium |
| moderation للمجتمع وتصفية abuse | server + admin | محتوى مسيء/إزعاج | Medium |
| إدارة نسخ التطبيق والملفات | schema + publisher UI | صعوبة التحديث والتراجع | Medium |

### Nice to Have

إضافة إشعارات بريدية، سجل تدقيق إداري، تحليلات تنزيل مجهولة، معاينة نوع الملف، بحث كامل النص، مزيد من اختبارات الوصول، وتطبيق سياسة احتفاظ لنتائج VirusTotal.

## 6. Incomplete Features and Broken Behavior

### مؤكد من الشيفرة

1. **الـlint مكسور:** توجد أخطاء Prettier في `CategoryIcon.tsx`, `LegalPage.tsx`, `SiteHeader.tsx`, `WishlistButton.tsx`, `button.tsx`, `integrations/lovable/index.ts`, `auth-attacher.ts`, و`auth-middleware.ts` وغيرها. توجد أيضًا تحذيرات Fast Refresh في عدة ملفات.
2. **حد 50MB غير مفروض في نموذج مشاركة الملفات:** يظهر النص للمستخدم في `files.upload.tsx`، لكن input لا يحتوي `max size` ولا تحقق قبل الرفع أو في Server Function.
3. **رفع تطبيق بلا تحقق صريح من MIME/الحجم:** ملف التطبيق يقبل أي نوع، والأيقونة واللقطات تقبل `image/*` في المتصفح فقط، ولا يوجد تحقق خادمي ظاهر.
4. **فشل بدء الفحص يُخفى:** `startScan(...).catch(() => null)` يرسل المستخدم إلى لوحة الناشر برسالة نجاح حتى لو فشل طلب الفحص، مع أن المنتج يصف التطبيق بأنه دخل الفحص.
5. **الفلترة حسب الفئة تتم بعد جلب النتائج:** `browseAppsQuery` يجلب حتى حد النتائج ثم يرشح `categories.slug` في العميل، لذلك قد يحصل المستخدم على عدد أقل من النتائج من الحد المطلوب، مع تكلفة أكبر.
6. **Service worker يبني بدون precache:** سجل البناء يذكر `precache 0 entries` ويحذر أن glob لا يطابق ملفات في `dist`. هذا لا يثبت أن offline مكسور بالكامل، لكنه يجعل سلوك PWA غير موثوق.
7. **README عام من Lovable:** لا يشرح بنية FALQO أو متغيرات البيئة أو migrations أو VirusTotal أو النشر.

### غير متحقق ويجب عدم اعتباره عطلًا مؤكدًا

- الإعداد الفعلي لـ Supabase Storage buckets غير موجود كاملًا ضمن الملفات؛ لذلك direct access أو public/private behavior هو **Not Verified**.
- نجاح تسجيل الدخول الحقيقي، تفعيل providers، وإرسال redirect في بيئة الإنتاج هو **Not Verified**.
- التنفيذ الفعلي لسياسات RLS وRPC في مشروع Supabase المرتبط هو **Not Verified** لأن التدقيق لم يستخدم بيانات اعتماد تشغيلية أو ينفذ تغييرات خارجية.
- لا يوجد دليل كافٍ على أن `refreshAppScan` يستدعى بعد اكتمال VirusTotal؛ اعتبر ذلك **Missing/Not Verified** وليس فشلًا مؤكدًا في provider.

## 7. Unnecessary or Over-Complex Items

| العنصر | لماذا قد يكون زائدًا أو معقدًا؟ | القرار | أثر الحذف |
|---|---|---|---|
| معظم مكونات Radix UI غير المستخدمة مباشرة | قالب UI كبير يرفع سطح الصيانة؛ لا يوجد دليل أن كل component مستخدم | أبقِ المستخدم، احذف غير المستخدم بعد dependency graph حقيقي | تقليل حجم وصيانة، لكن لا تحذف عشوائيًا |
| `@hookform/resolvers` | تحليل الاستيرادات لم يجد استخدامًا في `src`، مع وجود `react-hook-form` | احذف بعد تأكيد عدم وجود استخدام مولد/مستقبلي | تقليل dependency غير المستخدمة |
| `date-fns` | لم يظهر استخدام في شيفرة `src` | احذف أو وثّق سبب بقائه | تقليل حجم بسيط |
| PWA الآن | مفيدة للمنتج، لكن الإعداد الحالي يعطي precache 0 وتحذيرًا | أبقها وأصلح الإعداد، لا تحذفها | حذفها يفقد offline/install |
| `error-capture` وcustom server wrapper | معقدان نسبيًا لمعالجة أخطاء h3 | أبقهما مؤقتًا، أضف اختبارات وقلل monkey-patching إن أمكن | الحذف قد يضعف تشخيص SSR |
| أعمدة الدفع `price_cents`, `currency`, `platform_fee_bps` | لا يظهر مسار دفع أو بيع فعلي في الواجهة | أبقها فقط إن كانت roadmap موثقة؛ وإلا افصلها في migration مستقبلية | إزالة مبكرة قد تكسر خطط monetization |
| `admin/apps.tsx` مقابل `admin/index.tsx` | يوجد مساران إداريان ظاهران في inventory ويجب التأكد من الاستخدام | لا تحذف قبل route graph؛ وحّد لوحة الإدارة إن كان أحدهما legacy | تقليل الالتباس |

## 8. Security Audit

### Critical/High findings

| ID | المشكلة | الدليل | الخطورة | الإصلاح الدفاعي |
|---|---|---|---|---|
| SEC-01 | سياسة `apps_publisher_update_own` تسمح للناشر بتحديث أي أعمدة في سجله | migration الأولى، policy update عامة | Critical | أزل UPDATE العام، واستخدم RPC/Server Function بأعمدة allowlist؛ امنع تعديل `status`, `scan_status`, `scan_report`, `downloads_count`, `publisher_id`, `published_at`, `is_featured`. |
| SEC-02 | قبول الملفات يعتمد على client-side فقط | `publisher/upload.tsx`, `files.upload.tsx` | High | فرض الحجم وMIME/extension والعدد على الخادم وStorage؛ فحص magic bytes إن كان مناسبًا؛ رفض archive bombs. |
| SEC-03 | التطبيق يعلن الأمان قبل تحقق مؤكد من حالة الفحص | `scan_status` الافتراضي `queued` + مسار يدوي admin | High | لا تسمح بـ approved إلا إذا كان scan clean بقرار موثق؛ اجعل `approved` و`clean` invariant في RPC أو trigger. |
| SEC-04 | إعداد buckets وStorage policies غير مثبت في migrations | الموجود يضيف policies على `storage.objects` فقط | High / Not Verified | أضف runbook أو IaC يثبت bucket names, public flag, file size, MIME، واختبارات تنزيل مباشر/موقّع. |
| SEC-05 | RPC تنزيل التطبيق يستقبل `_user_id` من server بعد محاولة قراءة bearer يدويًا | `downloads.functions.ts` | Medium | استخدم جلسة موثقة server-side باستمرار، وسمِّ anonymous صراحة، وسجل audit metadata؛ لا تعتمد على شكل JWT فقط. |
| SEC-06 | لا توجد rate limits ظاهرة | جميع server functions وforum mutations | High | حد لكل IP/user/app، backoff، وidempotency keys للتنزيل والفحص والبلاغ. |
| SEC-07 | رفع VirusTotal إلى مزود خارجي بلا disclosure أو سياسة retention ظاهرة | `scan.functions.ts` | Medium | وضح نقل الملفات لطرف ثالث، راجع شروط الخصوصية وحقوق النشر، واحذف/قلل نتائج provider حسب الحاجة. |
| SEC-08 | `.env` مرفق بالمشروع | `.env` يحتوي publishable key وSupabase URL | Medium | المفتاح publishable ليس service secret، لكن لا توزع env committed؛ استخدم `.env.example` وrotate أي secret إذا ظهر في history. |
| SEC-09 | `profiles_public_read` يتيح قراءة profile rows العامة | migration الأولى | Medium | قلل الأعمدة المعروضة عبر view عامة، خصوصًا إذا توسع profile لاحقًا إلى بيانات حساسة. |
| SEC-10 | عمليات المنتدى لا تظهر عليها حدود طول/معدل في schema | forum tables وroutes | Medium | zod/server validation، limits، moderation، وrate limiting. |

### فحوص لم يظهر فيها دليل مباشر

لم أجد استعمالًا ظاهرًا لـ `dangerouslySetInnerHTML` أو SQL raw interpolation أو command execution أو path traversal في `src`. هذا **لا يثبت غياب الثغرة في المنصة أو إعداد Supabase**. CORS وsecurity headers وCSRF تم التعامل مع جزء server functions منه عبر `createCsrfMiddleware`، لكن إعدادات proxy/CDN النهائية **Not Verified**.

## 9. Performance Audit

### الأولويات

1. **استعلامات بلا pagination حقيقي:** الصفحة الرئيسية تطلب عدة قوائم، والملفات والمنتدى يستخدمان limits ثابتة. أضف cursor pagination وواجهات `useInfiniteQuery` عند الحاجة.
2. **تصفية category في العميل:** انقلها إلى relation filter أو query قابل للفهرسة. أضف index مركب مناسب لحالة `status, scan_status, category_id, created_at` حسب خطة الاستعلام.
3. **N+1 منطقي في المؤلفين:** forum queries تجلب topics ثم استعلام profiles منفصل، ثم replies ثم profiles منفصل. يمكن تقليله عبر embedded relation أو batch مدمج واحد.
4. **إعادة جلب متعددة بعد mutations:** invalidation عام لـ `apps` و`downloads` قد يسبب طلبات مكررة في الصفحات الكبيرة. استخدم تحديث cache مستهدفًا.
5. **رفع الملفات في loop تسلسلي:** لقطات الشاشة ترفع واحدة بعد الأخرى. يمكن استعمال concurrency محدود مع rollback واضح، لا `Promise.all` غير المحدود.
6. **PWA غير فعالة حاليًا:** `precache 0 entries` يعني فائدة offline أقل من المتوقع. أصلح build output/glob واختبر cache invalidation.
7. **الأصول:** توجد صور فئات PNG بحجوم تقارب 70–100KB لكل ملف. ليست كارثية، لكن WebP/AVIF وresponsive sizing قد يقللان التحميل.

لا توجد قياسات فعلية لـ TTFB أو LCP أو query plans أو memory leaks في التقرير؛ هذه العناصر **Not Verified** وتحتاج staging/load test.

## 10. Database Audit

### الإيجابيات

المخطط يستخدم مفاتيح UUID، foreign keys مع cascade/set null، unique constraints للتقييمات والتصويت وقائمة الرغبات، check للـvisibility، وفهارس أولية على status/category/owner/created_at. توجد triggers لتحديث timestamps والتقييم والعدادات والإشعارات.

### المخاطر

- صلاحيات update على `apps` واسعة جدًا بالنسبة لعملية نشر آمنة.
- `downloads` يمنح INSERT لـ anon/authenticated في SQL التاريخي، بينما التسجيل المقصود يمر عبر service role RPC. يلزم تبسيط الصلاحية لمنع مسار بديل غير مرغوب.
- `record_file_download` يتحقق من `flagged` فقط، بينما الملف `queued` أو `scanning` يمكن تنزيله. يجب تحديد سياسة المنتج: هل الملفات العامة لا تحتاج scan قبل النشر؟ إذا كان الجواب لا، فاجعل شرط التنزيل `clean`.
- لا يوجد index ظاهر على `apps(publisher_id, created_at)` رغم كثرة استعلامات الناشر، ولا على بعض مسارات admin/reporting. أضف بعد قياس query plans.
- لا تظهر constraints لطول `reason`, `status`, titles/bodies، ولا enum لحالات البلاغ. استخدم enums/checks أو validation server-side.
- migrations الأخيرة تحتوي على إدخالات فئات متقاربة (`app-requests` ثم `requests`) وترحيلًا تصحيحيًا category id. هذا يزيد خطر drift بين البيئات ويستدعي migration verification على staging.
- لا يوجد دليل على seed idempotency كامل لكل البيانات المرجعية؛ بعض INSERT الأولى لا تستخدم `ON CONFLICT`.
- لا يوجد RLS test harness أو migration smoke test.

## 11. UI/UX Audit

### ما يجعل المشروع قريبًا من منتج حقيقي

التصميم العربي RTL واضح، والـheader/footer والبطاقات والأزرار متسقة إلى حد كبير. توجد skeletons في صفحات مهمة، وempty states للتنزيلات والملفات والبلاغات، وtoast للنجاح والفشل، وalt text للصور الأساسية، وresponsive classes من `sm` وما فوق. صفحات 404 والخطأ وصفحة offline موجودة.

### الفجوات

| المشكلة | السبب | التأثير | الحل |
|---|---|---|---|
| بعض أخطاء الاستعلام لا تظهر كحالة error مستقلة | كثير من الصفحات تعرض `data ?? []` أو empty state | يظن المستخدم أن القائمة فارغة بينما API فشل | مكوّن ErrorState مع retry لكل query رئيسية |
| رسالة نجاح رفع التطبيق لا تعكس فشل بدء الفحص | `catch(() => null)` | ثقة زائفة وحالة تشغيلية غير واضحة | أظهر `queued/manual` بوضوح واسمح بإعادة المحاولة |
| نموذج الرفع يفتقد معاينة وحجم وتقدم | input خام وbusy واحد | تجربة ضعيفة مع ملفات كبيرة | progress، validation، preview، cleanup |
| أزرار الإدارة لا تظهر busy لكل تطبيق | mutation مشترك | نقرات مكررة أو التباس | disable per row وoptimistic state واضح |
| labels لبعض عناصر الاختيار ليست مرتبطة دائمًا بـ id | `publisher/upload.tsx` يستخدم wrapper label، أما select فليس له id واضح | accessibility أقل | id/label صريح وkeyboard tests |
| لا يوجد تأكيد حذف للملفات | `remove` ينفذ مباشرة | حذف غير مقصود | AlertDialog مع حالة pending |
| اللغة في error page الخادمية إنجليزية | `error-page.ts` | عدم اتساق المنتج العربي | ترجمة RTL وإظهار reference id غير حساس |
| المحتوى القانوني والاتصال يبدو placeholder/عامًا | README وصفحات legal بسيطة | يقلل الثقة والامتثال | مراجعة قانونية وبيانات تواصل وسياسة احتفاظ |
| أزرار التقييم/التصويت تعتمد على تسجيل الدخول دون دائمًا feedback موحد | بعض الحماية في handler | احتكاك وتجربة غير متسقة | auth prompt مركزي وحالات disabled/error |

### Responsive/accessibility

هناك responsive classes مناسبة للهواتف، لكن لم يُنفذ اختبار بصري على أجهزة فعلية أو automated axe. لذلك tablet/desktop overflow، focus order، contrast، reduced motion، وحجم الأهداف اللمسية هي **Not Verified**.

## 12. Code Quality Audit

- TypeScript strict مفعّل، وهو قرار جيد.
- build ينجح، ما يدل على قابلية ترجمة/تجميع جيدة.
- lint يفشل، ويجب اعتباره quality gate مكسورًا.
- توجد ملفات مولدة وتعليقات “do not edit” ضمن integrations؛ يجب توثيق مصدر توليدها حتى لا تضيع إصلاحات الأمن في regeneration.
- بعض الدوال تعيد `[]` عند عدم وجود user بدل رفع حالة auth، وهذا مناسب للقراءة العامة أحيانًا لكنه قد يخفي أخطاء جلسة.
- `console.error` وmonkey-patching في `error-capture` مفيدان تشخيصيًا لكن يحتاجان اختبارًا ولا ينبغي تسريب تفاصيل حساسة إلى logs عامة.
- لا توجد unit/integration/E2E tests ظاهرة في manifest أو الملفات.
- لا توجد CI configuration أو dependency update policy أو lockfile verification موثقة.

## 13. Dependency Audit

| التصنيف | النتيجة |
|---|---|
| Dependencies مستخدمة بوضوح | React, TanStack, Supabase, Radix components, zod, sonner, lucide، وغيرها. |
| Dependencies تبدو غير مستخدمة من `src` | `@hookform/resolvers`, `date-fns`، مع احتمال وجود dependencies قالبية أخرى. يجب التأكيد قبل الحذف. |
| Dependencies قالبية/غير مباشرة | `@tailwindcss/vite`, `tailwindcss`, `vite-tsconfig-paths`, `@tanstack/router-plugin` قد تدخل عبر config package؛ لا تحذف قبل تحليل lockfile/build. |
| مخاطر التحديث | `nitro` beta ونسخ مستقبلية/حديثة من Vite وTanStack تستدعي تثبيت versions واختبارات regression. |
| فحص CVE | **Not Verified**: لم يُشغل audit أمني لمستودع npm في هذه المراجعة. نفذ `npm audit --omit=dev` وSCA في CI، مع مراجعة false positives. |

## 14. End-to-End UX Audit

| السيناريو | النتيجة |
|---|---|
| فتح الموقع | يعمل من ناحية build/route؛ اتصال البيانات **Not Verified**. |
| تسجيل مستخدم | الشيفرة والمسارات موجودة؛ provider/email config **Not Verified**. |
| تسجيل الدخول | session storage وAuthProvider موجودان؛ اختبار حقيقي **Not Verified**. |
| الوصول لمسار محمي | client redirect موجود، لكن لا يجب اعتباره authorization server-side. |
| رفع تطبيق | upload + insert + scan request موجود؛ validation/rollback/final scan incomplete. |
| تنزيل تطبيق | server function + signed URL موجود؛ storage policy/RPC deployment **Not Verified**. |
| إدخال بيانات ناقصة | بعض zod validation للناشر، لكن مشاركة الملفات والمنتدى تحتاج validation أقوى. |
| انقطاع الشبكة | بعض toasts موجودة، لكن error states/retry غير موحدة. |
| خطأ API | root error boundary موجود؛ query-level error UI غير مكتمل. |
| تحديث الصفحة | routing وReact Query موجودان؛ session persistence يفترض Supabase config. |
| تسجيل الخروج وإعادة الدخول | `signOut` وAuthProvider موجودان؛ E2E **Not Verified**. |

## 15. Risk Assessment

| مستوى الخطر | العناصر |
|---|---|
| Critical | تحديث سجل التطبيق عبر RLS، الفجوة بين approval وscan، غياب اختبار RLS، غياب حدود رفع خادمية. |
| High | عدم وجود retry/worker للفحص، غياب rate limiting، orphan uploads، direct Storage configuration غير موثق، lint gate مكسور. |
| Medium | pagination، query filtering، legal/retention، moderation، PWA precache، dependencies القالبية. |
| Low | تحسينات typography، WebP، تقليل مكونات UI غير المستخدمة، polish للرسائل. |

## 16. Project Score

| المجال | الدرجة | سبب مختصر |
|---|---:|---|
| Architecture | 68/100 | فصل جيد لمشروع MVP، لكن domain rules موزعة بين العميل وRLS. |
| Functionality | 67/100 | مسارات كثيرة حقيقية، لكن الفحص والرفع والتنزيل غير مثبتة end-to-end. |
| UI/UX | 76/100 | تصميم عربي متسق واستجابة أساسية جيدة، مع نقص في error/progress/accessibility. |
| Security | 42/100 | وجود RLS وserver functions إيجابي، لكن صلاحيات apps والرفع والفحص عالية المخاطر. |
| Performance | 61/100 | حدود واستعلامات معقولة لـ MVP، لكن لا pagination أو قياسات فعلية. |
| Database | 64/100 | schema جيد مبدئيًا، مع drift وصلاحيات واسعة ونقص constraints/tests. |
| Code Quality | 62/100 | TypeScript strict وbuild ناجحان، لكن lint يفشل ولا توجد tests. |
| Reliability | 50/100 | error boundary موجود، لكن فشل scan والعمليات الجزئية غير محكم. |
| Scalability | 49/100 | القراءة المباشرة والlimits تكفي للبداية، لا للنمو العام. |
| Production Readiness | 44/100 | يحتاج hardening وتشغيلًا ومراقبة واختبارات قبل الإطلاق. |
| **Overall Score** | **57/100** | **MVP قوي بصريًا ووظيفيًا، غير جاهز لإطلاق عام آمن.** |

## 17. Complete Problems Table

| ID | المشكلة | النوع | الخطورة | التأثير | المكان | الحل | الأولوية |
|---|---|---|---|---|---|---|---|
| P-01 | publisher update policy واسعة | Security/Database | Critical | تجاوز دورة النشر | migration apps policy | RPC/allowlist وتقييد الأعمدة | Critical |
| P-02 | لا يوجد file validation خادمي كافٍ | Security/Incomplete | Critical | ملفات ضارة/كبيرة | upload routes/storage | size/MIME/magic bytes/server checks | Critical |
| P-03 | scan request failure مخفي | Broken/Reliability | High | حالة نجاح زائفة | publisher/upload.tsx | لا تبتلع الخطأ، أظهر queue/retry | Critical |
| P-04 | لا يوجد worker/retry للفحص ظاهر | Incomplete | High | queued forever | scan.functions.ts | queue/cron/webhook | Critical |
| P-05 | approved وclean ليست invariant مؤكدة | Security | Critical | نشر غير مفحوص | apps/RLS/admin | trigger/RPC transition | Critical |
| P-06 | RLS غير مختبر | Security | High | IDOR غير مكتشف | supabase | test matrix staging | Critical |
| P-07 | buckets غير معرفة كـ IaC كامل | Deployment | High | تسريب/فشل تنزيل | Storage | runbook/migrations/config | High |
| P-08 | حد 50MB نص واجهة فقط | Broken | High | تكلفة/DoS تخزين | files.upload.tsx | server/storage limit | High |
| P-09 | لا rate limit | Security | High | spam/abuse | functions/forum | per-IP/user limits | High |
| P-10 | لا rollback للرفع الجزئي | Reliability | High | orphan objects | publisher upload | cleanup transaction/job | High |
| P-11 | lint يفشل | Code Quality | Medium | CI/maintenance failures | multiple files | `prettier --write` ثم CI gate | High |
| P-12 | PWA precache 0 | Performance | Medium | offline ضعيف | vite.config.ts | fix output/glob and test | Medium |
| P-13 | category filter client-side | Performance | Medium | results ناقصة/طلبات أكبر | marketplace.ts | server-side relation filter | Medium |
| P-14 | no pagination/cursors | Performance | High | degradation with growth | marketplace/files/forum | cursor/infinite query | High |
| P-15 | direct client mutations متعددة | Architecture | High | business rule bypass | routes/lib | domain server functions | High |
| P-16 | downloads insert grants broad | Security | Medium | alternate count path | downloads migration | revoke direct insert if unused | Medium |
| P-17 | file queued/scanning downloadable | Security/Product | High | unscanned sharing | record_file_download | require clean or explicit policy | High |
| P-18 | reports/status untyped | Database | Medium | inconsistent moderation state | app_reports | enum/check + workflow | Medium |
| P-19 | no E2E tests | Missing | High | regressions | project-wide | auth/upload/download tests | Critical |
| P-20 | no production observability | Missing | High | delayed incidents | deployment | logs/metrics/alerts | High |
| P-21 | legal/privacy content needs finalization | UX/Compliance | Medium | trust/consent risk | legal routes | review and retention policy | Medium |
| P-22 | delete file no confirmation | UX | Medium | accidental deletion | files.upload.tsx | AlertDialog | Medium |
| P-23 | query errors look like empty states | UX | Medium | misleading UI | multiple routes | ErrorState + retry | Medium |
| P-24 | npm audit/SCA not run | Security | Medium | unknown CVEs | dependencies | CI scanning | High |
| P-25 | README not project documentation | Missing | Medium | poor onboarding/deploy | README.md | rewrite runbook | Medium |

## 18. Priority Fix List

1. أغلق تحديثات `apps` العامة للناشر، وأنشئ transition API خادمية allowlisted.
2. اجعل شرط النشر invariant: `status = approved` لا يكون ممكنًا إلا مع `scan_status = clean` وscan record صالح.
3. أضف limits وMIME/magic-byte validation على الخادم وStorage، مع حد حقيقي 50MB أو قيمة موحدة.
4. أصلح lifecycle للفحص: queue، retry، polling/webhook، timeout، failed state، وواجهة واضحة.
5. اكتب اختبارات RLS وownership لكل جدول حساس وكل Server Function.
6. نفذ rollback/cleanup لكل upload يفشل بعد رفع بعض الملفات.
7. أضف rate limits وidempotency للتنزيل والفحص والبلاغ والمنتدى.
8. أصلح `lint` وأضف CI يمنع الدمج عند فشل build/lint/typecheck.
9. أضف E2E حقيقيًا للتسجيل، الرفع، قبول المشرف، الفحص، التنزيل، الملف الخاص، والخروج.
10. وثّق واثبت إعداد Supabase Storage والبيئة والمراقبة والـrollback.

## 19. Development Roadmap

### PHASE 1 — Critical

إغلاق SEC-01 إلى SEC-05، استبدال updates الحساسة بـ RPC/domain functions، فرض upload limits، وإضافة RLS test matrix. لا تنقل المشروع إلى public beta قبل إكمال هذه المرحلة.

### PHASE 2 — Core Functionality

إكمال scan lifecycle، حالات `queued/scanning/clean/flagged/failed`، cleanup، retry، pagination، وتوحيد validation بين frontend/backend.

### PHASE 3 — Security

إضافة rate limiting، audit log إداري، security headers، مراجعة CORS/CSRF على CDN، dependency scanning، سياسات VirusTotal والاحتفاظ، وفحص direct storage access.

### PHASE 4 — Performance

نقل الفلاتر إلى SQL، إضافة indexes بعد `EXPLAIN`, cursor pagination، تقليل invalidation، تحسين رفع اللقطات بتزامن محدود، وإصلاح PWA caching.

### PHASE 5 — UI/UX

إضافة ErrorState/retry، progress/preview للرفع، confirmation للحذف، حالات scan صريحة، تحسين accessibility باختبارات axe، وإتمام legal/contact copy.

### PHASE 6 — Cleanup

تشغيل dependency graph، إزالة ما هو غير مستخدم بعد التحقق، توحيد لوحة admin، تقليل القالبية، وتنظيف migrations المرجعية المتكررة.

### PHASE 7 — Final Polish

اختبار load وmobile/tablet، قياس Core Web Vitals، مراجعة copy العربية، إعداد alerting/runbook، smoke test بعد deploy، وقرار go/no-go موثق.

## 20. Production Readiness Assessment

| الشرط | الحالة |
|---|---|
| Build | PASS |
| Lint | FAIL |
| Type safety | Build مرّ؛ typecheck مستقل غير مثبت كأمر منفصل |
| Authentication | Partially Verified |
| Authorization/RLS | Not Verified end-to-end؛ مخاطر مؤكدة من schema |
| Upload security | FAIL for production bar |
| Antivirus workflow | Incomplete/Not Verified |
| Database migrations | موجودة، لكن تحتاج staging verification وdrift review |
| Error handling | Partially Working |
| Monitoring | Missing from repository evidence |
| Tests | Missing from repository evidence |
| Deployment runbook | Missing/insufficient |
| Mobile/responsive | Code suggests support; visual test Not Verified |

## 21. Final Verdict

المشروع **ليس جاهزًا للإطلاق العام**، لكنه ليس prototype وهميًا. توجد شيفرة فعلية تغطي معظم رحلة المنتج، ونجاح build يؤكد أن الأساس قابل للتشغيل. الفجوة الأساسية بين الوضع الحالي والمنتج الإنتاجي هي **الضمانات الخادمية والتشغيلية**، لا إعادة بناء الواجهة.

### أكبر 10 مشاكل تمنع الإطلاق

1. صلاحيات تحديث `apps` أوسع من اللازم.
2. عدم وجود invariant خادمي يربط `approved` بـ `clean`.
3. تحقق الملفات من جهة العميل أكثر من الخادم.
4. lifecycle الفحص الأمني غير مكتمل أو غير مثبت.
5. لا توجد اختبارات RLS/ownership.
6. إعداد Storage الفعلي غير موثق/غير متحقق.
7. عدم وجود rate limiting وanti-abuse.
8. لا يوجد rollback للرفع الجزئي.
9. lint يفشل، ولا توجد CI/tests ظاهرة.
10. لا توجد observability وrunbook إنتاجي كافيان.

### أهم 10 أشياء يجب إضافتها

1. Server-side domain API للنشر.
2. File validation وحدود حجم ونوع حقيقية.
3. Scan queue/retry/webhook/failed state.
4. RLS integration tests.
5. E2E suite.
6. Rate limiting وidempotency.
7. Cleanup للملفات orphaned.
8. Pagination وquery indexes.
9. Monitoring وalerts وaudit log.
10. README/runbook و`.env.example` وسياسة privacy/retention نهائية.

### أهم 10 أشياء يجب حذفها أو تبسيطها

1. حذف dependencies غير المستخدمة بعد تحقق نهائي.
2. إزالة أي UI components قالبية غير مستوردة فعليًا.
3. توحيد لوحات الإدارة المتكررة إن ثبت وجود legacy route.
4. تقليل updates المباشرة من routes إلى domain functions.
5. إزالة grants غير اللازمة على downloads.
6. تبسيط مسار error-capture بعد إضافة اختبارات.
7. فصل أو تأجيل أعمدة الدفع غير المستخدمة إن لم تكن ضمن release.
8. إزالة إدخالات seed المتكررة وتوحيد migrations المرجعية.
9. تقليل invalidation العام إلى cache updates مستهدفة.
10. حذف أي صفحة/إعداد لا يظهر في route graph بعد إجراء dependency graph حقيقي.

### ماذا يجب إصلاحه أولًا؟

**ابدأ بـ P-01 وP-02 وP-03 وP-04 وP-05 وP-06.** بعد ذلك شغّل staging E2E من إنشاء المستخدم حتى التنزيل، مع مستخدم عادي وناشر ومشرف، وسجّل نتائج RLS وStorage والفحص. إذا نجح هذا السيناريو، انتقل إلى rate limiting والمراقبة ثم polish الواجهة.

## References

[1]: file:///home/ubuntu/falqo-audit/package.json "FALQO package manifest"
[2]: file:///home/ubuntu/falqo-audit/src/routes/_authenticated/publisher/upload.tsx "Publisher upload route"
[3]: file:///home/ubuntu/falqo-audit/src/routes/_authenticated/files.upload.tsx "Shared file upload route"
[4]: file:///home/ubuntu/falqo-audit/src/lib/scan.functions.ts "VirusTotal scan server functions"
[5]: file:///home/ubuntu/falqo-audit/src/lib/downloads.functions.ts "Application download server function"
[6]: file:///home/ubuntu/falqo-audit/src/integrations/supabase/auth-middleware.ts "Supabase server authentication middleware"
[7]: file:///home/ubuntu/falqo-audit/supabase/migrations/20260817102033_4b8fe88d-3281-48d8-b96e-4d19b7d86d04.sql "Initial Supabase schema and policies"
[8]: file:///home/ubuntu/falqo-audit/supabase/migrations/20260825065302_3a201115-27ab-4093-95b9-a5d5ae678a49.sql "Download RPC and publisher policies"
[9]: file:///home/ubuntu/falqo-audit/supabase/migrations/20260829144938_3a81d9d9-6fa0-4cd0-83b4-0901023713d4.sql "Files and forum schema"
[10]: file:///home/ubuntu/falqo-audit/vite.config.ts "Vite, Nitro, and PWA configuration"
[11]: file:///home/ubuntu/falqo-audit/README.md "Project README"
[12]: file:///tmp/falqo-lint.log "Lint output captured during audit"
[13]: file:///tmp/falqo-build.log "Build output captured during audit"
