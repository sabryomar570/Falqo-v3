# FALQO

منصة عربية لمتجر تطبيقات آمن، مشاركة الملفات، والمجتمع. يعتمد المشروع على React وTanStack Start وSupabase، ويمكن تشغيله محليًا أو رفعه على استضافة تدعم Node.js.

## المتطلبات

- Node.js 20 أو أحدث
- npm 10 أو أحدث
- مشروع Supabase مع Auth وPostgres وStorage
- مفتاح VirusTotal اختياري إذا كان الفحص الخارجي مفعّلًا

## التشغيل المحلي

```bash
npm ci
cp .env.example .env
npm run dev
```

## التحقق قبل النشر

```bash
npm test
npm run lint
npx tsc --noEmit
npm run build
```

## متغيرات البيئة

راجع `.env.example`. المتغيرات التي تبدأ بـ `VITE_` تستخدم في المتصفح، أما `SUPABASE_SERVICE_ROLE_KEY` و`VIRUSTOTAL_API_KEY` فهما للخادم فقط ويجب عدم تضمينهما في كود المتصفح أو مستودع Git.

## النشر

```bash
npm ci --omit=dev
npm run build
node .output/server/index.mjs
```

يستمع الخادم على المنفذ الموجود في `PORT` عند ضبطه من مزود الاستضافة، أو على المنفذ الافتراضي الذي توفره منصة التشغيل. اضبط `NITRO_PRESET` حسب مزود الاستضافة عند الحاجة، مثل `node-server` أو `vercel` أو `netlify`.

طبّق migrations الموجودة في `supabase/migrations` على مشروع Supabase staging أولًا، ثم نفّذ مصفوفة الصلاحيات في `audit/SECURITY_MATRIX.md` قبل الإنتاج. دليل النشر والتشغيل موجودان في `docs/DEPLOYMENT.md` و`docs/RUNBOOK.md`.

## الترخيص والحقوق

حقوق اسم وشعار ومحتوى FALQO تعود إلى مالك المشروع. حقوق المكتبات الخارجية تبقى وفق تراخيصها الأصلية، ويمكن مراجعة تراخيص الحزم عبر `npm ls` وملفات الحزم الخاصة بها.
