import { describe, expect, it } from "vitest";

import { sanitizeFilename, validateUploadFile } from "../src/lib/upload-validation";

function file(name: string, size: number, type: string) {
  return new File([new Uint8Array(size)], name, { type });
}

describe("upload validation", () => {
  it("sanitizes path separators and control characters", () => {
    expect(sanitizeFilename("../dangerous file\n.apk")).toBe("dangerous_file.apk");
  });

  it("accepts supported app packages within the size limit", () => {
    expect(
      validateUploadFile(
        file("release.apk", 1024, "application/vnd.android.package-archive"),
        "app",
      ),
    ).toEqual({
      safeName: "release.apk",
      extension: "apk",
    });
  });

  it("rejects executable scripts and oversized files", () => {
    expect(() =>
      validateUploadFile(file("payload.sh", 1024, "text/x-shellscript"), "shared"),
    ).toThrow("blocked_file_type");
    expect(() =>
      validateUploadFile(file("large.zip", 51 * 1024 * 1024, "application/zip"), "shared"),
    ).toThrow("file_too_large");
  });

  it("requires a real image MIME and supported extension for screenshots", () => {
    expect(() =>
      validateUploadFile(file("image.svg", 1024, "image/svg+xml"), "screenshot"),
    ).toThrow("invalid_image_type");
    expect(validateUploadFile(file("image.webp", 1024, "image/webp"), "screenshot").extension).toBe(
      "webp",
    );
  });
});
