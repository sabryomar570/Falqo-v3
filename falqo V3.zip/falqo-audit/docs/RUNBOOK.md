# Operations Runbook

## Failed scans

Inspect the related `scan_jobs` or `file_scan_jobs` row, provider response, attempt count, and `last_error`. Retry only within the configured attempt limit. Never manually mark content clean without an authorized review and a recorded reason.

## Failed uploads

Find records without valid Storage objects and objects without a database owner. Run cleanup in dry-run mode first, then delete only objects proven to be orphaned.

## Failed downloads

Check app/file status, Storage signed URL creation, RPC result, and provider logs. Redact the URL and token from all incident output.

## Security incident

Disable affected upload or download capability, preserve sanitized logs, rotate exposed secrets, identify affected rows, and document the incident before re-enabling access.
