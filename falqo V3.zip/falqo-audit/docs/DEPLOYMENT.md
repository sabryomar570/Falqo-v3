# Deployment Guide

## Required environment

Copy `.env.example` to the deployment secret manager. Never commit `.env`, service-role keys, or provider secrets.

Required server variables are `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`. `VIRUSTOTAL_API_KEY` is optional only for environments that intentionally use manual scanning; absence must leave content non-downloadable until an authorized review marks it clean.

## Supabase setup

Apply migrations in filename order to a staging project first. Confirm the four Storage buckets exist with the intended public/private configuration and run `audit/SECURITY_MATRIX.md` before production.

## Build and deploy

```sh
npm ci
npm run lint
npx tsc --noEmit
npm run build
npx vite preview
```

Use the generated Nitro deployment target appropriate for the hosting provider. Configure TLS, HTTPS-only cookies, security headers, log redaction, health checks, and a rollback to the previous build.

## Release gate

Do not deploy when lint, typecheck, build, RLS tests, storage tests, or scan lifecycle checks fail. A successful build alone is not a production approval.
