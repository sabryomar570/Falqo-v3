# Testing Guide

## Local checks

```sh
npm ci
npm run lint
npx tsc --noEmit
npm run build
```

## Required automated layers

Unit tests cover filename sanitization, upload limits, extension/MIME rules, slug creation, and scan state transitions. Integration tests cover Server Functions, RPCs, signed URL authorization, and database invariants. RLS tests use isolated anonymous, user, publisher, and admin sessions. E2E tests cover the flows listed in `audit/E2E_RESULTS.md`.

Use a dedicated staging Supabase project and synthetic files. Never test destructive paths against production data.
