# Security Guide

FALQO treats the browser as untrusted. RLS, server identity, Storage policies, database triggers, and provider state transitions are the enforcement layers.

Publisher clients must not update approval, scan verdict, ownership, counters, featured state, or publication timestamps. Use the narrow `update_publisher_app` RPC for editable metadata. Admin and provider transitions must pass the database publication invariant.

Uploads must pass client validation, Storage metadata limits, server-side metadata validation, and antivirus policy. A file with `queued`, `scanning`, `failed`, or `flagged` status is not downloadable as a public asset.

Never log access tokens, service-role keys, provider keys, signed URLs, or raw sensitive payloads. Apply rate limits to authentication, uploads, downloads, scans, reports, reviews, search, and community writes.

Run the role matrix in `audit/SECURITY_MATRIX.md` for every schema or policy change.
