ALTER TABLE public.downloads
  ADD COLUMN IF NOT EXISTS app_version text,
  ADD COLUMN IF NOT EXISTS file_size bigint;

CREATE POLICY "downloads_publisher_read_own_apps"
ON public.downloads
FOR SELECT
TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.apps a
  WHERE a.id = downloads.app_id AND a.publisher_id = auth.uid()
));

CREATE OR REPLACE FUNCTION public.record_download(_app_id uuid, _user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE target public.apps;
BEGIN
  SELECT * INTO target FROM public.apps WHERE id = _app_id;
  IF target.id IS NULL THEN
    RAISE EXCEPTION 'app_not_found';
  END IF;
  IF target.status <> 'approved' OR target.scan_status <> 'clean' THEN
    RAISE EXCEPTION 'app_not_available';
  END IF;

  INSERT INTO public.downloads (app_id, user_id, app_version, file_size)
  VALUES (_app_id, _user_id, target.version, target.file_size);

  UPDATE public.apps SET downloads_count = downloads_count + 1 WHERE id = _app_id;
END;
$$;

REVOKE ALL ON FUNCTION public.record_download(uuid, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.record_download(uuid, uuid) TO service_role;

CREATE POLICY "scan_jobs_publisher_read_own"
ON public.scan_jobs
FOR SELECT
TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.apps a
  WHERE a.id = scan_jobs.app_id AND a.publisher_id = auth.uid()
));

GRANT SELECT ON public.scan_jobs TO authenticated;
GRANT ALL ON public.scan_jobs TO service_role;
GRANT SELECT, INSERT ON public.downloads TO authenticated;
GRANT INSERT ON public.downloads TO anon;
GRANT ALL ON public.downloads TO service_role;
