-- FALQO production hardening.
-- This migration intentionally narrows client capabilities and makes the scan
-- lifecycle explicit. Apply it in staging first and run the RLS matrix.

ALTER TYPE public.scan_status ADD VALUE IF NOT EXISTS 'failed';

ALTER TABLE public.scan_jobs
  ADD COLUMN IF NOT EXISTS attempts INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS last_error TEXT,
  ADD COLUMN IF NOT EXISTS idempotency_key TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS scan_jobs_idempotency_key_idx
  ON public.scan_jobs (idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS scan_jobs_retry_idx
  ON public.scan_jobs (status, next_attempt_at);

-- Do not expose a generic app update surface to publishers. Publisher-owned
-- metadata is changed through the narrow function below; moderation and scan
-- state remain server/admin responsibilities.
DROP POLICY IF EXISTS "apps_publisher_update_own" ON public.apps;

CREATE OR REPLACE FUNCTION public.update_publisher_app(
  _app_id UUID,
  _name TEXT,
  _tagline TEXT,
  _description TEXT,
  _category_id UUID,
  _version TEXT
)
RETURNS public.apps
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE result public.apps;
BEGIN
  UPDATE public.apps
  SET name = left(trim(_name), 80),
      tagline = NULLIF(left(trim(COALESCE(_tagline, '')), 120), ''),
      description = left(trim(_description), 4000),
      category_id = _category_id,
      version = left(trim(_version), 20),
      updated_at = now()
  WHERE id = _app_id AND publisher_id = auth.uid()
  RETURNING * INTO result;

  IF result.id IS NULL THEN
    RAISE EXCEPTION 'app_not_found_or_forbidden';
  END IF;
  RETURN result;
END;
$$;

REVOKE ALL ON FUNCTION public.update_publisher_app(UUID, TEXT, TEXT, TEXT, UUID, TEXT)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.update_publisher_app(UUID, TEXT, TEXT, TEXT, UUID, TEXT)
  TO authenticated;

-- Only the service role can record public download events. The client cannot
-- forge user_id or increment counters through PostgREST.
REVOKE INSERT ON public.downloads FROM anon, authenticated;

-- A file is not downloadable until it has a clean verdict. Owners/admins can
-- still inspect their rows through RLS for remediation.
CREATE OR REPLACE FUNCTION public.record_file_download(_file_id UUID, _user_id UUID)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target public.files;
BEGIN
  SELECT * INTO target FROM public.files WHERE id = _file_id;
  IF target.id IS NULL THEN RAISE EXCEPTION 'file_not_found'; END IF;
  IF target.scan_status <> 'clean' THEN RAISE EXCEPTION 'file_not_available'; END IF;
  INSERT INTO public.file_downloads (file_id, user_id) VALUES (_file_id, _user_id);
  UPDATE public.files SET downloads_count = downloads_count + 1 WHERE id = _file_id;
END; $$;

REVOKE ALL ON FUNCTION public.record_file_download(UUID, UUID) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.record_file_download(UUID, UUID) TO service_role;

-- Keep report states bounded and index moderation queues.
ALTER TABLE public.app_reports
  ADD CONSTRAINT app_reports_status_check
  CHECK (status IN ('open', 'reviewing', 'resolved', 'dismissed'));
CREATE INDEX IF NOT EXISTS app_reports_status_created_idx
  ON public.app_reports (status, created_at DESC);

-- These policies preserve public media reads for icons/screenshots while the
-- application binary remains accessible only through the signed server flow.
DROP POLICY IF EXISTS "app_media_public_read" ON storage.objects;
CREATE POLICY "app_media_public_read" ON storage.objects FOR SELECT
  USING (bucket_id IN ('app-icons', 'app-screenshots'));

-- Shared-file objects are owner-scoped; public sharing is implemented by the
-- server function, not by a public storage SELECT policy.
DROP POLICY IF EXISTS "shared_files_owner_read" ON storage.objects;
CREATE POLICY "shared_files_owner_read" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'shared-files' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE INDEX IF NOT EXISTS apps_publisher_created_idx
  ON public.apps (publisher_id, created_at DESC);
CREATE INDEX IF NOT EXISTS apps_live_category_created_idx
  ON public.apps (status, scan_status, category_id, created_at DESC);
