-- Storage policies are a second line of defense. The application still validates
-- file content before upload and the scanner remains the publication gate.
DROP POLICY IF EXISTS "app_media_owner_insert" ON storage.objects;
CREATE POLICY "app_media_owner_insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  owner = auth.uid()
  AND (
    (bucket_id IN ('app-icons', 'app-screenshots')
      AND COALESCE((metadata->>'size')::bigint, 0) <= 8388608
      AND COALESCE(metadata->>'mimetype', '') LIKE 'image/%')
    OR
    (bucket_id = 'app-files'
      AND COALESCE((metadata->>'size')::bigint, 0) <= 262144000)
  )
);

DROP POLICY IF EXISTS "shared_files_owner_insert" ON storage.objects;
CREATE POLICY "shared_files_owner_insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'shared-files'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND COALESCE((metadata->>'size')::bigint, 0) <= 52428800
  AND COALESCE(metadata->>'mimetype', '') NOT IN (
    'text/html', 'application/javascript', 'text/javascript',
    'application/x-httpd-php', 'application/x-sh', 'application/x-msdos-program'
  )
);

DROP POLICY IF EXISTS "app_media_owner_update" ON storage.objects;
CREATE POLICY "app_media_owner_update" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id IN ('app-icons', 'app-screenshots', 'app-files') AND owner = auth.uid())
WITH CHECK (bucket_id IN ('app-icons', 'app-screenshots', 'app-files') AND owner = auth.uid());
