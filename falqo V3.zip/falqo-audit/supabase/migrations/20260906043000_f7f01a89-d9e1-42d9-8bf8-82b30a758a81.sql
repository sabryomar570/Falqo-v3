UPDATE public.forum_topics SET category_id = '82aa0e2b-a87e-4349-ab03-954653c82ad0'
WHERE category_id = 'e26fc6f0-6c68-4136-9f67-7602a77530cc';
DELETE FROM public.forum_categories WHERE id = 'e26fc6f0-6c68-4136-9f67-7602a77530cc';