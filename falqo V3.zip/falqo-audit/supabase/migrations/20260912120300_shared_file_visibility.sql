DROP POLICY IF EXISTS files_public_read ON public.files;
CREATE POLICY files_public_read ON public.files FOR SELECT TO anon, authenticated
  USING (visibility = 'public' AND scan_status = 'clean');
