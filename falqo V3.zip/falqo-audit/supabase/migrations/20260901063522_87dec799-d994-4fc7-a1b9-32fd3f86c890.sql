INSERT INTO public.forum_categories (slug, name_ar, description_ar, icon, sort_order) VALUES
  ('requests', 'طلبات التطبيقات', 'اطلب تطبيقًا أو ملفًا وسيساعدك المجتمع', 'Sparkles', 1),
  ('support', 'الدعم الفني', 'مشاكل التحميل والتثبيت والحسابات', 'LifeBuoy', 2),
  ('news', 'أخبار وتحديثات', 'جديد المنصة والتطبيقات والإصدارات', 'Megaphone', 3),
  ('general', 'نقاش عام', 'أي موضوع يخص التقنية والتطبيقات', 'MessagesSquare', 4)
ON CONFLICT (slug) DO NOTHING;