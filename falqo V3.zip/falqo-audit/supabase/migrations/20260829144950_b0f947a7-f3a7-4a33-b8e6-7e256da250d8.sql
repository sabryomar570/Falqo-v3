REVOKE EXECUTE ON FUNCTION public.refresh_forum_topic_counts() FROM anon, authenticated, PUBLIC;
