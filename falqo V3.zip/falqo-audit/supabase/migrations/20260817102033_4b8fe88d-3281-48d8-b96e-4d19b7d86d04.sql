CREATE TYPE public.app_role AS ENUM ('admin','moderator','user');
CREATE TYPE public.app_status AS ENUM ('pending','approved','rejected');
CREATE TYPE public.scan_status AS ENUM ('queued','scanning','clean','flagged');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  avatar_url TEXT,
  is_publisher BOOLEAN NOT NULL DEFAULT false,
  publisher_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "user_roles_read_own" ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  icon TEXT NOT NULL DEFAULT 'Sparkles',
  gradient_from TEXT NOT NULL DEFAULT '#0071E3',
  gradient_to TEXT NOT NULL DEFAULT '#5AC8FA',
  sort_order INT NOT NULL DEFAULT 0
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories_public_read" ON public.categories FOR SELECT USING (true);

CREATE TABLE public.apps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  publisher_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  tagline TEXT,
  description TEXT NOT NULL DEFAULT '',
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  icon_url TEXT,
  screenshots TEXT[] NOT NULL DEFAULT '{}',
  file_url TEXT,
  file_name TEXT,
  file_size BIGINT NOT NULL DEFAULT 0,
  version TEXT NOT NULL DEFAULT '1.0.0',
  platform TEXT NOT NULL DEFAULT 'android',
  downloads_count BIGINT NOT NULL DEFAULT 0,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 0,
  rating_count INT NOT NULL DEFAULT 0,
  status public.app_status NOT NULL DEFAULT 'pending',
  rejection_reason TEXT,
  scan_status public.scan_status NOT NULL DEFAULT 'queued',
  scan_provider TEXT,
  scan_report JSONB,
  scanned_at TIMESTAMPTZ,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_free BOOLEAN NOT NULL DEFAULT true,
  price_cents INT NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  platform_fee_bps INT NOT NULL DEFAULT 0,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX apps_category_idx ON public.apps(category_id);
CREATE INDEX apps_status_idx ON public.apps(status, scan_status);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.apps TO authenticated;
GRANT SELECT ON public.apps TO anon;
GRANT ALL ON public.apps TO service_role;
ALTER TABLE public.apps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "apps_public_read_live" ON public.apps FOR SELECT
  USING (status = 'approved' AND scan_status = 'clean');
CREATE POLICY "apps_publisher_read_own" ON public.apps FOR SELECT TO authenticated
  USING (auth.uid() = publisher_id);
CREATE POLICY "apps_admin_read_all" ON public.apps FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "apps_publisher_insert" ON public.apps FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = publisher_id);
CREATE POLICY "apps_publisher_update_own" ON public.apps FOR UPDATE TO authenticated
  USING (auth.uid() = publisher_id) WITH CHECK (auth.uid() = publisher_id);
CREATE POLICY "apps_admin_update" ON public.apps FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "apps_publisher_delete_own" ON public.apps FOR DELETE TO authenticated
  USING (auth.uid() = publisher_id OR public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id UUID NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (app_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reviews TO authenticated;
GRANT SELECT ON public.reviews TO anon;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews_public_read" ON public.reviews FOR SELECT USING (true);
CREATE POLICY "reviews_insert_own" ON public.reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "reviews_update_own" ON public.reviews FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "reviews_delete_own" ON public.reviews FOR DELETE TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.downloads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id UUID NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.downloads TO authenticated;
GRANT INSERT ON public.downloads TO anon;
GRANT ALL ON public.downloads TO service_role;
ALTER TABLE public.downloads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "downloads_insert_any" ON public.downloads FOR INSERT WITH CHECK (true);
CREATE POLICY "downloads_admin_read" ON public.downloads FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.scan_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id UUID NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'manual',
  external_id TEXT,
  status public.scan_status NOT NULL DEFAULT 'queued',
  result JSONB,
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);
GRANT SELECT ON public.scan_jobs TO authenticated;
GRANT ALL ON public.scan_jobs TO service_role;
ALTER TABLE public.scan_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "scan_jobs_admin_read" ON public.scan_jobs FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS TRIGGER
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER apps_touch BEFORE UPDATE ON public.apps FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'avatar_url')
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user') ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.refresh_app_rating() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target UUID;
BEGIN
  target := COALESCE(NEW.app_id, OLD.app_id);
  UPDATE public.apps a SET
    rating_avg = COALESCE((SELECT ROUND(AVG(rating)::numeric, 2) FROM public.reviews WHERE app_id = target), 0),
    rating_count = (SELECT COUNT(*) FROM public.reviews WHERE app_id = target)
  WHERE a.id = target;
  RETURN NULL;
END; $$;
CREATE TRIGGER reviews_rating_sync AFTER INSERT OR UPDATE OR DELETE ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.refresh_app_rating();

INSERT INTO public.categories (slug, name, name_ar, icon, gradient_from, gradient_to, sort_order) VALUES
  ('games','Games','ألعاب','Gamepad2','#FF7A59','#FFB65C',1),
  ('productivity','Productivity','إنتاجية','ListChecks','#0071E3','#5AC8FA',2),
  ('education','Education','تعليم','GraduationCap','#34C759','#8BE78B',3),
  ('entertainment','Entertainment','ترفيه','Play','#AF52DE','#DA8FFF',4),
  ('tools','Tools','أدوات','Wrench','#8E8E93','#C7C7CC',5),
  ('social','Social','تواصل','MessageCircle','#FF375F','#FF8FA8',6);

CREATE POLICY "app_media_public_read" ON storage.objects FOR SELECT
  USING (bucket_id IN ('app-icons','app-screenshots','app-files'));
CREATE POLICY "app_media_owner_insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id IN ('app-icons','app-screenshots','app-files') AND owner = auth.uid());
CREATE POLICY "app_media_owner_update" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id IN ('app-icons','app-screenshots','app-files') AND owner = auth.uid());
CREATE POLICY "app_media_owner_delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id IN ('app-icons','app-screenshots','app-files') AND owner = auth.uid());