-- ============ PUBLIC FILE SHARING ============
CREATE TABLE public.files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  file_path TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_size BIGINT NOT NULL DEFAULT 0,
  mime_type TEXT,
  visibility TEXT NOT NULL DEFAULT 'public',
  downloads_count BIGINT NOT NULL DEFAULT 0,
  scan_status scan_status NOT NULL DEFAULT 'queued',
  scan_report JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT files_visibility_check CHECK (visibility IN ('public','private'))
);
CREATE INDEX files_owner_idx ON public.files(owner_id);
CREATE INDEX files_public_idx ON public.files(visibility, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.files TO authenticated;
GRANT SELECT ON public.files TO anon;
GRANT ALL ON public.files TO service_role;
ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;

CREATE POLICY files_public_read ON public.files FOR SELECT TO anon, authenticated
  USING (visibility = 'public' AND scan_status <> 'flagged');
CREATE POLICY files_owner_read ON public.files FOR SELECT TO authenticated
  USING (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY files_owner_insert ON public.files FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY files_owner_update ON public.files FOR UPDATE TO authenticated
  USING (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY files_owner_delete ON public.files FOR DELETE TO authenticated
  USING (owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER files_touch BEFORE UPDATE ON public.files
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.file_downloads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id UUID NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX file_downloads_file_idx ON public.file_downloads(file_id, created_at DESC);
GRANT SELECT ON public.file_downloads TO authenticated;
GRANT ALL ON public.file_downloads TO service_role;
ALTER TABLE public.file_downloads ENABLE ROW LEVEL SECURITY;
CREATE POLICY file_downloads_owner_read ON public.file_downloads FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.files f WHERE f.id = file_downloads.file_id AND f.owner_id = auth.uid())
    OR public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.record_file_download(_file_id UUID, _user_id UUID)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target public.files;
BEGIN
  SELECT * INTO target FROM public.files WHERE id = _file_id;
  IF target.id IS NULL THEN RAISE EXCEPTION 'file_not_found'; END IF;
  IF target.scan_status = 'flagged' THEN RAISE EXCEPTION 'file_not_available'; END IF;
  INSERT INTO public.file_downloads (file_id, user_id) VALUES (_file_id, _user_id);
  UPDATE public.files SET downloads_count = downloads_count + 1 WHERE id = _file_id;
END; $$;
REVOKE EXECUTE ON FUNCTION public.record_file_download(UUID, UUID) FROM anon, authenticated;

-- ============ COMMUNITY FORUM ============
CREATE TABLE public.forum_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  description_ar TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT 'MessagesSquare',
  sort_order INTEGER NOT NULL DEFAULT 0
);
GRANT SELECT ON public.forum_categories TO anon, authenticated;
GRANT ALL ON public.forum_categories TO service_role;
ALTER TABLE public.forum_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY forum_categories_read ON public.forum_categories FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.forum_topics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID NOT NULL REFERENCES public.forum_categories(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  is_pinned BOOLEAN NOT NULL DEFAULT false,
  is_locked BOOLEAN NOT NULL DEFAULT false,
  replies_count INTEGER NOT NULL DEFAULT 0,
  votes_count INTEGER NOT NULL DEFAULT 0,
  last_activity_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX forum_topics_category_idx ON public.forum_topics(category_id, last_activity_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.forum_topics TO authenticated;
GRANT SELECT ON public.forum_topics TO anon;
GRANT ALL ON public.forum_topics TO service_role;
ALTER TABLE public.forum_topics ENABLE ROW LEVEL SECURITY;
CREATE POLICY forum_topics_read ON public.forum_topics FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY forum_topics_insert ON public.forum_topics FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid());
CREATE POLICY forum_topics_update_own ON public.forum_topics FOR UPDATE TO authenticated
  USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY forum_topics_delete_own ON public.forum_topics FOR DELETE TO authenticated
  USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER forum_topics_touch BEFORE UPDATE ON public.forum_topics
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.forum_replies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id UUID NOT NULL REFERENCES public.forum_topics(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX forum_replies_topic_idx ON public.forum_replies(topic_id, created_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.forum_replies TO authenticated;
GRANT SELECT ON public.forum_replies TO anon;
GRANT ALL ON public.forum_replies TO service_role;
ALTER TABLE public.forum_replies ENABLE ROW LEVEL SECURITY;
CREATE POLICY forum_replies_read ON public.forum_replies FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY forum_replies_insert ON public.forum_replies FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid()
    AND EXISTS (SELECT 1 FROM public.forum_topics t WHERE t.id = topic_id AND t.is_locked = false));
CREATE POLICY forum_replies_update_own ON public.forum_replies FOR UPDATE TO authenticated
  USING (author_id = auth.uid()) WITH CHECK (author_id = auth.uid());
CREATE POLICY forum_replies_delete_own ON public.forum_replies FOR DELETE TO authenticated
  USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER forum_replies_touch BEFORE UPDATE ON public.forum_replies
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.forum_topic_votes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id UUID NOT NULL REFERENCES public.forum_topics(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (topic_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.forum_topic_votes TO authenticated;
GRANT SELECT ON public.forum_topic_votes TO anon;
GRANT ALL ON public.forum_topic_votes TO service_role;
ALTER TABLE public.forum_topic_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY forum_votes_read ON public.forum_topic_votes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY forum_votes_insert ON public.forum_topic_votes FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY forum_votes_delete ON public.forum_topic_votes FOR DELETE TO authenticated
  USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.refresh_forum_topic_counts()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target UUID;
BEGIN
  IF TG_TABLE_NAME = 'forum_replies' THEN
    target := COALESCE(NEW.topic_id, OLD.topic_id);
    UPDATE public.forum_topics t SET
      replies_count = (SELECT COUNT(*) FROM public.forum_replies WHERE topic_id = target),
      last_activity_at = GREATEST(t.created_at, COALESCE((SELECT MAX(created_at) FROM public.forum_replies WHERE topic_id = target), t.created_at))
    WHERE t.id = target;
  ELSE
    target := COALESCE(NEW.topic_id, OLD.topic_id);
    UPDATE public.forum_topics SET
      votes_count = (SELECT COUNT(*) FROM public.forum_topic_votes WHERE topic_id = target)
    WHERE id = target;
  END IF;
  RETURN NULL;
END; $$;

CREATE TRIGGER forum_replies_counts AFTER INSERT OR DELETE ON public.forum_replies
  FOR EACH ROW EXECUTE FUNCTION public.refresh_forum_topic_counts();
CREATE TRIGGER forum_votes_counts AFTER INSERT OR DELETE ON public.forum_topic_votes
  FOR EACH ROW EXECUTE FUNCTION public.refresh_forum_topic_counts();

INSERT INTO public.forum_categories (slug, name_ar, description_ar, icon, sort_order) VALUES
  ('app-requests', 'طلبات التطبيقات', 'اطلب تطبيقًا تريد رؤيته على FALQO', 'Sparkles', 1),
  ('support', 'الدعم الفني', 'مشاكل التحميل والتثبيت والحسابات', 'LifeBuoy', 2),
  ('news', 'الأخبار والتحديثات', 'إعلانات المنصة وتحديثات التطبيقات', 'Megaphone', 3),
  ('general', 'نقاش عام', 'أي حديث آخر مع مجتمع FALQO', 'MessagesSquare', 4);
