CREATE TABLE IF NOT EXISTS public.file_scan_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id UUID NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'manual',
  external_id TEXT,
  status public.scan_status NOT NULL DEFAULT 'queued',
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS file_scan_jobs_file_idx ON public.file_scan_jobs(file_id, requested_at DESC);
CREATE INDEX IF NOT EXISTS file_scan_jobs_retry_idx ON public.file_scan_jobs(status, requested_at);
GRANT SELECT ON public.file_scan_jobs TO authenticated;
GRANT ALL ON public.file_scan_jobs TO service_role;
ALTER TABLE public.file_scan_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY file_scan_jobs_owner_read ON public.file_scan_jobs FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.files f WHERE f.id = file_scan_jobs.file_id AND (f.owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))));
