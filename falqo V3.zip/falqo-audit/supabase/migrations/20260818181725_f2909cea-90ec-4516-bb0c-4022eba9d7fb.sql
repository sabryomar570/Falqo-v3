-- Wishlist
CREATE TABLE public.wishlist (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  app_id uuid not null references public.apps(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, app_id)
);
GRANT SELECT, INSERT, DELETE ON public.wishlist TO authenticated;
GRANT ALL ON public.wishlist TO service_role;
ALTER TABLE public.wishlist ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own wishlist select" ON public.wishlist FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "own wishlist insert" ON public.wishlist FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "own wishlist delete" ON public.wishlist FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Notifications
CREATE TABLE public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null default 'system',
  title text not null,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
GRANT SELECT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own notifications select" ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "own notifications update" ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "own notifications delete" ON public.notifications FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE INDEX notifications_user_created_idx ON public.notifications (user_id, created_at DESC);

-- App reports (Trust & Safety reporting)
CREATE TABLE public.app_reports (
  id uuid primary key default gen_random_uuid(),
  app_id uuid not null references public.apps(id) on delete cascade,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);
GRANT SELECT, INSERT ON public.app_reports TO authenticated;
GRANT ALL ON public.app_reports TO service_role;
ALTER TABLE public.app_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reporter reads own reports" ON public.app_reports FOR SELECT TO authenticated USING (reporter_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "user creates report" ON public.app_reports FOR INSERT TO authenticated WITH CHECK (reporter_id = auth.uid());
CREATE POLICY "admin updates report" ON public.app_reports FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Notify publisher when admin decides on their app
CREATE OR REPLACE FUNCTION public.notify_publisher_on_review()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.notifications (user_id, kind, title, body, link)
    VALUES (
      NEW.publisher_id,
      'review',
      CASE NEW.status
        WHEN 'approved' THEN 'تم قبول تطبيقك: ' || NEW.name
        WHEN 'rejected' THEN 'تم رفض تطبيقك: ' || NEW.name
        ELSE 'تحديث حالة المراجعة: ' || NEW.name
      END,
      COALESCE(NEW.rejection_reason, NULL),
      '/publisher'
    );
  END IF;
  IF NEW.scan_status IS DISTINCT FROM OLD.scan_status THEN
    INSERT INTO public.notifications (user_id, kind, title, body, link)
    VALUES (NEW.publisher_id, 'security', 'تحديث حالة الفحص الأمني: ' || NEW.name, NEW.scan_status, '/publisher');
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_publisher_on_review() FROM anon, authenticated;
CREATE TRIGGER apps_notify_publisher AFTER UPDATE ON public.apps FOR EACH ROW EXECUTE FUNCTION public.notify_publisher_on_review();