CREATE OR REPLACE FUNCTION public.enforce_app_publication_invariant()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'approved' AND (NEW.scan_status <> 'clean' OR NEW.file_url IS NULL) THEN
    RAISE EXCEPTION 'approved_app_requires_clean_scan_and_file';
  END IF;
  IF NEW.scan_status = 'clean' AND NEW.file_url IS NULL THEN
    RAISE EXCEPTION 'clean_app_requires_file';
  END IF;
  IF NEW.status = 'approved' AND NEW.published_at IS NULL THEN
    NEW.published_at = now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS apps_publication_invariant ON public.apps;
CREATE TRIGGER apps_publication_invariant
BEFORE INSERT OR UPDATE OF status, scan_status, file_url, published_at ON public.apps
FOR EACH ROW EXECUTE FUNCTION public.enforce_app_publication_invariant();

REVOKE ALL ON FUNCTION public.enforce_app_publication_invariant() FROM PUBLIC, anon, authenticated;
