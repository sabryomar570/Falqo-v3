REVOKE EXECUTE ON FUNCTION public.record_file_download(UUID, UUID) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.record_file_download(UUID, UUID) TO service_role;
