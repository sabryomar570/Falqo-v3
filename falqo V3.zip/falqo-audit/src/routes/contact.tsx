import { createFileRoute, Link } from "@tanstack/react-router";
import { LifeBuoy, Mail, ShieldAlert } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "تواصل معنا — FALQO" },
      {
        name: "description",
        content: "قنوات التواصل مع فريق FALQO للدعم، البلاغات الأمنية، وطلبات الناشرين.",
      },
      { property: "og:title", content: "تواصل معنا — FALQO" },
      { property: "og:description", content: "اتصل بفريق FALQO للدعم أو للإبلاغ عن مشكلة أمنية." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

const CHANNELS = [
  {
    icon: Mail,
    title: "الدعم العام",
    body: "أسئلة الحساب، التحميل، أو المراجعات.",
    value: "support@falqo.app",
  },
  {
    icon: ShieldAlert,
    title: "البلاغات الأمنية",
    body: "ملف مشبوه أو ثغرة في المنصة — أولوية قصوى.",
    value: "security@falqo.app",
  },
  {
    icon: LifeBuoy,
    title: "الناشرون",
    body: "استفسارات المراجعة أو حالة تطبيق مرفوض.",
    value: "publishers@falqo.app",
  },
] as const;

function ContactPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 pb-20 pt-12 sm:px-6">
      <h1 className="text-3xl font-extrabold sm:text-4xl">تواصل معنا</h1>
      <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
        عناوين البريد التالية عناوين أولية قابلة للتعديل. للإبلاغ عن تطبيق بعينه استخدم زر «إبلاغ»
        في صفحة التطبيق حتى يصل البلاغ مباشرة إلى فريق المراجعة.
      </p>

      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {CHANNELS.map((channel) => (
          <div key={channel.title} className="glass rounded-4xl p-6">
            <span className="grid size-10 place-items-center rounded-2xl bg-muted text-muted-foreground">
              <channel.icon className="size-4" />
            </span>
            <h2 className="mt-3 text-base font-bold">{channel.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{channel.body}</p>
            <a
              href={`mailto:${channel.value}`}
              className="mt-3 inline-block text-sm font-semibold text-primary"
            >
              {channel.value}
            </a>
          </div>
        ))}
        <div className="glass rounded-4xl p-6">
          <h2 className="text-base font-bold">صفحات مفيدة</h2>
          <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground">
            <li>
              <Link to="/help" className="font-semibold text-primary">
                مركز المساعدة
              </Link>
            </li>
            <li>
              <Link to="/trust-safety" className="font-semibold text-primary">
                معايير الأمان
              </Link>
            </li>
            <li>
              <Link to="/community-guidelines" className="font-semibold text-primary">
                إرشادات المجتمع
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
