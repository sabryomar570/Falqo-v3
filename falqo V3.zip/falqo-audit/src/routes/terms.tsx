import { createFileRoute } from "@tanstack/react-router";

import { LegalPage } from "@/components/LegalPage";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "شروط الاستخدام — FALQO" },
      {
        name: "description",
        content: "قواعد استخدام متجر FALQO للمستخدمين والناشرين ومسؤوليات كل طرف.",
      },
      { property: "og:title", content: "شروط الاستخدام — FALQO" },
      {
        property: "og:description",
        content: "القواعد التي تنظّم رفع التطبيقات وتحميلها على FALQO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LegalPage
      title="شروط الاستخدام"
      intro="باستخدامك FALQO فأنت توافق على القواعد التالية التي تحفظ حقوق المستخدمين والناشرين."
      updated="أغسطس 2026"
      sections={[
        {
          heading: "الحساب",
          body: [
            "التسجيل يتم عبر جوجل فقط، وأنت مسؤول عن نشاط حسابك.",
            "يُمنع انتحال شخصية أو جهة أخرى.",
          ],
        },
        {
          heading: "للناشرين",
          body: [
            "أنت مالك التطبيق الذي ترفعه أو تملك حق نشره.",
            "يُمنع رفع ملفات ضارة أو مضللة أو تنتهك حقوق الآخرين.",
            "كل تطبيق يمر بمراجعة بشرية وفحص أمني قبل النشر، ويمكن رفضه أو إزالته مع بيان السبب.",
          ],
        },
        {
          heading: "للمستخدمين",
          body: [
            "التحميل حاليًا مجاني، وأنت مسؤول عن تثبيت أي ملف على جهازك.",
            "المراجعات يجب أن تكون حقيقية ومحترمة، ولا يُسمح بالتقييمات المزيفة.",
          ],
        },
        {
          heading: "حدود المسؤولية",
          body: [
            "نبذل جهدًا معقولًا في المراجعة والفحص لكننا لا نضمن خلو أي ملف من كل المخاطر.",
            "قد نعدّل هذه الشروط، وسنوضح تاريخ آخر تحديث أعلى الصفحة.",
          ],
        },
      ]}
    />
  ),
});
