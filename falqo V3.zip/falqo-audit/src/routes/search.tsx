import { createFileRoute, redirect } from "@tanstack/react-router";
import { z } from "zod";

const schema = z.object({ q: z.string().optional() });

export const Route = createFileRoute("/search")({
  validateSearch: schema,
  beforeLoad: ({ search }) => {
    throw redirect({ to: "/browse", search: search.q ? { q: search.q } : {} });
  },
  component: () => null,
});
