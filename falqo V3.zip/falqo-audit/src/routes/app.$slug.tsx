import { useState } from "react";
import { createFileRoute, Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CalendarClock, Download, HardDrive, ShieldCheck, Tag } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

import { CategoryBadge } from "@/components/CategoryBadge";
import { ReportAppDialog } from "@/components/ReportAppDialog";
import { WishlistButton } from "@/components/WishlistButton";
import { SignedImage } from "@/components/SignedImage";
import { StarPicker, StarRating } from "@/components/StarRating";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { saveIntendedPath, useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { requestAppDownload } from "@/lib/downloads.functions";
import { appBySlugQuery, reviewsQuery } from "@/lib/marketplace";
import { BUCKETS, formatBytes, getSignedUrls } from "@/lib/storage";

export const Route = createFileRoute("/app/$slug")({
  loader: ({ params, context }) => context.queryClient.ensureQueryData(appBySlugQuery(params.slug)),
  head: ({ loaderData, params }) => {
    const app = loaderData ?? null;
    const title = app ? `${app.name} — FALQO` : `${params.slug} — FALQO`;
    const description = app
      ? `${app.tagline || app.description.slice(0, 150)} — تحميل مجاني بعد اجتياز الفحص الأمني على FALQO.`
      : "تفاصيل التطبيق: لقطات الشاشة، الحجم، آخر تحديث، التقييمات ومراجعات المستخدمين.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  errorComponent: () => <AppUnavailable />,
  notFoundComponent: () => <AppUnavailable />,
  component: AppDetail,
});

const reviewSchema = z.object({
  rating: z.number().int().min(1).max(5),
  comment: z.string().trim().max(1000).optional(),
});

function AppDetail() {
  const { slug } = Route.useParams();
  const app = useQuery(appBySlugQuery(slug));
  const reviews = useQuery(reviewsQuery(app.data?.id));
  const shots = useQuery({
    queryKey: ["shots", app.data?.id],
    queryFn: () => getSignedUrls(BUCKETS.screenshots, app.data?.screenshots ?? []),
    enabled: Boolean(app.data?.screenshots?.length),
    staleTime: 1000 * 60 * 30,
  });
  const startDownload = useServerFn(requestAppDownload);
  const { user } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const queryClient = useQueryClient();

  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  const submitReview = useMutation({
    mutationFn: async () => {
      const parsed = reviewSchema.parse({ rating, comment: comment.trim() || undefined });
      const { error } = await supabase.from("reviews").upsert(
        {
          app_id: app.data!.id,
          user_id: user!.id,
          rating: parsed.rating,
          comment: parsed.comment ?? null,
        },
        { onConflict: "app_id,user_id" },
      );
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تم حفظ تقييمك");
      setComment("");
      void queryClient.invalidateQueries({ queryKey: ["reviews"] });
      void queryClient.invalidateQueries({ queryKey: ["apps"] });
    },
    onError: () => toast.error("تعذّر إرسال التقييم"),
  });

  const download = useMutation({
    mutationFn: () => startDownload({ data: { slug } }),
    onSuccess: (result) => {
      if (!result.ok) {
        toast.error(
          result.reason === "no_file"
            ? "ملف التحميل غير متاح حاليًا"
            : result.reason === "not_available"
              ? "التطبيق قيد المراجعة أو الفحص الأمني"
              : "التطبيق غير موجود",
        );
        return;
      }
      void queryClient.invalidateQueries({ queryKey: ["apps"] });
      void queryClient.invalidateQueries({ queryKey: ["downloads"] });
      window.location.href = result.url;
    },
    onError: () => toast.error("تعذّر بدء التحميل، حاول مرة أخرى"),
  });

  if (app.isLoading) {
    return <div className="mx-auto mt-16 h-64 max-w-4xl animate-pulse rounded-4xl glass" />;
  }

  if (!app.data) {
    return <AppUnavailable />;
  }

  const data = app.data;

  return (
    <div className="mx-auto max-w-4xl px-4 pb-10 pt-10 sm:px-6">
      <div className="glass-strong rounded-4xl p-6 sm:p-8">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
          <SignedImage
            bucket={BUCKETS.icons}
            path={data.icon_url}
            alt={data.name}
            className="size-24 rounded-3xl object-cover shadow-[var(--shadow-float)] sm:size-28"
          />
          <div className="min-w-0 flex-1">
            <CategoryBadge category={data.categories} />
            <h1 className="mt-2 text-3xl font-extrabold">{data.name}</h1>
            {data.tagline && <p className="mt-1 text-sm text-muted-foreground">{data.tagline}</p>}
            <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <StarRating value={Number(data.rating_avg)} size={15} />
                {Number(data.rating_avg).toFixed(1)} ({data.rating_count})
              </span>
              <span className="flex items-center gap-1">
                <Download className="size-4" />
                {data.downloads_count}
              </span>
              <span className="glass-subtle flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold text-success-foreground">
                <ShieldCheck className="size-3.5" />
                اجتاز الفحص الأمني
              </span>
            </div>
          </div>
          <div className="flex w-full flex-col items-stretch gap-2 sm:w-auto sm:items-end">
            <Button
              variant="hero"
              size="lg"
              className="w-full sm:w-auto"
              disabled={download.isPending}
              onClick={() => download.mutate()}
            >
              <Download />
              تحميل مجاني
            </Button>
            <div className="flex items-center justify-center gap-1 sm:justify-end">
              <WishlistButton appId={data.id} />
              <ReportAppDialog appId={data.id} />
            </div>
          </div>
        </div>

        <dl className="mt-6 grid grid-cols-2 gap-3 border-t hairline pt-5 text-sm sm:grid-cols-4">
          <Meta
            icon={<HardDrive className="size-4" />}
            label="حجم الملف"
            value={formatBytes(Number(data.file_size))}
          />
          <Meta icon={<Tag className="size-4" />} label="الإصدار" value={data.version} />
          <Meta
            icon={<CalendarClock className="size-4" />}
            label="آخر تحديث"
            value={new Date(data.updated_at).toLocaleDateString("ar-EG")}
          />
          <Meta
            icon={<Download className="size-4" />}
            label="التحميلات"
            value={String(data.downloads_count)}
          />
        </dl>
      </div>

      {(shots.data?.length ?? 0) > 0 && (
        <section className="mt-8">
          <h2 className="text-xl font-bold">لقطات الشاشة</h2>
          <div className="no-scrollbar mt-4 flex gap-3 overflow-x-auto pb-2">
            {(shots.data ?? []).map((url, index) => (
              <img
                key={url}
                src={url}
                alt={`${data.name} - لقطة ${index + 1}`}
                loading="lazy"
                className="h-64 w-auto rounded-3xl border border-glass-border object-cover shadow-[var(--shadow-float)]"
              />
            ))}
          </div>
        </section>
      )}

      <section className="glass mt-8 rounded-3xl p-6">
        <h2 className="text-xl font-bold">عن التطبيق</h2>
        <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
          {data.description || "لا يوجد وصف."}
        </p>
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-bold">المراجعات</h2>

        {user ? (
          <div className="glass mt-4 rounded-3xl p-5">
            <StarPicker value={rating} onChange={setRating} />
            <Textarea
              value={comment}
              maxLength={1000}
              onChange={(event) => setComment(event.target.value)}
              placeholder="شاركنا تجربتك مع التطبيق..."
              className="mt-3 rounded-2xl bg-card/70"
            />
            <Button
              variant="hero"
              className="mt-3"
              disabled={submitReview.isPending}
              onClick={() => submitReview.mutate()}
            >
              إرسال التقييم
            </Button>
          </div>
        ) : (
          <div className="glass mt-4 flex flex-wrap items-center justify-between gap-3 rounded-3xl p-5">
            <p className="text-sm text-muted-foreground">سجّل الدخول لكتابة مراجعة.</p>
            <Button
              variant="glass"
              onClick={() => {
                saveIntendedPath(pathname);
                void navigate({ to: "/auth" });
              }}
            >
              تسجيل الدخول
            </Button>
          </div>
        )}

        <div className="mt-4 space-y-3">
          {(reviews.data ?? []).map((review) => (
            <article key={review.id} className="glass rounded-3xl p-5">
              <div className="flex items-center gap-3">
                {review.profiles?.avatar_url ? (
                  <img
                    src={review.profiles.avatar_url}
                    alt={review.profiles.full_name ?? "مستخدم"}
                    className="size-9 rounded-full object-cover"
                  />
                ) : (
                  <span className="size-9 rounded-full bg-muted" />
                )}
                <div>
                  <p className="text-sm font-semibold">{review.profiles?.full_name ?? "مستخدم"}</p>
                  <StarRating value={review.rating} />
                </div>
                <span className="ms-auto text-xs text-muted-foreground">
                  {new Date(review.created_at).toLocaleDateString("ar-EG")}
                </span>
              </div>
              {review.comment && (
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {review.comment}
                </p>
              )}
            </article>
          ))}
          {(reviews.data ?? []).length === 0 && (
            <p className="glass rounded-3xl p-6 text-center text-sm text-muted-foreground">
              لا توجد مراجعات بعد.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}

function Meta({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div>
      <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
        {icon}
        {label}
      </dt>
      <dd className="mt-1 text-sm font-semibold">{value}</dd>
    </div>
  );
}

function AppUnavailable() {
  return (
    <div className="mx-auto max-w-md px-4 py-24 text-center">
      <div className="glass rounded-3xl p-10">
        <h1 className="text-xl font-bold">التطبيق غير متاح</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          قد يكون التطبيق قيد المراجعة أو تمت إزالته.
        </p>
        <Button variant="glass" className="mt-6" asChild>
          <Link to="/browse">استكشف تطبيقات أخرى</Link>
        </Button>
      </div>
    </div>
  );
}
