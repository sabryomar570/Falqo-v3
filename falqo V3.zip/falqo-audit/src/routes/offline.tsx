import { createFileRoute, Link } from "@tanstack/react-router";
import { CloudOff } from "lucide-react";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/offline")({
  head: () => ({
    meta: [
      { title: "لا يوجد اتصال — FALQO" },
      {
        name: "description",
        content: "تعذّر الاتصال بالإنترنت. يمكنك المحاولة مرة أخرى بعد استعادة الاتصال.",
      },
      { property: "og:title", content: "لا يوجد اتصال — FALQO" },
      { property: "og:description", content: "شاشة FALQO عند انقطاع الاتصال." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: OfflinePage,
});

function OfflinePage() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-4 text-center">
      <span className="grid size-14 place-items-center rounded-3xl bg-muted text-muted-foreground">
        <CloudOff className="size-6" />
      </span>
      <h1 className="mt-5 text-2xl font-extrabold">لا يوجد اتصال بالإنترنت</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        FALQO يعمل الآن من الذاكرة المؤقتة. الصفحات التي زرتها سابقًا قد تكون متاحة، أما التحميل
        ورفع التطبيقات فيحتاج اتصالًا.
      </p>
      <div className="mt-6 flex gap-2">
        <Button variant="hero" onClick={() => window.location.reload()}>
          إعادة المحاولة
        </Button>
        <Button variant="glass" asChild>
          <Link to="/">الصفحة الرئيسية</Link>
        </Button>
      </div>
    </div>
  );
}
