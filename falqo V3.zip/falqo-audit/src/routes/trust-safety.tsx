import { createFileRoute } from "@tanstack/react-router";
import { FileSearch, ShieldCheck, UserCheck, Workflow } from "lucide-react";

export const Route = createFileRoute("/trust-safety")({
  head: () => ({
    meta: [
      { title: "معايير الأمان — FALQO" },
      {
        name: "description",
        content:
          "كيف يفحص FALQO كل تطبيق قبل النشر: قائمة انتظار فحص، تكامل مع خدمة فحص أمني خارجية، ومراجعة بشرية.",
      },
      { property: "og:title", content: "معايير الأمان — FALQO" },
      {
        property: "og:description",
        content: "مراحل مراجعة وفحص التطبيقات على FALQO قبل ظهورها في المتجر.",
      },
    ],
  }),
  component: TrustSafety,
});

const STEPS = [
  {
    icon: Workflow,
    title: "قائمة انتظار الفحص",
    body: "بمجرد رفع أي ملف، يُسجَّل في قائمة انتظار فحص داخلية ولا يُنشر في المتجر مباشرة.",
  },
  {
    icon: FileSearch,
    title: "فحص أمني خارجي",
    body: "الملفات تُمرَّر إلى خدمة فحص أمني متخصصة (VirusTotal / MobSF) عبر تكامل من جهة الخادم، ولا يتم أي فحص وهمي داخل الواجهة.",
  },
  {
    icon: UserCheck,
    title: "مراجعة بشرية",
    body: "يعاين فريق المراجعة بيانات التطبيق ونتيجة الفحص، ويقرر القبول أو الرفض مع ذكر السبب للناشر.",
  },
  {
    icon: ShieldCheck,
    title: "نشر بعد الموافقة فقط",
    body: "لا يظهر التطبيق للمستخدمين إلا بعد اجتياز الفحص والحصول على الموافقة النهائية.",
  },
];

function TrustSafety() {
  return (
    <div className="mx-auto max-w-4xl px-4 pb-10 pt-12 sm:px-6">
      <h1 className="text-4xl font-extrabold sm:text-5xl">معايير الأمان</h1>
      <p className="mt-4 max-w-2xl text-base text-muted-foreground">
        هذا النص مؤقت (placeholder) وسيتم استبداله بالنص النهائي لسياسة الأمان. المبدأ ثابت: لا يصل
        إليك أي ملف قبل أن يمر بمراحل الفحص والمراجعة التالية.
      </p>

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        {STEPS.map((step) => (
          <div key={step.title} className="glass rounded-3xl p-6">
            <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-b from-primary-glow to-primary text-primary-foreground">
              <step.icon className="size-5" />
            </span>
            <h2 className="mt-4 text-lg font-bold">{step.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
          </div>
        ))}
      </div>

      <div className="glass-strong mt-8 rounded-3xl p-6">
        <h2 className="text-lg font-bold">الإبلاغ عن تطبيق</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          إذا لاحظت سلوكًا مريبًا في أي تطبيق منشور، أبلغنا وسنعيد إدخاله في مسار الفحص فورًا مع
          إمكانية إخفائه مؤقتًا من المتجر.
        </p>
      </div>
    </div>
  );
}
