import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { takeIntendedPath, useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "تسجيل الدخول — FALQO" },
      {
        name: "description",
        content: "سجّل الدخول إلى FALQO باستخدام حساب Google للوصول إلى ملفك الشخصي ونشر تطبيقاتك.",
      },
      { property: "og:title", content: "تسجيل الدخول — FALQO" },
      { property: "og:description", content: "تسجيل دخول سريع وآمن عبر Google." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { user, loading, signInWithGoogle } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      const intended = takeIntendedPath();
      void navigate({ to: intended && intended !== "/auth" ? intended : "/profile" });
    }
  }, [loading, user, navigate]);

  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 pb-16 pt-20">
      <div className="glass-strong w-full rounded-4xl p-8 text-center">
        <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-gradient-to-b from-primary-glow to-primary text-primary-foreground shadow-[var(--glow-primary)]">
          <ShieldCheck className="size-6" />
        </span>
        <h1 className="mt-5 text-2xl font-bold">مرحبًا بك في FALQO</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          تسجيل الدخول والتسجيل يتمّان حاليًا عبر حساب Google فقط.
        </p>

        <Button
          variant="hero"
          size="lg"
          className="mt-7 w-full"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            const result = await signInWithGoogle();
            if (result.error) {
              toast.error("تعذّر تسجيل الدخول، حاول مرة أخرى.");
              setBusy(false);
            }
          }}
        >
          {busy ? "جارٍ التحويل..." : "متابعة باستخدام Google"}
        </Button>

        <p className="mt-6 text-xs leading-relaxed text-muted-foreground">
          بالمتابعة أنت توافق على معايير الأمان وسياسة النشر في FALQO.
        </p>
      </div>
    </div>
  );
}
