import { useEffect } from "react";
import { createFileRoute, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";

import { saveIntendedPath, useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (!loading && !user) {
      saveIntendedPath(pathname);
      void navigate({ to: "/auth" });
    }
  }, [loading, user, pathname, navigate]);

  if (loading || !user) {
    return <div className="mx-auto mt-20 h-64 max-w-3xl animate-pulse rounded-4xl glass" />;
  }

  return <Outlet />;
}
