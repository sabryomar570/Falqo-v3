import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUp, MessagesSquare, Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { EmptyState } from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth, saveIntendedPath } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import {
  forumRepliesQuery,
  forumTopicQuery,
  myTopicVotesQuery,
  toggleTopicVote,
} from "@/lib/forum";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/community/$topicId")({
  head: () => ({
    meta: [
      { title: "موضوع في مجتمع FALQO" },
      {
        name: "description",
        content: "نقاش من مجتمع FALQO مع ردود المستخدمين والتصويت على الموضوع.",
      },
      { property: "og:title", content: "موضوع في مجتمع FALQO" },
      { property: "og:description", content: "شارك رأيك وساعد بقية المستخدمين." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TopicPage,
});

function TopicPage() {
  const { topicId } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const topic = useQuery(forumTopicQuery(topicId));
  const replies = useQuery(forumRepliesQuery(topicId));
  const votes = useQuery(myTopicVotesQuery);
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);

  const voted = (votes.data ?? []).includes(topicId);

  const requireAuth = () => {
    if (user) return true;
    saveIntendedPath(`/community/${topicId}`);
    void navigate({ to: "/auth" });
    return false;
  };

  const onVote = async () => {
    if (!requireAuth() || !user) return;
    try {
      await toggleTopicVote(topicId, user.id, voted);
      await queryClient.invalidateQueries({ queryKey: ["forum"] });
    } catch {
      toast.error("تعذّر تسجيل التصويت");
    }
  };

  const onReply = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!requireAuth() || !user || !body.trim()) return;
    setBusy(true);
    const { error } = await supabase
      .from("forum_replies")
      .insert({ topic_id: topicId, author_id: user.id, body: body.trim() });
    setBusy(false);
    if (error) {
      toast.error("تعذّر إرسال الرد");
      return;
    }
    setBody("");
    await queryClient.invalidateQueries({ queryKey: ["forum"] });
  };

  if (topic.isLoading) {
    return (
      <div className="mx-auto max-w-3xl px-4 pt-10">
        <div className="glass h-52 animate-pulse rounded-4xl" />
      </div>
    );
  }

  if (!topic.data) {
    return (
      <div className="mx-auto max-w-3xl px-4 pb-16 pt-10">
        <EmptyState
          icon={MessagesSquare}
          title="الموضوع غير موجود"
          action={
            <Button variant="hero" asChild>
              <Link to="/community">عودة للمجتمع</Link>
            </Button>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 pb-16 pt-10 sm:px-6">
      <article className="glass-strong rounded-4xl p-6 sm:p-8">
        <p className="text-xs text-muted-foreground">
          {topic.data.forum_categories?.name_ar ?? "نقاش"}
        </p>
        <h1 className="mt-1 text-2xl font-extrabold sm:text-3xl">{topic.data.title}</h1>
        <p className="mt-1 text-xs text-muted-foreground">
          {topic.data.author?.full_name ?? "مستخدم"}
        </p>
        <p className="mt-5 whitespace-pre-wrap text-sm leading-relaxed">{topic.data.body}</p>
        <div className="mt-6 flex items-center gap-2">
          <Button
            variant={voted ? "hero" : "glass"}
            size="sm"
            onClick={() => void onVote()}
            className={cn(voted && "shadow-[var(--glow-primary)]")}
          >
            <ArrowUp />
            {topic.data.votes_count} تصويت
          </Button>
          <span className="text-xs text-muted-foreground">{topic.data.replies_count} رد</span>
        </div>
      </article>

      <section className="mt-8 space-y-3">
        <h2 className="text-xl font-bold">الردود</h2>
        {(replies.data ?? []).map((reply) => (
          <div key={reply.id} className="glass rounded-3xl p-5">
            <p className="text-xs text-muted-foreground">{reply.author?.full_name ?? "مستخدم"}</p>
            <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{reply.body}</p>
          </div>
        ))}
        {(replies.data ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">لا توجد ردود بعد — كن أول من يشارك.</p>
        ) : null}
      </section>

      {topic.data.is_locked ? (
        <p className="mt-6 text-sm text-muted-foreground">هذا الموضوع مغلق للردود.</p>
      ) : (
        <form onSubmit={onReply} className="glass mt-6 space-y-3 rounded-3xl p-5">
          <Textarea
            value={body}
            onChange={(event) => setBody(event.target.value)}
            placeholder={user ? "اكتب ردك…" : "سجّل الدخول للمشاركة"}
            rows={4}
          />
          <Button type="submit" variant="hero" disabled={busy || !body.trim()}>
            <Send />
            إرسال الرد
          </Button>
        </form>
      )}
    </div>
  );
}
