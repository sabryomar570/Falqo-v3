import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Download, FileDown, MessageSquare, Search, Star } from "lucide-react";

import { AppCard } from "@/components/AppCard";
import { CategoryBadge } from "@/components/CategoryBadge";
import { CategoryArt } from "@/components/CategoryIcon";
import { SignedImage } from "@/components/SignedImage";
import { StarRating } from "@/components/StarRating";
import { Button } from "@/components/ui/button";
import { publicFilesQuery } from "@/lib/files";
import { forumTopicsQuery } from "@/lib/forum";
import { browseAppsQuery, categoriesQuery, type AppRow } from "@/lib/marketplace";
import { BUCKETS, formatBytes } from "@/lib/storage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FALQO — تطبيقات وملفات ومجتمع عربي" },
      {
        name: "description",
        content: "حمّل تطبيقات مفحوصة، شارك ملفاتك برابط واحد، وناقش مع المجتمع. مجاني.",
      },
      { property: "og:title", content: "FALQO — تطبيقات وملفات ومجتمع عربي" },
      { property: "og:description", content: "حمّل. شارك. ناقش. في مكان واحد." },
    ],
  }),
  component: Home,
});

function Home() {
  const featured = useQuery(browseAppsQuery({ featuredOnly: true, limit: 1 }));
  const newest = useQuery(browseAppsQuery({ sort: "newest", limit: 12 }));
  const popular = useQuery(browseAppsQuery({ sort: "downloads", limit: 10 }));
  const topRated = useQuery(browseAppsQuery({ sort: "rating", limit: 10 }));
  const categories = useQuery(categoriesQuery);
  const files = useQuery(publicFilesQuery(""));
  const topics = useQuery(forumTopicsQuery(undefined, "latest"));

  const spotlight = featured.data?.[0] ?? popular.data?.[0] ?? newest.data?.[0];
  const rated = (topRated.data ?? []).filter((app) => app.rating_count > 0);
  const hasApps = (newest.data?.length ?? 0) > 0;

  return (
    <div className="mx-auto max-w-6xl px-4 pb-10 pt-8 sm:px-6 sm:pt-12">
      {/* 1. سؤال + فعل فوري: البحث أول ما تلمسه العين */}
      <section className="text-center">
        <h1 className="text-3xl font-extrabold sm:text-5xl">ماذا تريد أن تحمّل اليوم؟</h1>
        <SearchBar />
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          {(categories.data ?? []).map((category) => (
            <Link
              key={category.id}
              to="/browse"
              search={{ category: category.slug }}
              className="glass rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors hover:bg-accent"
            >
              {category.name_ar}
            </Link>
          ))}
        </div>
      </section>

      {/* 2. تركيز واحد: بطاقة اليوم */}
      {spotlight && (
        <section className="mt-10">
          <Eyebrow>اختيار اليوم</Eyebrow>
          <Link
            to="/app/$slug"
            params={{ slug: spotlight.slug }}
            className="glass-strong lift mt-3 block overflow-hidden rounded-4xl p-6 sm:p-8"
          >
            <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
              <SignedImage
                bucket={BUCKETS.icons}
                path={spotlight.icon_url}
                alt={spotlight.name}
                className="size-24 rounded-3xl object-cover shadow-[var(--shadow-float)] sm:size-32"
              />
              <div className="min-w-0 flex-1">
                <CategoryBadge category={spotlight.categories} />
                <h2 className="mt-2 truncate text-2xl font-bold sm:text-4xl">{spotlight.name}</h2>
                <p className="mt-2 line-clamp-2 text-sm text-muted-foreground sm:text-base">
                  {spotlight.tagline || spotlight.description}
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <StarRating value={Number(spotlight.rating_avg)} size={16} />
                    {Number(spotlight.rating_avg).toFixed(1)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Download className="size-4" />
                    {spotlight.downloads_count}
                  </span>
                  <span>{formatBytes(Number(spotlight.file_size))}</span>
                </div>
              </div>
              <span className="inline-flex h-11 shrink-0 items-center justify-center gap-2 self-start rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground shadow-[var(--glow-primary)] sm:self-center">
                تحميل
                <ArrowLeft className="size-4" />
              </span>
            </div>
          </Link>
        </section>
      )}

      {/* 3. دليل اجتماعي: قوائم مرقّمة */}
      {hasApps && (
        <section className="mt-14 grid gap-8 lg:grid-cols-2">
          <RankedList
            title="الأكثر تحميلًا"
            apps={popular.data ?? []}
            sort="downloads"
            metric={(app) => (
              <>
                <Download className="size-3.5" />
                {app.downloads_count}
              </>
            )}
          />
          <RankedList
            title="الأعلى تقييمًا"
            apps={rated.length ? rated : (popular.data ?? []).slice().reverse()}
            sort="rating"
            metric={(app) => (
              <>
                <Star className="size-3.5 fill-current text-primary" />
                {Number(app.rating_avg).toFixed(1)}
              </>
            )}
          />
        </section>
      )}

      {/* 4. جديد */}
      <section className="mt-14">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-bold sm:text-3xl">وصل حديثًا</h2>
          <Link
            to="/browse"
            search={{ sort: "newest" }}
            className="text-sm font-semibold text-primary"
          >
            الكل
          </Link>
        </div>
        {newest.isLoading ? (
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((key) => (
              <div key={key} className="glass h-36 animate-pulse rounded-3xl" />
            ))}
          </div>
        ) : !hasApps ? (
          <div className="glass mt-5 rounded-3xl p-8 text-center">
            <p className="font-semibold">لا تطبيقات بعد.</p>
            <Button variant="hero" size="sm" className="mt-4" asChild>
              <Link to="/publisher">كن أول ناشر</Link>
            </Button>
          </div>
        ) : (
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {(newest.data ?? []).slice(0, 6).map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
        )}
      </section>

      {/* 5. التصنيفات بالفن */}
      <section className="mt-14">
        <h2 className="text-2xl font-bold sm:text-3xl">تصفّح حسب النوع</h2>
        <div className="mt-5 grid grid-cols-3 gap-3 lg:grid-cols-6">
          {(categories.data ?? []).map((category) => (
            <Link
              key={category.id}
              to="/browse"
              search={{ category: category.slug }}
              className="glass lift rounded-3xl p-4 text-center"
            >
              <CategoryArt category={category} className="mx-auto size-14" />
              <p className="mt-3 text-sm font-semibold">{category.name_ar}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* 6. نبض حي: ملفات + نقاشات */}
      <section className="mt-14 grid gap-4 lg:grid-cols-2">
        <PulseCard
          title="آخر الملفات"
          icon={<FileDown className="size-4 text-primary" />}
          to="/files"
          empty="ارفع ملفًا واحصل على رابط."
          items={(files.data ?? []).slice(0, 5).map((file) => ({
            id: file.id,
            title: file.title,
            meta: `${formatBytes(Number(file.file_size))} · ${file.downloads_count} تحميل`,
            link: (
              <Link to="/files/$slug" params={{ slug: file.slug }} className="absolute inset-0" />
            ),
          }))}
        />
        <PulseCard
          title="يُناقَش الآن"
          icon={<MessageSquare className="size-4 text-primary" />}
          to="/community"
          empty="ابدأ أول نقاش."
          items={(topics.data ?? []).slice(0, 5).map((topic) => ({
            id: topic.id,
            title: topic.title,
            meta: `${topic.replies_count} رد · ${topic.votes_count} تصويت`,
            link: (
              <Link
                to="/community/$topicId"
                params={{ topicId: topic.id }}
                className="absolute inset-0"
              />
            ),
          }))}
        />
      </section>

      {/* 7. للناشرين — في النهاية، بعد أن رأى القيمة */}
      <section className="glass mt-14 flex flex-col items-center justify-between gap-4 rounded-3xl p-6 sm:flex-row">
        <div>
          <h2 className="text-xl font-bold">عندك تطبيق؟</h2>
          <p className="mt-1 text-sm text-muted-foreground">ارفعه الآن. يُنشر خلال ساعات.</p>
        </div>
        <Button variant="hero" asChild>
          <Link to="/publisher/upload">
            انشر
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
      </section>
    </div>
  );
}

function SearchBar() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  return (
    <form
      className="glass-strong mx-auto mt-6 flex max-w-xl items-center gap-2 rounded-full p-1.5 ps-4"
      onSubmit={(event) => {
        event.preventDefault();
        navigate({ to: "/browse", search: q.trim() ? { q: q.trim() } : {} });
      }}
    >
      <Search className="size-5 shrink-0 text-muted-foreground" />
      <input
        value={q}
        onChange={(event) => setQ(event.target.value)}
        placeholder="اسم تطبيق أو ملف…"
        aria-label="بحث"
        className="h-10 min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground"
      />
      <Button type="submit" variant="hero" size="sm" className="rounded-full">
        بحث
      </Button>
    </form>
  );
}

function Eyebrow({ children }: { children: React.ReactNode }) {
  return <span className="text-xs font-bold uppercase tracking-wide text-primary">{children}</span>;
}

function RankedList({
  title,
  apps,
  sort,
  metric,
}: {
  title: string;
  apps: AppRow[];
  sort: "downloads" | "rating";
  metric: (app: AppRow) => React.ReactNode;
}) {
  return (
    <div>
      <div className="flex items-end justify-between">
        <h2 className="text-2xl font-bold sm:text-3xl">{title}</h2>
        <Link to="/browse" search={{ sort }} className="text-sm font-semibold text-primary">
          الكل
        </Link>
      </div>
      <ol className="glass mt-5 divide-y divide-[var(--glass-hairline)] rounded-3xl px-2">
        {apps.slice(0, 5).map((app, index) => (
          <li key={app.id}>
            <Link
              to="/app/$slug"
              params={{ slug: app.slug }}
              className="flex items-center gap-3 rounded-2xl px-2 py-3 transition-colors hover:bg-accent"
            >
              <span className="w-6 text-center text-lg font-extrabold text-muted-foreground">
                {index + 1}
              </span>
              <SignedImage
                bucket={BUCKETS.icons}
                path={app.icon_url}
                alt={app.name}
                className="size-12 shrink-0 rounded-xl object-cover shadow-[var(--shadow-soft)]"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[15px] font-semibold">{app.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {app.categories?.name_ar ?? app.platform}
                </p>
              </div>
              <span className="flex shrink-0 items-center gap-1 text-xs font-semibold text-muted-foreground">
                {metric(app)}
              </span>
            </Link>
          </li>
        ))}
      </ol>
    </div>
  );
}

function PulseCard({
  title,
  icon,
  to,
  empty,
  items,
}: {
  title: string;
  icon: React.ReactNode;
  to: "/files" | "/community";
  empty: string;
  items: { id: string; title: string; meta: string; link: React.ReactNode }[];
}) {
  return (
    <div className="glass rounded-3xl p-5">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-bold">
          {icon}
          {title}
        </h2>
        <Link to={to} className="text-sm font-semibold text-primary">
          الكل
        </Link>
      </div>
      {items.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">{empty}</p>
      ) : (
        <ul className="mt-3 divide-y divide-[var(--glass-hairline)]">
          {items.map((item) => (
            <li key={item.id} className="relative flex items-center justify-between gap-3 py-2.5">
              <span className="truncate text-sm font-medium">{item.title}</span>
              <span className="shrink-0 text-xs text-muted-foreground">{item.meta}</span>
              {item.link}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
