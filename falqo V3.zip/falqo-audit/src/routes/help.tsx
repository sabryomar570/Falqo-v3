import { createFileRoute, Link } from "@tanstack/react-router";

import { LegalPage } from "@/components/LegalPage";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "مركز المساعدة — FALQO" },
      {
        name: "description",
        content: "أجوبة سريعة عن التحميل، رفع التطبيقات، حالة المراجعة، والفحص الأمني في FALQO.",
      },
      { property: "og:title", content: "مركز المساعدة — FALQO" },
      { property: "og:description", content: "دليل مختصر لاستخدام متجر FALQO كمستخدم أو ناشر." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LegalPage
      title="مركز المساعدة"
      intro="أسرع الأجوبة عن أكثر الأسئلة تكرارًا داخل FALQO."
      sections={[
        {
          heading: "كيف أحمّل تطبيقًا؟",
          body: [
            "افتح صفحة التطبيق ثم اضغط زر التحميل. يُسجَّل التحميل في حسابك ويُنشأ رابط تنزيل موقّت وآمن.",
            "تظهر في المتجر العام فقط التطبيقات المقبولة والتي اجتازت الفحص الأمني.",
          ],
        },
        {
          heading: "كيف أصبح ناشرًا؟",
          body: [
            "من صفحة الملف الشخصي اضغط «صير ناشر»، ثم ارفع تطبيقك من لوحة الناشر.",
            "كل تطبيق جديد يبدأ بحالة «قيد المراجعة» ولا يُنشر تلقائيًا.",
          ],
        },
        {
          heading: "لماذا تطبيقي ما زال قيد المراجعة؟",
          body: [
            "المراجعة تتضمن تحقّقًا بشريًا وفحصًا أمنيًا للملف. تجد الحالة الحالية وسبب أي رفض في لوحة الناشر.",
          ],
        },
        {
          heading: "تثبيت FALQO كتطبيق",
          body: [
            "اضغط زر «تثبيت التطبيق» في الشريط العلوي على المتصفحات المدعومة.",
            "على iPhone: من Safari اختر «مشاركة» ثم «إضافة إلى الشاشة الرئيسية».",
          ],
        },
      ]}
      footer={
        <div className="glass flex flex-col items-center gap-3 rounded-4xl p-6 text-center">
          <p className="text-sm text-muted-foreground">لم تجد إجابتك؟</p>
          <Button variant="hero" asChild>
            <Link to="/contact">تواصل معنا</Link>
          </Button>
        </div>
      }
    />
  ),
});
