import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/apps/$category")({
  beforeLoad: ({ params }) => {
    throw redirect({ to: "/browse", search: { category: params.category } });
  },
  component: () => null,
});
