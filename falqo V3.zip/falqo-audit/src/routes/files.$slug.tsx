import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Copy, Download, FileArchive, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { EmptyState } from "@/components/EmptyState";
import { ScanPill } from "@/components/StatusPill";
import { Button } from "@/components/ui/button";
import { fileBySlugQuery } from "@/lib/files";
import { requestSharedFileDownload } from "@/lib/files.functions";
import { formatBytes } from "@/lib/storage";

export const Route = createFileRoute("/files/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `تحميل ملف ${params.slug} — FALQO` },
      {
        name: "description",
        content: "صفحة تحميل ملف مشترك على FALQO مع الحجم وعدد التحميلات وحالة الفحص الأمني.",
      },
      { property: "og:title", content: "تحميل ملف مشترك — FALQO" },
      {
        property: "og:description",
        content: "رابط مشاركة آمن مع فحص أمني وعدّاد تحميلات.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FileDetail,
});

function FileDetail() {
  const { slug } = Route.useParams();
  const file = useQuery(fileBySlugQuery(slug));
  const download = useServerFn(requestSharedFileDownload);
  const [busy, setBusy] = useState(false);

  const onDownload = async () => {
    setBusy(true);
    try {
      const result = await download({ data: { slug } });
      if (!result.ok) {
        toast.error(
          result.reason === "private"
            ? "هذا الملف خاص ولا يمكن تحميله."
            : result.reason === "not_found"
              ? "الملف غير موجود."
              : "الملف غير متاح للتحميل حاليًا.",
        );
        return;
      }
      window.location.href = result.url;
      void file.refetch();
    } catch {
      toast.error("تعذّر بدء التحميل، حاول مرة أخرى.");
    } finally {
      setBusy(false);
    }
  };

  if (file.isLoading) {
    return (
      <div className="mx-auto max-w-3xl px-4 pt-10">
        <div className="glass h-64 animate-pulse rounded-4xl" />
      </div>
    );
  }

  if (!file.data) {
    return (
      <div className="mx-auto max-w-3xl px-4 pb-16 pt-10">
        <EmptyState
          icon={FileArchive}
          title="الملف غير موجود"
          description="قد يكون الرابط منتهيًا أو تم حذف الملف."
          action={
            <Button variant="hero" asChild>
              <Link to="/files">تصفح الملفات</Link>
            </Button>
          }
        />
      </div>
    );
  }

  const data = file.data;

  return (
    <div className="mx-auto max-w-3xl px-4 pb-16 pt-10 sm:px-6">
      <div className="glass-strong rounded-4xl p-6 sm:p-8">
        <div className="flex items-start gap-4">
          <span className="grid size-14 shrink-0 place-items-center rounded-3xl bg-gradient-to-b from-primary-glow/25 to-primary/15 text-primary">
            <FileArchive className="size-6" />
          </span>
          <div className="min-w-0">
            <h1 className="text-2xl font-extrabold sm:text-3xl">{data.title}</h1>
            <p className="mt-1 truncate text-sm text-muted-foreground">{data.file_name}</p>
          </div>
          <div className="ms-auto hidden sm:block">
            <ScanPill status={data.scan_status} />
          </div>
        </div>

        {data.description ? (
          <p className="mt-5 text-sm leading-relaxed text-muted-foreground">{data.description}</p>
        ) : null}

        <dl className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Stat label="الحجم" value={formatBytes(data.file_size)} />
          <Stat label="التحميلات" value={String(data.downloads_count)} />
          <Stat label="النوع" value={data.mime_type?.split("/").pop()?.toUpperCase() ?? "ملف"} />
        </dl>

        <div className="mt-6 flex flex-wrap gap-2">
          <Button variant="hero" size="lg" disabled={busy} onClick={() => void onDownload()}>
            <Download />
            {busy ? "جارٍ التحضير…" : "تحميل الملف"}
          </Button>
          <Button
            variant="glass"
            size="lg"
            onClick={() => {
              void navigator.clipboard.writeText(window.location.href);
              toast.success("تم نسخ رابط المشاركة");
            }}
          >
            <Copy />
            نسخ الرابط
          </Button>
        </div>

        <p className="mt-5 inline-flex items-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5 text-primary" />
          روابط التحميل موقّعة ومؤقتة، وكل ملف يمرّ على معايير الأمان لدينا.
        </p>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-3xl px-4 py-3">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-bold">{value}</dd>
    </div>
  );
}
