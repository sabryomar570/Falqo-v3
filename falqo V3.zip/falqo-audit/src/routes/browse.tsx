import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { z } from "zod";

import { AppCard } from "@/components/AppCard";
import { CategoryGlyph } from "@/components/CategoryIcon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { browseAppsQuery, categoriesQuery } from "@/lib/marketplace";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
  rating: z.coerce.number().optional(),
  sort: z.enum(["newest", "downloads", "rating"]).optional(),
});

export const Route = createFileRoute("/browse")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "استكشاف التطبيقات — FALQO" },
      {
        name: "description",
        content: "ابحث وفلتر تطبيقات FALQO حسب الفئة والتقييم والأحدث أو الأكثر تحميلًا.",
      },
      { property: "og:title", content: "استكشاف التطبيقات — FALQO" },
      { property: "og:description", content: "بحث وفلترة سريعة داخل متجر تطبيقات FALQO." },
    ],
  }),
  component: Browse,
});

const SORTS = [
  { key: "newest", label: "الأحدث" },
  { key: "downloads", label: "الأكثر تحميلًا" },
  { key: "rating", label: "الأعلى تقييمًا" },
] as const;

function Browse() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/browse" });
  const categories = useQuery(categoriesQuery);
  const [term, setTerm] = useState(search.q ?? "");

  const apps = useQuery(
    browseAppsQuery({
      ...(search.q ? { search: search.q } : {}),
      ...(search.category ? { category: search.category } : {}),
      ...(search.rating ? { minRating: search.rating } : {}),
      sort: search.sort ?? "newest",
    }),
  );

  const update = (patch: Record<string, unknown>) =>
    navigate({ search: (prev) => ({ ...prev, ...patch }) });

  return (
    <div className="mx-auto max-w-6xl px-4 pb-10 pt-10 sm:px-6">
      <h1 className="text-3xl font-extrabold sm:text-4xl">استكشاف التطبيقات</h1>

      <div className="glass-strong mt-6 rounded-3xl p-4">
        <form
          className="flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            update({ q: term.trim() || undefined });
          }}
        >
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute end-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={term}
              onChange={(event) => setTerm(event.target.value)}
              placeholder="ابحث باسم التطبيق..."
              maxLength={80}
              className="h-11 rounded-full border-border bg-card/70 pe-10"
            />
          </div>
          <Button type="submit" variant="hero">
            بحث
          </Button>
        </form>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
            <SlidersHorizontal className="size-3.5" />
            الفئة
          </span>
          <Chip active={!search.category} onClick={() => update({ category: undefined })}>
            الكل
          </Chip>
          {(categories.data ?? []).map((category) => (
            <Chip
              key={category.id}
              active={search.category === category.slug}
              onClick={() => update({ category: category.slug })}
            >
              <span className="flex items-center gap-1.5">
                <CategoryGlyph category={category} />
                {category.name_ar}
              </span>
            </Chip>
          ))}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground">الترتيب</span>
          {SORTS.map((item) => (
            <Chip
              key={item.key}
              active={(search.sort ?? "newest") === item.key}
              onClick={() => update({ sort: item.key })}
            >
              {item.label}
            </Chip>
          ))}
          <span className="ms-2 text-xs font-semibold text-muted-foreground">التقييم</span>
          {[0, 3, 4].map((value) => (
            <Chip
              key={value}
              active={(search.rating ?? 0) === value}
              onClick={() => update({ rating: value || undefined })}
            >
              {value === 0 ? "الكل" : `${value}+ نجوم`}
            </Chip>
          ))}
        </div>
      </div>

      {apps.isLoading ? (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((key) => (
            <div key={key} className="glass h-36 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : (apps.data ?? []).length === 0 ? (
        <p className="glass mt-6 rounded-3xl p-10 text-center text-sm text-muted-foreground">
          لا توجد نتائج مطابقة لبحثك.
        </p>
      ) : (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {(apps.data ?? []).map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      )}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "cursor-pointer rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all duration-200",
        active
          ? "bg-primary text-primary-foreground shadow-[var(--glow-primary)]"
          : "glass-subtle text-muted-foreground hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}
