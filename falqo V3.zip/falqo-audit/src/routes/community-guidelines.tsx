import { createFileRoute } from "@tanstack/react-router";

import { LegalPage } from "@/components/LegalPage";

export const Route = createFileRoute("/community-guidelines")({
  head: () => ({
    meta: [
      { title: "إرشادات المجتمع — FALQO" },
      { name: "description", content: "قواعد التعامل والمراجعات والمحتوى داخل مجتمع FALQO." },
      { property: "og:title", content: "إرشادات المجتمع — FALQO" },
      {
        property: "og:description",
        content: "ما هو مسموح وما هو ممنوع في المراجعات والمحتوى على FALQO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LegalPage
      title="إرشادات المجتمع"
      intro="هدفنا مجتمع مفيد ومحترم يساعد الناس على اختيار تطبيقات آمنة."
      updated="أغسطس 2026"
      sections={[
        {
          heading: "المراجعات",
          body: [
            "اكتب تجربتك الحقيقية مع التطبيق فقط.",
            "ممنوع التقييمات المدفوعة أو المزيفة أو الحملات المنظمة ضد ناشر معيّن.",
            "لكل مستخدم مراجعة واحدة لكل تطبيق، ويمكنه تعديلها أو حذفها.",
          ],
        },
        {
          heading: "المحتوى الممنوع",
          body: [
            "برمجيات ضارة أو أدوات اختراق أو ملفات مموّهة.",
            "محتوى يحرّض على العنف أو الكراهية أو ينتهك خصوصية الآخرين.",
            "انتهاك حقوق الملكية الفكرية.",
          ],
        },
        {
          heading: "الإبلاغ والإجراءات",
          body: [
            "يمكن لأي مستخدم مسجّل الإبلاغ عن تطبيق من صفحته، ويصل البلاغ إلى فريق المراجعة.",
            "قد تشمل الإجراءات إزالة التطبيق أو إيقاف حساب الناشر بحسب خطورة المخالفة.",
          ],
        },
      ]}
    />
  ),
});
