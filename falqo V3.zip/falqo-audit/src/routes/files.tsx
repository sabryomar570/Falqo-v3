import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Download, FolderOpen, Search, Upload } from "lucide-react";
import { useState } from "react";
import { z } from "zod";

import { EmptyState } from "@/components/EmptyState";
import { ScanPill } from "@/components/StatusPill";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { publicFilesQuery } from "@/lib/files";
import { formatBytes } from "@/lib/storage";

export const Route = createFileRoute("/files")({
  validateSearch: z.object({ q: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "الملفات — مشاركة وتحميل سريع | FALQO" },
      {
        name: "description",
        content:
          "ارفع أي ملف واحصل على رابط مشاركة عام بصفحة تحميل تعرض الحجم والعدّاد وحالة الفحص الأمني.",
      },
      { property: "og:title", content: "الملفات — مشاركة وتحميل سريع | FALQO" },
      {
        property: "og:description",
        content: "مشاركة ملفات بأسلوب حديث وآمن داخل منصة FALQO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FilesPage,
});

function FilesPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/files" });
  const [term, setTerm] = useState(search.q ?? "");
  const files = useQuery(publicFilesQuery(search.q ?? ""));

  return (
    <div className="mx-auto max-w-6xl px-4 pb-16 pt-10 sm:px-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold sm:text-4xl">الملفات</h1>
          <p className="mt-2 text-sm text-muted-foreground">ارفع ملفًا. خذ الرابط. شاركه.</p>
        </div>
        <Button variant="hero" asChild>
          <Link to="/files/upload">
            <Upload />
            رفع ملف
          </Link>
        </Button>
      </header>

      <form
        className="glass mt-6 flex items-center gap-2 rounded-full p-2"
        onSubmit={(event) => {
          event.preventDefault();
          void navigate({ search: { q: term || undefined } });
        }}
      >
        <Search className="ms-2 size-4 text-muted-foreground" />
        <Input
          value={term}
          onChange={(event) => setTerm(event.target.value)}
          placeholder="ابحث في الملفات المشتركة"
          className="border-0 bg-transparent shadow-none focus-visible:ring-0"
        />
        <Button type="submit" size="sm" variant="glass">
          بحث
        </Button>
      </form>

      {files.isLoading ? (
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {[0, 1, 2, 3].map((key) => (
            <div key={key} className="glass h-28 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : (files.data ?? []).length === 0 ? (
        <div className="mt-6">
          <EmptyState
            icon={FolderOpen}
            title="لا توجد ملفات بعد"
            description="كن أول من يشارك ملفًا مع المجتمع."
            action={
              <Button variant="hero" asChild>
                <Link to="/files/upload">رفع ملف</Link>
              </Button>
            }
          />
        </div>
      ) : (
        <ul className="mt-6 grid gap-3 sm:grid-cols-2">
          {(files.data ?? []).map((file) => (
            <li key={file.id}>
              <Link
                to="/files/$slug"
                params={{ slug: file.slug }}
                className="glass lift flex h-full flex-col gap-3 rounded-3xl p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-b from-primary-glow/25 to-primary/15 text-primary">
                    <FolderOpen className="size-5" />
                  </span>
                  <ScanPill status={file.scan_status} />
                </div>
                <div>
                  <h2 className="line-clamp-1 font-bold">{file.title}</h2>
                  <p className="line-clamp-2 mt-1 text-sm text-muted-foreground">
                    {file.description || file.file_name}
                  </p>
                </div>
                <div className="mt-auto flex items-center gap-4 text-xs text-muted-foreground">
                  <span>{formatBytes(file.file_size)}</span>
                  <span className="inline-flex items-center gap-1">
                    <Download className="size-3.5" />
                    {file.downloads_count}
                  </span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
