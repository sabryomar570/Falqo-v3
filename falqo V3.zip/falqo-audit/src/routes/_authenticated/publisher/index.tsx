import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CalendarClock, Download, HardDrive, Plus, RefreshCw, Tag } from "lucide-react";
import { toast } from "sonner";

import { CategoryBadge } from "@/components/CategoryBadge";
import { SignedImage } from "@/components/SignedImage";
import { ScanPill, StatusPill } from "@/components/StatusPill";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { myAppsQuery, type AppRow } from "@/lib/marketplace";
import { publisherDownloadsQuery, type AppDownloadStats } from "@/lib/publisher";
import { refreshAppScan } from "@/lib/scan.functions";
import { BUCKETS, formatBytes } from "@/lib/storage";

export const Route = createFileRoute("/_authenticated/publisher/")({
  head: () => ({
    meta: [
      { title: "لوحة الناشر — FALQO" },
      {
        name: "description",
        content: "تابع حالة مراجعة وفحص تطبيقاتك وأحداث التنزيل الفعلية على FALQO.",
      },
      { property: "og:title", content: "لوحة الناشر — FALQO" },
      {
        property: "og:description",
        content: "إدارة تطبيقاتك وحالة المراجعة وأحداث التنزيل على FALQO.",
      },
    ],
  }),
  component: PublisherDashboard,
});

function PublisherDashboard() {
  const { profile } = useAuth();
  const apps = useQuery(myAppsQuery);
  const appIds = (apps.data ?? []).map((app) => app.id);
  const downloads = useQuery(publisherDownloadsQuery(appIds));

  if (profile && !profile.is_publisher) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <div className="glass rounded-3xl p-8">
          <h1 className="text-xl font-bold">حسابك ليس حساب ناشر</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            فعّل وضع الناشر من صفحة ملفك الشخصي لتتمكن من رفع التطبيقات.
          </p>
          <Button variant="hero" className="mt-6" asChild>
            <Link to="/profile">اذهب إلى ملفي</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 pb-10 pt-12 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold">لوحة الناشر</h1>
        <Button variant="hero" asChild>
          <Link to="/publisher/upload">
            <Plus />
            رفع تطبيق
          </Link>
        </Button>
      </div>

      <div className="mt-6 space-y-4">
        {apps.isLoading && <div className="glass h-40 animate-pulse rounded-3xl" />}
        {(apps.data ?? []).map((app) => (
          <PublisherAppCard
            key={app.id}
            app={app}
            stats={downloads.data?.[app.id]}
            loading={downloads.isLoading}
          />
        ))}
        {!apps.isLoading && (apps.data ?? []).length === 0 && (
          <p className="glass rounded-3xl p-10 text-center text-sm text-muted-foreground">
            لم ترفع أي تطبيق بعد.
          </p>
        )}
      </div>
    </div>
  );
}

function PublisherAppCard({
  app,
  stats,
  loading,
}: {
  app: AppRow;
  stats: AppDownloadStats | undefined;
  loading: boolean;
}) {
  const queryClient = useQueryClient();
  const refreshScan = useServerFn(refreshAppScan);

  const rescan = useMutation({
    mutationFn: () => refreshScan({ data: { appId: app.id } }),
    onSuccess: (result) => {
      if (!result.ok) {
        toast.error(
          result.reason === "no_job"
            ? "لا توجد مهمة فحص خارجية لهذا التطبيق بعد"
            : "تعذّر تحديث نتيجة الفحص الآن",
        );
        return;
      }
      toast.success(
        result.status === "clean"
          ? "الفحص انتهى: الملف آمن"
          : result.status === "flagged"
            ? "الفحص انتهى: تم رصد خطر في الملف"
            : "الفحص ما زال جاريًا",
      );
      void queryClient.invalidateQueries({ queryKey: ["apps"] });
    },
    onError: () => toast.error("تعذّر تحديث نتيجة الفحص"),
  });

  return (
    <article className="glass rounded-3xl p-5">
      <div className="flex items-start gap-4">
        <SignedImage
          bucket={BUCKETS.icons}
          path={app.icon_url}
          alt={app.name}
          className="size-16 shrink-0 rounded-2xl object-cover"
        />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="truncate text-base font-bold">{app.name}</h2>
            <CategoryBadge category={app.categories} />
          </div>
          {app.tagline && <p className="mt-0.5 text-xs text-muted-foreground">{app.tagline}</p>}
          <p className="mt-2 line-clamp-2 text-[13px] leading-relaxed text-muted-foreground">
            {app.description || "لا يوجد وصف."}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <StatusPill status={app.status} />
            <ScanPill status={app.scan_status} />
          </div>
          {app.status === "rejected" && app.rejection_reason && (
            <p className="mt-2 rounded-2xl bg-destructive/10 p-3 text-xs text-destructive">
              سبب الرفض: {app.rejection_reason}
            </p>
          )}
        </div>
        <Button
          variant="glass"
          size="sm"
          disabled={rescan.isPending}
          onClick={() => rescan.mutate()}
        >
          <RefreshCw className={rescan.isPending ? "animate-spin" : undefined} />
          تحديث الفحص
        </Button>
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-3 border-t hairline pt-4 text-xs sm:grid-cols-4">
        <Meta icon={<Tag className="size-3.5" />} label="الإصدار" value={app.version} />
        <Meta
          icon={<HardDrive className="size-3.5" />}
          label="حجم الملف"
          value={formatBytes(Number(app.file_size))}
        />
        <Meta
          icon={<CalendarClock className="size-3.5" />}
          label="آخر تحديث"
          value={new Date(app.updated_at).toLocaleDateString("ar-EG")}
        />
        <Meta
          icon={<CalendarClock className="size-3.5" />}
          label="تاريخ الرفع"
          value={new Date(app.created_at).toLocaleDateString("ar-EG")}
        />
      </dl>

      <section className="mt-4 border-t hairline pt-4">
        <h3 className="flex items-center gap-1.5 text-sm font-bold">
          <Download className="size-4 text-primary" />
          أحداث التنزيل
        </h3>
        {loading ? (
          <div className="glass-subtle mt-3 h-16 animate-pulse rounded-2xl" />
        ) : (
          <>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <Stat label="اليوم" value={stats?.today ?? 0} />
              <Stat label="7 أيام" value={stats?.week ?? 0} />
              <Stat label="الإجمالي" value={stats?.total ?? 0} />
            </div>
            {(stats?.events.length ?? 0) === 0 ? (
              <p className="mt-3 text-xs text-muted-foreground">
                لا توجد أحداث تنزيل مسجّلة لهذا التطبيق بعد.
              </p>
            ) : (
              <ul className="mt-3 space-y-1.5">
                {(stats?.events ?? []).map((event) => (
                  <li
                    key={event.id}
                    className="glass-subtle flex items-center justify-between rounded-2xl px-3 py-2 text-xs"
                  >
                    <span className="text-muted-foreground">
                      {new Date(event.created_at).toLocaleString("ar-EG")}
                    </span>
                    <span className="flex items-center gap-3">
                      <span>{event.user_id ? "مستخدم مسجّل" : "زائر"}</span>
                      <span className="text-muted-foreground">
                        إصدار {event.app_version ?? app.version}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </section>
    </article>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass-subtle rounded-2xl px-3 py-2">
      <p className="text-lg font-bold">{value}</p>
      <p className="text-[11px] text-muted-foreground">{label}</p>
    </div>
  );
}

function Meta({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div>
      <dt className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        {icon}
        {label}
      </dt>
      <dd className="mt-0.5 font-semibold">{value}</dd>
    </div>
  );
}
