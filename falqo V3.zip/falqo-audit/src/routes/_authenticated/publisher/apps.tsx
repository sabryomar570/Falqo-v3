import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/publisher/apps")({
  beforeLoad: () => {
    throw redirect({ to: "/publisher" });
  },
  component: () => null,
});
