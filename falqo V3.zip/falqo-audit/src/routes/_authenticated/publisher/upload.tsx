import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { categoriesQuery } from "@/lib/marketplace";
import { submitAppScan } from "@/lib/scan.functions";
import { BUCKETS, uploadFile } from "@/lib/storage";

export const Route = createFileRoute("/_authenticated/publisher/upload")({
  head: () => ({
    meta: [
      { title: "رفع تطبيق — FALQO" },
      { name: "description", content: "ارفع تطبيقك على FALQO ليدخل قائمة الفحص الأمني والمراجعة." },
      { property: "og:title", content: "رفع تطبيق — FALQO" },
      { property: "og:description", content: "نموذج رفع التطبيقات للناشرين على FALQO." },
    ],
  }),
  component: UploadApp,
});

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  tagline: z.string().trim().max(120).optional(),
  description: z.string().trim().min(20).max(4000),
  version: z.string().trim().min(1).max(20),
  category_id: z.string().uuid(),
});

function slugify(value: string) {
  return (
    value
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 50) || `app-${Date.now()}`
  );
}

function UploadApp() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const categories = useQuery(categoriesQuery);
  const startScan = useServerFn(submitAppScan);

  const [form, setForm] = useState({
    name: "",
    tagline: "",
    description: "",
    version: "1.0.0",
    category_id: "",
  });
  const [icon, setIcon] = useState<File | null>(null);
  const [shots, setShots] = useState<File[]>([]);
  const [pkg, setPkg] = useState<File | null>(null);

  const submit = useMutation({
    mutationFn: async () => {
      const parsed = schema.parse(form);
      if (!icon) throw new Error("icon");
      if (!pkg) throw new Error("file");

      const slug = `${slugify(parsed.name)}-${Math.random().toString(36).slice(2, 6)}`;
      const uploadedPaths: { bucket: (typeof BUCKETS)[keyof typeof BUCKETS]; path: string }[] = [];
      let iconPath = "";
      let filePath = "";
      let recordCreated = false;
      const shotPaths: string[] = [];
      try {
        iconPath = await uploadFile(BUCKETS.icons, user!.id, icon, "icon");
        uploadedPaths.push({ bucket: BUCKETS.icons, path: iconPath });
        filePath = await uploadFile(BUCKETS.files, user!.id, pkg, "app");
        uploadedPaths.push({ bucket: BUCKETS.files, path: filePath });
        for (const shot of shots.slice(0, 6)) {
          const shotPath = await uploadFile(BUCKETS.screenshots, user!.id, shot, "screenshot");
          uploadedPaths.push({ bucket: BUCKETS.screenshots, path: shotPath });
          shotPaths.push(shotPath);
        }

        const { data, error } = await supabase
          .from("apps")
          .insert({
            publisher_id: user!.id,
            slug,
            name: parsed.name,
            tagline: parsed.tagline ?? null,
            description: parsed.description,
            version: parsed.version,
            category_id: parsed.category_id,
            icon_url: iconPath,
            screenshots: shotPaths,
            file_url: filePath,
            file_name: pkg.name,
            file_size: pkg.size,
          })
          .select("id")
          .single();
        if (error) throw error;
        recordCreated = true;

        // Real security scan: queue the file with the scanning provider.
        const scan = await startScan({ data: { appId: data.id } });
        if (!scan.ok) throw new Error("scan_start_failed");
      } catch (error) {
        if (!recordCreated) {
          await Promise.all(
            uploadedPaths.map(({ bucket, path }) => supabase.storage.from(bucket).remove([path])),
          );
        }
        throw error;
      }
    },
    onSuccess: () => {
      toast.success("تم الرفع! التطبيق الآن قيد المراجعة والفحص.");
      void navigate({ to: "/publisher" });
    },
    onError: (error) =>
      toast.error(
        error.message === "icon"
          ? "أضف أيقونة التطبيق"
          : error.message === "file"
            ? "أضف ملف التطبيق (APK أو غيره)"
            : error.message === "file_too_large"
              ? "حجم الملف يتجاوز الحد المسموح"
              : error.message === "invalid_app_type"
                ? "نوع ملف التطبيق غير مدعوم"
                : error.message === "scan_start_failed"
                  ? "تم رفع الملفات، لكن بدء الفحص فشل. أعد المحاولة من لوحة الناشر."
                  : "تحقق من البيانات المدخلة ثم أعد المحاولة",
      ),
  });

  return (
    <div className="mx-auto max-w-2xl px-4 pb-12 pt-12 sm:px-6">
      <h1 className="text-3xl font-extrabold">رفع تطبيق جديد</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        سيدخل التطبيق قائمة الفحص الأمني ولن يُنشر قبل الموافقة.
      </p>

      <form
        className="glass-strong mt-6 space-y-4 rounded-4xl p-6"
        onSubmit={(event) => {
          event.preventDefault();
          submit.mutate();
        }}
      >
        <Field label="اسم التطبيق">
          <Input
            value={form.name}
            maxLength={80}
            onChange={(event) => setForm({ ...form, name: event.target.value })}
            className="rounded-2xl bg-card/70"
          />
        </Field>
        <Field label="وصف مختصر">
          <Input
            value={form.tagline}
            maxLength={120}
            onChange={(event) => setForm({ ...form, tagline: event.target.value })}
            className="rounded-2xl bg-card/70"
          />
        </Field>
        <Field label="الوصف الكامل">
          <Textarea
            value={form.description}
            maxLength={4000}
            rows={5}
            onChange={(event) => setForm({ ...form, description: event.target.value })}
            className="rounded-2xl bg-card/70"
          />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="الإصدار">
            <Input
              value={form.version}
              maxLength={20}
              onChange={(event) => setForm({ ...form, version: event.target.value })}
              className="rounded-2xl bg-card/70"
            />
          </Field>
          <Field label="الفئة">
            <select
              value={form.category_id}
              onChange={(event) => setForm({ ...form, category_id: event.target.value })}
              className="h-9 w-full rounded-2xl border border-input bg-card/70 px-3 text-sm"
            >
              <option value="">اختر فئة</option>
              {(categories.data ?? []).map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name_ar}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="أيقونة التطبيق">
          <Input
            type="file"
            accept="image/*"
            onChange={(event) => setIcon(event.target.files?.[0] ?? null)}
            className="rounded-2xl bg-card/70"
          />
        </Field>
        <Field label="لقطات الشاشة (حتى 6)">
          <Input
            type="file"
            accept="image/*"
            multiple
            onChange={(event) => setShots(Array.from(event.target.files ?? []))}
            className="rounded-2xl bg-card/70"
          />
        </Field>
        <Field label="ملف التطبيق (APK أو غيره)">
          <Input
            type="file"
            onChange={(event) => setPkg(event.target.files?.[0] ?? null)}
            className="rounded-2xl bg-card/70"
          />
        </Field>

        <Button
          type="submit"
          variant="hero"
          size="lg"
          className="w-full"
          disabled={submit.isPending}
        >
          <UploadCloud />
          {submit.isPending ? "جارٍ الرفع..." : "رفع للمراجعة"}
        </Button>
      </form>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold">{label}</span>
      {children}
    </label>
  );
}
