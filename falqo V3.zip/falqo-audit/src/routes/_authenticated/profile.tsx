import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { LogOut, Rocket } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "ملفي الشخصي — FALQO" },
      { name: "description", content: "بياناتك على FALQO وحالة حساب الناشر." },
      { property: "og:title", content: "ملفي الشخصي — FALQO" },
      { property: "og:description", content: "إدارة حسابك وحالة النشر على FALQO." },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { user, profile, isAdmin, signOut, refreshProfile } = useAuth();

  const becomePublisher = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("profiles")
        .update({ is_publisher: true })
        .eq("id", user!.id);
      if (error) throw error;
      await refreshProfile();
    },
    onSuccess: () => toast.success("صرت ناشرًا! يمكنك رفع تطبيقاتك الآن."),
    onError: () => toast.error("تعذّر تحديث الحساب"),
  });

  return (
    <div className="mx-auto max-w-2xl px-4 pb-10 pt-12 sm:px-6">
      <div className="glass-strong rounded-4xl p-7 text-center">
        {profile?.avatar_url ? (
          <img
            src={profile.avatar_url}
            alt={profile.full_name ?? "صورة الحساب"}
            className="mx-auto size-20 rounded-full object-cover shadow-[var(--shadow-float)]"
          />
        ) : (
          <span className="mx-auto block size-20 rounded-full bg-muted" />
        )}
        <h1 className="mt-4 text-2xl font-bold">{profile?.full_name ?? "مستخدم FALQO"}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{user?.email}</p>
        <div className="mt-3 flex flex-wrap justify-center gap-2 text-xs font-semibold">
          <span className="glass-subtle rounded-full px-3 py-1">
            {profile?.is_publisher ? "ناشر / مطوّر" : "مستخدم عادي"}
          </span>
          {isAdmin && <span className="glass-subtle rounded-full px-3 py-1">مشرف</span>}
        </div>

        <div className="mt-7 flex flex-col gap-2 sm:flex-row sm:justify-center">
          {profile?.is_publisher ? (
            <Button variant="hero" asChild>
              <Link to="/publisher">
                <Rocket />
                لوحة الناشر
              </Link>
            </Button>
          ) : (
            <Button
              variant="hero"
              disabled={becomePublisher.isPending}
              onClick={() => becomePublisher.mutate()}
            >
              <Rocket />
              صير ناشر
            </Button>
          )}
          <Button variant="glass" onClick={() => void signOut()}>
            <LogOut />
            تسجيل الخروج
          </Button>
        </div>
      </div>
    </div>
  );
}
