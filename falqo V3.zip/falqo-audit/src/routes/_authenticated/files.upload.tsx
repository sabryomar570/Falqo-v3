import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { FolderOpen, Trash2, Upload } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { ScanPill } from "@/components/StatusPill";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { fileSlug, myFilesQuery, uploadSharedFile, SHARED_BUCKET } from "@/lib/files";
import { formatBytes } from "@/lib/storage";
import { submitSharedFileScan } from "@/lib/file-scan.functions";

export const Route = createFileRoute("/_authenticated/files/upload")({
  head: () => ({
    meta: [
      { title: "رفع ملف — FALQO" },
      { name: "description", content: "ارفع ملفًا واحصل على رابط مشاركة عام فورًا على FALQO." },
      { property: "og:title", content: "رفع ملف — FALQO" },
      { property: "og:description", content: "مشاركة الملفات بسهولة وأمان." },
    ],
  }),
  component: UploadFilePage,
});

function UploadFilePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const mine = useQuery(myFilesQuery);
  const startScan = useServerFn(submitSharedFileScan);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [visibility, setVisibility] = useState<"public" | "private">("public");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user || !file) {
      toast.error("اختر ملفًا أولًا.");
      return;
    }
    setBusy(true);
    try {
      const path = await uploadSharedFile(user.id, file);
      const slug = fileSlug(title || file.name);
      const { data: created, error } = await supabase
        .from("files")
        .insert({
          owner_id: user.id,
          slug,
          title: title || file.name,
          description,
          file_path: path,
          file_name: file.name,
          file_size: file.size,
          mime_type: file.type || null,
          visibility,
        })
        .select("id")
        .single();
      if (error) throw error;
      if (!created) throw new Error("file_record_missing");
      const scan = await startScan({ data: { fileId: created.id } });
      if (!scan.ok) toast.warning("تم رفع الملف، لكن الفحص الأمني يحتاج إلى إعادة المحاولة.");
      toast.success("تم رفع الملف بنجاح");
      await queryClient.invalidateQueries({ queryKey: ["files"] });
      void navigate({ to: "/files/$slug", params: { slug } });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "تعذّر رفع الملف");
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: string, path: string) => {
    if (!window.confirm("هل تريد حذف هذا الملف نهائيًا؟")) return;
    await supabase.storage.from(SHARED_BUCKET).remove([path]);
    const { error } = await supabase.from("files").delete().eq("id", id);
    if (error) {
      toast.error("تعذّر حذف الملف");
      return;
    }
    toast.success("تم حذف الملف");
    await queryClient.invalidateQueries({ queryKey: ["files"] });
  };

  return (
    <div className="mx-auto max-w-3xl px-4 pb-16 pt-10 sm:px-6">
      <h1 className="text-3xl font-extrabold">رفع ملف</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        الحد الأقصى للملف 50 ميجابايت. الملفات العامة تحصل على صفحة تحميل قابلة للمشاركة.
      </p>

      <form onSubmit={submit} className="glass-strong mt-6 space-y-5 rounded-4xl p-6">
        <div className="space-y-2">
          <Label htmlFor="file">الملف</Label>
          <Input
            id="file"
            type="file"
            onChange={(event) => setFile(event.target.files?.[0] ?? null)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="title">العنوان</Label>
          <Input
            id="title"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="اسم واضح للملف"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="description">الوصف</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="ماذا يحتوي هذا الملف؟"
            rows={4}
          />
        </div>
        <div className="space-y-2">
          <Label>الظهور</Label>
          <div className="flex gap-2">
            {(["public", "private"] as const).map((value) => (
              <Button
                key={value}
                type="button"
                variant={visibility === value ? "hero" : "glass"}
                size="sm"
                onClick={() => setVisibility(value)}
              >
                {value === "public" ? "عام" : "خاص"}
              </Button>
            ))}
          </div>
        </div>
        <Button type="submit" variant="hero" size="lg" disabled={busy}>
          <Upload />
          {busy ? "جارٍ الرفع…" : "رفع ومشاركة"}
        </Button>
      </form>

      <section className="mt-10">
        <h2 className="text-xl font-bold">ملفاتي</h2>
        <ul className="mt-4 space-y-3">
          {(mine.data ?? []).map((row) => (
            <li key={row.id} className="glass flex items-center gap-3 rounded-3xl p-4">
              <span className="grid size-10 shrink-0 place-items-center rounded-2xl bg-muted text-muted-foreground">
                <FolderOpen className="size-4" />
              </span>
              <div className="min-w-0">
                <Link
                  to="/files/$slug"
                  params={{ slug: row.slug }}
                  className="block truncate font-semibold hover:text-primary"
                >
                  {row.title}
                </Link>
                <p className="text-xs text-muted-foreground">
                  {formatBytes(row.file_size)} · {row.downloads_count} تحميل ·{" "}
                  {row.visibility === "public" ? "عام" : "خاص"}
                </p>
              </div>
              <div className="ms-auto flex items-center gap-2">
                <ScanPill status={row.scan_status} />
                <Button
                  variant="ghost"
                  size="iconSm"
                  aria-label="حذف"
                  onClick={() => void remove(row.id, row.file_path)}
                >
                  <Trash2 />
                </Button>
              </div>
            </li>
          ))}
          {(mine.data ?? []).length === 0 ? (
            <li className="text-sm text-muted-foreground">لم ترفع أي ملف بعد.</li>
          ) : null}
        </ul>
      </section>
    </div>
  );
}
