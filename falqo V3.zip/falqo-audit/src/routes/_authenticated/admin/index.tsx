import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { ScanPill, StatusPill } from "@/components/StatusPill";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { adminReportsQuery } from "@/lib/community";
import { adminStatsQuery, type AppStatus, type ScanStatus } from "@/lib/marketplace";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "لوحة المشرف — FALQO" },
      { name: "description", content: "مراجعة التطبيقات وإدارة حالات الفحص الأمني على FALQO." },
      { property: "og:title", content: "لوحة المشرف — FALQO" },
      { property: "og:description", content: "قبول ورفض التطبيقات وإدارة الفحص الأمني." },
    ],
  }),
  component: AdminDashboard,
});

const FILTERS: { key: AppStatus | "all"; label: string }[] = [
  { key: "pending", label: "قيد المراجعة" },
  { key: "approved", label: "مقبولة" },
  { key: "rejected", label: "مرفوضة" },
  { key: "all", label: "الكل" },
];

function AdminDashboard() {
  const { isAdmin, loading } = useAuth();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<AppStatus | "all">("pending");
  const [reason, setReason] = useState<Record<string, string>>({});
  const stats = useQuery({ ...adminStatsQuery, enabled: isAdmin });

  const apps = useQuery({
    queryKey: ["admin-apps", filter],
    enabled: isAdmin,
    queryFn: async () => {
      let query = supabase
        .from("apps")
        .select("*, categories(*), profiles:publisher_id(full_name)")
        .order("created_at", { ascending: false });
      if (filter !== "all") query = query.eq("status", filter);
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const decide = useMutation({
    mutationFn: async (input: {
      id: string;
      status?: AppStatus;
      scan_status?: ScanStatus;
      note?: string;
    }) => {
      const { error } = await supabase
        .from("apps")
        .update({
          ...(input.status ? { status: input.status } : {}),
          ...(input.scan_status ? { scan_status: input.scan_status } : {}),
          ...(input.note !== undefined ? { rejection_reason: input.note || null } : {}),
          ...(input.status === "approved" ? { published_at: new Date().toISOString() } : {}),
        })
        .eq("id", input.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تم تحديث حالة التطبيق");
      void queryClient.invalidateQueries({ queryKey: ["admin-apps"] });
      void queryClient.invalidateQueries({ queryKey: ["admin-stats"] });
      void queryClient.invalidateQueries({ queryKey: ["apps"] });
    },
    onError: () => toast.error("تعذّر تحديث الحالة"),
  });

  if (!loading && !isAdmin) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <div className="glass rounded-3xl p-10">
          <h1 className="text-xl font-bold">صفحة للمشرفين فقط</h1>
          <p className="mt-2 text-sm text-muted-foreground">ليست لديك صلاحية الوصول.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 pb-12 pt-12 sm:px-6">
      <h1 className="text-3xl font-extrabold">لوحة المشرف</h1>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "إجمالي التطبيقات", value: stats.data?.apps },
          { label: "الناشرون", value: stats.data?.publishers },
          { label: "المعروضة حاليًا", value: (apps.data ?? []).length },
          { label: "إجمالي التحميلات", value: stats.data?.downloads },
        ].map((item) => (
          <div key={item.label} className="glass rounded-3xl p-4">
            <p className="text-xs text-muted-foreground">{item.label}</p>
            <p className="mt-1 text-2xl font-bold">{item.value ?? "—"}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {FILTERS.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setFilter(item.key)}
            className={cn(
              "cursor-pointer rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all",
              filter === item.key
                ? "bg-primary text-primary-foreground shadow-[var(--glow-primary)]"
                : "glass-subtle text-muted-foreground",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="mt-5 space-y-3">
        {(apps.data ?? []).map((app) => (
          <div key={app.id} className="glass rounded-3xl p-5">
            <div className="flex flex-wrap items-center gap-3">
              <p className="font-semibold">{app.name}</p>
              <StatusPill status={app.status} />
              <ScanPill status={app.scan_status} />
              <span className="ms-auto text-xs text-muted-foreground">
                {new Date(app.created_at).toLocaleDateString("ar-EG")}
              </span>
            </div>
            <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{app.description}</p>

            <div className="mt-4 flex flex-wrap gap-2">
              {(["queued", "scanning", "clean", "flagged", "failed"] as ScanStatus[]).map(
                (scan) => (
                  <Button
                    key={scan}
                    variant="glass"
                    size="sm"
                    disabled={decide.isPending}
                    onClick={() => decide.mutate({ id: app.id, scan_status: scan })}
                  >
                    فحص: {scan}
                  </Button>
                ),
              )}
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button
                variant="hero"
                size="sm"
                onClick={() => decide.mutate({ id: app.id, status: "approved", note: "" })}
              >
                قبول
              </Button>
              <Input
                value={reason[app.id] ?? ""}
                maxLength={300}
                placeholder="سبب الرفض"
                onChange={(event) => setReason({ ...reason, [app.id]: event.target.value })}
                className="h-9 max-w-xs rounded-2xl bg-card/70"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  decide.mutate({
                    id: app.id,
                    status: "rejected",
                    note: reason[app.id] ?? "",
                  })
                }
              >
                رفض
              </Button>
            </div>
          </div>
        ))}
        {(apps.data ?? []).length === 0 && (
          <p className="glass rounded-3xl p-10 text-center text-sm text-muted-foreground">
            لا توجد تطبيقات في هذه القائمة.
          </p>
        )}
      </div>

      <ReportsQueue enabled={isAdmin} />
    </div>
  );
}

function ReportsQueue({ enabled }: { enabled: boolean }) {
  const queryClient = useQueryClient();
  const reports = useQuery({ ...adminReportsQuery, enabled });

  const resolve = useMutation({
    mutationFn: async (input: { id: string; status: string }) => {
      const { error } = await supabase
        .from("app_reports")
        .update({ status: input.status })
        .eq("id", input.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تم تحديث البلاغ");
      void queryClient.invalidateQueries({ queryKey: ["admin", "reports"] });
    },
    onError: () => toast.error("تعذّر تحديث البلاغ"),
  });

  return (
    <section className="mt-12">
      <h2 className="text-xl font-bold">بلاغات المستخدمين</h2>
      <div className="mt-4 space-y-3">
        {(reports.data ?? []).map((report) => (
          <div key={report.id} className="glass rounded-3xl p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-semibold">{report.apps?.name ?? "تطبيق محذوف"}</span>
              <span className="glass-subtle rounded-full px-2.5 py-1 text-xs font-semibold">
                {report.reason}
              </span>
              <span className="text-xs text-muted-foreground">{report.status}</span>
              <span className="ms-auto text-xs text-muted-foreground">
                {new Date(report.created_at).toLocaleDateString("ar-EG")}
              </span>
            </div>
            {report.details && (
              <p className="mt-2 text-sm text-muted-foreground">{report.details}</p>
            )}
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                variant="glass"
                size="sm"
                onClick={() => resolve.mutate({ id: report.id, status: "reviewing" })}
              >
                قيد المعالجة
              </Button>
              <Button
                variant="hero"
                size="sm"
                onClick={() => resolve.mutate({ id: report.id, status: "resolved" })}
              >
                تم الحل
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => resolve.mutate({ id: report.id, status: "dismissed" })}
              >
                تجاهل
              </Button>
            </div>
          </div>
        ))}
        {(reports.data ?? []).length === 0 && (
          <p className="glass rounded-3xl p-10 text-center text-sm text-muted-foreground">
            لا توجد بلاغات حاليًا.
          </p>
        )}
      </div>
    </section>
  );
}
