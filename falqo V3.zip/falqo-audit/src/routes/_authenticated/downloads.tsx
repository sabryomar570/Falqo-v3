import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";

import { EmptyState } from "@/components/EmptyState";
import { SignedImage } from "@/components/SignedImage";
import { Button } from "@/components/ui/button";
import { myDownloadsQuery } from "@/lib/community";
import { BUCKETS } from "@/lib/storage";

export const Route = createFileRoute("/_authenticated/downloads")({
  head: () => ({
    meta: [
      { title: "سجل التحميلات — FALQO" },
      { name: "description", content: "كل التطبيقات التي حمّلتها من متجر FALQO مرتبة بالأحدث." },
      { property: "og:title", content: "سجل التحميلات — FALQO" },
      { property: "og:description", content: "تابع تحميلاتك السابقة وأعد تحميل أي تطبيق." },
    ],
  }),
  component: DownloadsPage,
});

function DownloadsPage() {
  const downloads = useQuery(myDownloadsQuery);
  const items = downloads.data ?? [];

  return (
    <div className="mx-auto max-w-3xl px-4 pb-16 pt-10 sm:px-6">
      <h1 className="text-3xl font-extrabold">سجل التحميلات</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        سجل حقيقي لعمليات التحميل المرتبطة بحسابك.
      </p>

      {downloads.isLoading ? (
        <div className="mt-6 space-y-3">
          {[0, 1, 2].map((key) => (
            <div key={key} className="glass h-20 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="mt-6">
          <EmptyState
            icon={Download}
            title="لا توجد تحميلات بعد"
            description="بمجرد تحميل أي تطبيق سيظهر هنا مع تاريخ التحميل."
            action={
              <Button variant="hero" asChild>
                <Link to="/browse">ابدأ الاستكشاف</Link>
              </Button>
            }
          />
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {items.map((item) => (
            <li key={item.id} className="glass flex items-center gap-3 rounded-3xl p-3.5">
              <SignedImage
                bucket={BUCKETS.icons}
                path={item.app?.icon_url ?? null}
                alt={item.app?.name ?? "تطبيق"}
                className="size-12 shrink-0 rounded-2xl object-cover"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{item.app?.name ?? "تطبيق محذوف"}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(item.created_at).toLocaleString("ar")}
                </p>
              </div>
              {item.app ? (
                <Button variant="glass" size="sm" asChild>
                  <Link to="/app/$slug" params={{ slug: item.app.slug }}>
                    فتح
                  </Link>
                </Button>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
