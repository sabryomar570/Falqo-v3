import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, CheckCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { EmptyState } from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { deleteNotification, markNotificationsRead, notificationsQuery } from "@/lib/community";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({
    meta: [
      { title: "الإشعارات — FALQO" },
      {
        name: "description",
        content: "مركز إشعارات FALQO: حالة المراجعة، الفحص الأمني، والتحديثات.",
      },
      { property: "og:title", content: "الإشعارات — FALQO" },
      { property: "og:description", content: "تابع كل تحديثات حسابك وتطبيقاتك في مكان واحد." },
    ],
  }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const queryClient = useQueryClient();
  const notifications = useQuery(notificationsQuery);
  const items = notifications.data ?? [];
  const unread = items.filter((item) => !item.read_at).length;

  const readAll = useMutation({
    mutationFn: () => markNotificationsRead(),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteNotification(id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <div className="mx-auto max-w-3xl px-4 pb-16 pt-10 sm:px-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold">الإشعارات</h1>
        {unread > 0 ? (
          <Button variant="glass" onClick={() => readAll.mutate()} disabled={readAll.isPending}>
            <CheckCheck className="size-4" />
            تعليم الكل كمقروء
          </Button>
        ) : null}
      </div>

      {notifications.isLoading ? (
        <div className="mt-6 space-y-3">
          {[0, 1, 2].map((key) => (
            <div key={key} className="glass h-20 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="mt-6">
          <EmptyState
            icon={Bell}
            title="لا توجد إشعارات بعد"
            description="ستظهر هنا تحديثات مراجعة تطبيقاتك، نتائج الفحص الأمني، وإشعارات حسابك."
          />
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {items.map((item) => (
            <li
              key={item.id}
              className={cn(
                "glass flex items-start gap-3 rounded-3xl p-4",
                !item.read_at && "border-primary/30",
              )}
            >
              <span
                className={cn(
                  "mt-1.5 size-2 shrink-0 rounded-full",
                  item.read_at ? "bg-muted-foreground/40" : "bg-primary",
                )}
              />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{item.title}</p>
                {item.body ? (
                  <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
                    {item.body}
                  </p>
                ) : null}
                <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{new Date(item.created_at).toLocaleString("ar")}</span>
                  {item.link === "/publisher" ? (
                    <Link to="/publisher" className="font-semibold text-primary">
                      فتح لوحة الناشر
                    </Link>
                  ) : null}
                </div>
              </div>
              <Button
                variant="ghost"
                size="iconSm"
                aria-label="حذف الإشعار"
                onClick={() => remove.mutate(item.id)}
              >
                <Trash2 />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
