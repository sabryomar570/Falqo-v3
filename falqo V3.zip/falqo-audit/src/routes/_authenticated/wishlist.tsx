import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Heart } from "lucide-react";

import { AppCard } from "@/components/AppCard";
import { EmptyState } from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { wishlistAppsQuery } from "@/lib/community";

export const Route = createFileRoute("/_authenticated/wishlist")({
  head: () => ({
    meta: [
      { title: "المفضلة — FALQO" },
      { name: "description", content: "التطبيقات التي حفظتها في قائمة المفضلة على FALQO." },
      { property: "og:title", content: "المفضلة — FALQO" },
      { property: "og:description", content: "قائمة التطبيقات المحفوظة لديك." },
    ],
  }),
  component: WishlistPage,
});

function WishlistPage() {
  const apps = useQuery(wishlistAppsQuery);

  return (
    <div className="mx-auto max-w-6xl px-4 pb-16 pt-10 sm:px-6">
      <h1 className="text-3xl font-extrabold">المفضلة</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        التطبيقات التي حفظتها للرجوع إليها لاحقًا.
      </p>

      {apps.isLoading ? (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((key) => (
            <div key={key} className="glass h-36 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : (apps.data ?? []).length === 0 ? (
        <div className="mt-6">
          <EmptyState
            icon={Heart}
            title="قائمتك فارغة"
            description="اضغط على «أضف للمفضلة» في صفحة أي تطبيق ليظهر هنا."
            action={
              <Button variant="hero" asChild>
                <Link to="/browse">استكشف التطبيقات</Link>
              </Button>
            }
          />
        </div>
      ) : (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {(apps.data ?? []).map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      )}
    </div>
  );
}
