import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { forumCategoriesQuery } from "@/lib/forum";

export const Route = createFileRoute("/_authenticated/community/new")({
  head: () => ({
    meta: [
      { title: "موضوع جديد — مجتمع FALQO" },
      { name: "description", content: "افتح نقاشًا جديدًا أو اطلب تطبيقًا في مجتمع FALQO." },
      { property: "og:title", content: "موضوع جديد — مجتمع FALQO" },
      { property: "og:description", content: "شارك سؤالك أو طلبك مع المجتمع." },
    ],
  }),
  component: NewTopicPage,
});

function NewTopicPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const categories = useQuery(forumCategoriesQuery);
  const [categoryId, setCategoryId] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);

  const activeCategory = categoryId || categories.data?.[0]?.id || "";

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user || !activeCategory) return;
    setBusy(true);
    const { data, error } = await supabase
      .from("forum_topics")
      .insert({
        author_id: user.id,
        category_id: activeCategory,
        title: title.trim(),
        body: body.trim(),
      })
      .select("id")
      .single();
    setBusy(false);
    if (error || !data) {
      toast.error("تعذّر نشر الموضوع");
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["forum"] });
    void navigate({ to: "/community/$topicId", params: { topicId: data.id } });
  };

  return (
    <div className="mx-auto max-w-2xl px-4 pb-16 pt-10 sm:px-6">
      <h1 className="text-3xl font-extrabold">موضوع جديد</h1>
      <form onSubmit={submit} className="glass-strong mt-6 space-y-5 rounded-4xl p-6">
        <div className="space-y-2">
          <Label>القسم</Label>
          <div className="flex flex-wrap gap-2">
            {(categories.data ?? []).map((category) => (
              <Button
                key={category.id}
                type="button"
                size="sm"
                variant={activeCategory === category.id ? "hero" : "glass"}
                onClick={() => setCategoryId(category.id)}
              >
                {category.name_ar}
              </Button>
            ))}
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="title">العنوان</Label>
          <Input
            id="title"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="اكتب عنوانًا واضحًا"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="body">التفاصيل</Label>
          <Textarea
            id="body"
            value={body}
            onChange={(event) => setBody(event.target.value)}
            rows={7}
            placeholder="اشرح طلبك أو سؤالك بالتفصيل"
            required
          />
        </div>
        <Button type="submit" variant="hero" size="lg" disabled={busy}>
          <Send />
          {busy ? "جارٍ النشر…" : "نشر الموضوع"}
        </Button>
      </form>
    </div>
  );
}
