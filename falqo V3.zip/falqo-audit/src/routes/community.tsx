import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUp, MessageSquare, MessagesSquare, Pin, Plus } from "lucide-react";
import { z } from "zod";

import { EmptyState } from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { forumCategoriesQuery, forumTopicsQuery } from "@/lib/forum";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/community")({
  validateSearch: z.object({
    category: z.string().optional(),
    sort: z.enum(["latest", "top"]).optional(),
  }),
  head: () => ({
    meta: [
      { title: "المجتمع — نقاشات وطلبات التطبيقات | FALQO" },
      {
        name: "description",
        content:
          "شارك في مجتمع FALQO: اطلب تطبيقًا، اسأل عن مشكلة، وتابع أخبار المنصة مع تصويت وردود.",
      },
      { property: "og:title", content: "مجتمع FALQO" },
      {
        property: "og:description",
        content: "نقاشات، طلبات تطبيقات، ودعم فني من مستخدمين حقيقيين.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CommunityPage,
});

function CommunityPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/community" });
  const categories = useQuery(forumCategoriesQuery);
  const sort = search.sort ?? "latest";
  const topics = useQuery(forumTopicsQuery(search.category, sort));

  return (
    <div className="mx-auto max-w-5xl px-4 pb-16 pt-10 sm:px-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold sm:text-4xl">المجتمع</h1>
          <p className="mt-2 text-sm text-muted-foreground">اسأل. اقترح. صوّت.</p>
        </div>
        <Button variant="hero" asChild>
          <Link to="/community/new">
            <Plus />
            موضوع جديد
          </Link>
        </Button>
      </header>

      <div className="mt-6 flex flex-wrap gap-2">
        <Chip
          active={!search.category}
          onClick={() => void navigate({ search: (prev) => ({ ...prev, category: undefined }) })}
        >
          كل الأقسام
        </Chip>
        {(categories.data ?? []).map((category) => (
          <Chip
            key={category.id}
            active={search.category === category.slug}
            onClick={() =>
              void navigate({ search: (prev) => ({ ...prev, category: category.slug }) })
            }
          >
            {category.name_ar}
          </Chip>
        ))}
        <span className="mx-1 hidden w-px self-stretch bg-border sm:block" />
        {(["latest", "top"] as const).map((value) => (
          <Chip
            key={value}
            active={sort === value}
            onClick={() => void navigate({ search: (prev) => ({ ...prev, sort: value }) })}
          >
            {value === "latest" ? "الأحدث" : "الأكثر تصويتًا"}
          </Chip>
        ))}
      </div>

      {topics.isLoading ? (
        <div className="mt-6 space-y-3">
          {[0, 1, 2].map((key) => (
            <div key={key} className="glass h-24 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : (topics.data ?? []).length === 0 ? (
        <div className="mt-6">
          <EmptyState
            icon={MessagesSquare}
            title="لا توجد مواضيع بعد"
            description="افتح أول نقاش في هذا القسم."
            action={
              <Button variant="hero" asChild>
                <Link to="/community/new">موضوع جديد</Link>
              </Button>
            }
          />
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {(topics.data ?? []).map((topic) => (
            <li key={topic.id}>
              <Link
                to="/community/$topicId"
                params={{ topicId: topic.id }}
                className="glass lift flex items-start gap-4 rounded-3xl p-5"
              >
                <span className="grid shrink-0 place-items-center rounded-2xl bg-muted px-3 py-2 text-center">
                  <ArrowUp className="size-4 text-primary" />
                  <span className="text-sm font-bold">{topic.votes_count}</span>
                </span>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    {topic.is_pinned ? <Pin className="size-3.5 text-primary" /> : null}
                    <h2 className="line-clamp-1 font-bold">{topic.title}</h2>
                  </div>
                  <p className="line-clamp-2 mt-1 text-sm text-muted-foreground">{topic.body}</p>
                  <p className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    <span>{topic.forum_categories?.name_ar ?? "نقاش"}</span>
                    <span>{topic.author?.full_name ?? "مستخدم"}</span>
                    <span className="inline-flex items-center gap-1">
                      <MessageSquare className="size-3.5" />
                      {topic.replies_count}
                    </span>
                  </p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "glass rounded-full px-4 py-2 text-sm font-medium transition-transform hover:-translate-y-0.5",
        active && "bg-primary text-primary-foreground shadow-[var(--glow-primary)]",
      )}
    >
      {children}
    </button>
  );
}
