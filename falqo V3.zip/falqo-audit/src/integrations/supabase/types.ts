export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      app_reports: {
        Row: {
          app_id: string;
          created_at: string;
          details: string | null;
          id: string;
          reason: string;
          reporter_id: string;
          status: string;
        };
        Insert: {
          app_id: string;
          created_at?: string;
          details?: string | null;
          id?: string;
          reason: string;
          reporter_id: string;
          status?: string;
        };
        Update: {
          app_id?: string;
          created_at?: string;
          details?: string | null;
          id?: string;
          reason?: string;
          reporter_id?: string;
          status?: string;
        };
        Relationships: [
          {
            foreignKeyName: "app_reports_app_id_fkey";
            columns: ["app_id"];
            isOneToOne: false;
            referencedRelation: "apps";
            referencedColumns: ["id"];
          },
        ];
      };
      apps: {
        Row: {
          category_id: string | null;
          created_at: string;
          currency: string;
          description: string;
          downloads_count: number;
          file_name: string | null;
          file_size: number;
          file_url: string | null;
          icon_url: string | null;
          id: string;
          is_featured: boolean;
          is_free: boolean;
          name: string;
          platform: string;
          platform_fee_bps: number;
          price_cents: number;
          published_at: string | null;
          publisher_id: string;
          rating_avg: number;
          rating_count: number;
          rejection_reason: string | null;
          scan_provider: string | null;
          scan_report: Json | null;
          scan_status: Database["public"]["Enums"]["scan_status"];
          scanned_at: string | null;
          screenshots: string[];
          slug: string;
          status: Database["public"]["Enums"]["app_status"];
          tagline: string | null;
          updated_at: string;
          version: string;
        };
        Insert: {
          category_id?: string | null;
          created_at?: string;
          currency?: string;
          description?: string;
          downloads_count?: number;
          file_name?: string | null;
          file_size?: number;
          file_url?: string | null;
          icon_url?: string | null;
          id?: string;
          is_featured?: boolean;
          is_free?: boolean;
          name: string;
          platform?: string;
          platform_fee_bps?: number;
          price_cents?: number;
          published_at?: string | null;
          publisher_id: string;
          rating_avg?: number;
          rating_count?: number;
          rejection_reason?: string | null;
          scan_provider?: string | null;
          scan_report?: Json | null;
          scan_status?: Database["public"]["Enums"]["scan_status"];
          scanned_at?: string | null;
          screenshots?: string[];
          slug: string;
          status?: Database["public"]["Enums"]["app_status"];
          tagline?: string | null;
          updated_at?: string;
          version?: string;
        };
        Update: {
          category_id?: string | null;
          created_at?: string;
          currency?: string;
          description?: string;
          downloads_count?: number;
          file_name?: string | null;
          file_size?: number;
          file_url?: string | null;
          icon_url?: string | null;
          id?: string;
          is_featured?: boolean;
          is_free?: boolean;
          name?: string;
          platform?: string;
          platform_fee_bps?: number;
          price_cents?: number;
          published_at?: string | null;
          publisher_id?: string;
          rating_avg?: number;
          rating_count?: number;
          rejection_reason?: string | null;
          scan_provider?: string | null;
          scan_report?: Json | null;
          scan_status?: Database["public"]["Enums"]["scan_status"];
          scanned_at?: string | null;
          screenshots?: string[];
          slug?: string;
          status?: Database["public"]["Enums"]["app_status"];
          tagline?: string | null;
          updated_at?: string;
          version?: string;
        };
        Relationships: [
          {
            foreignKeyName: "apps_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "categories";
            referencedColumns: ["id"];
          },
        ];
      };
      categories: {
        Row: {
          gradient_from: string;
          gradient_to: string;
          icon: string;
          id: string;
          name: string;
          name_ar: string;
          slug: string;
          sort_order: number;
        };
        Insert: {
          gradient_from?: string;
          gradient_to?: string;
          icon?: string;
          id?: string;
          name: string;
          name_ar: string;
          slug: string;
          sort_order?: number;
        };
        Update: {
          gradient_from?: string;
          gradient_to?: string;
          icon?: string;
          id?: string;
          name?: string;
          name_ar?: string;
          slug?: string;
          sort_order?: number;
        };
        Relationships: [];
      };
      downloads: {
        Row: {
          app_id: string;
          app_version: string | null;
          created_at: string;
          file_size: number | null;
          id: string;
          user_id: string | null;
        };
        Insert: {
          app_id: string;
          app_version?: string | null;
          created_at?: string;
          file_size?: number | null;
          id?: string;
          user_id?: string | null;
        };
        Update: {
          app_id?: string;
          app_version?: string | null;
          created_at?: string;
          file_size?: number | null;
          id?: string;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "downloads_app_id_fkey";
            columns: ["app_id"];
            isOneToOne: false;
            referencedRelation: "apps";
            referencedColumns: ["id"];
          },
        ];
      };
      file_scan_jobs: {
        Row: {
          attempts: number;
          completed_at: string | null;
          external_id: string | null;
          file_id: string;
          id: string;
          last_error: string | null;
          provider: string;
          requested_at: string;
          result: Json | null;
          status: Database["public"]["Enums"]["scan_status"];
        };
        Insert: {
          attempts?: number;
          completed_at?: string | null;
          external_id?: string | null;
          file_id: string;
          id?: string;
          last_error?: string | null;
          provider?: string;
          requested_at?: string;
          result?: Json | null;
          status?: Database["public"]["Enums"]["scan_status"];
        };
        Update: {
          attempts?: number;
          completed_at?: string | null;
          external_id?: string | null;
          file_id?: string;
          id?: string;
          last_error?: string | null;
          provider?: string;
          requested_at?: string;
          result?: Json | null;
          status?: Database["public"]["Enums"]["scan_status"];
        };
        Relationships: [
          {
            foreignKeyName: "file_scan_jobs_file_id_fkey";
            columns: ["file_id"];
            isOneToOne: false;
            referencedRelation: "files";
            referencedColumns: ["id"];
          },
        ];
      };
      file_downloads: {
        Row: {
          created_at: string;
          file_id: string;
          id: string;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          file_id: string;
          id?: string;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          file_id?: string;
          id?: string;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "file_downloads_file_id_fkey";
            columns: ["file_id"];
            isOneToOne: false;
            referencedRelation: "files";
            referencedColumns: ["id"];
          },
        ];
      };
      files: {
        Row: {
          created_at: string;
          description: string;
          downloads_count: number;
          file_name: string;
          file_path: string;
          file_size: number;
          id: string;
          mime_type: string | null;
          owner_id: string;
          scan_report: Json | null;
          scan_status: Database["public"]["Enums"]["scan_status"];
          slug: string;
          title: string;
          updated_at: string;
          visibility: string;
        };
        Insert: {
          created_at?: string;
          description?: string;
          downloads_count?: number;
          file_name: string;
          file_path: string;
          file_size?: number;
          id?: string;
          mime_type?: string | null;
          owner_id: string;
          scan_report?: Json | null;
          scan_status?: Database["public"]["Enums"]["scan_status"];
          slug: string;
          title: string;
          updated_at?: string;
          visibility?: string;
        };
        Update: {
          created_at?: string;
          description?: string;
          downloads_count?: number;
          file_name?: string;
          file_path?: string;
          file_size?: number;
          id?: string;
          mime_type?: string | null;
          owner_id?: string;
          scan_report?: Json | null;
          scan_status?: Database["public"]["Enums"]["scan_status"];
          slug?: string;
          title?: string;
          updated_at?: string;
          visibility?: string;
        };
        Relationships: [];
      };
      forum_categories: {
        Row: {
          description_ar: string;
          icon: string;
          id: string;
          name_ar: string;
          slug: string;
          sort_order: number;
        };
        Insert: {
          description_ar?: string;
          icon?: string;
          id?: string;
          name_ar: string;
          slug: string;
          sort_order?: number;
        };
        Update: {
          description_ar?: string;
          icon?: string;
          id?: string;
          name_ar?: string;
          slug?: string;
          sort_order?: number;
        };
        Relationships: [];
      };
      forum_replies: {
        Row: {
          author_id: string;
          body: string;
          created_at: string;
          id: string;
          topic_id: string;
          updated_at: string;
        };
        Insert: {
          author_id: string;
          body: string;
          created_at?: string;
          id?: string;
          topic_id: string;
          updated_at?: string;
        };
        Update: {
          author_id?: string;
          body?: string;
          created_at?: string;
          id?: string;
          topic_id?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "forum_replies_topic_id_fkey";
            columns: ["topic_id"];
            isOneToOne: false;
            referencedRelation: "forum_topics";
            referencedColumns: ["id"];
          },
        ];
      };
      forum_topic_votes: {
        Row: {
          created_at: string;
          id: string;
          topic_id: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          topic_id: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          topic_id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "forum_topic_votes_topic_id_fkey";
            columns: ["topic_id"];
            isOneToOne: false;
            referencedRelation: "forum_topics";
            referencedColumns: ["id"];
          },
        ];
      };
      forum_topics: {
        Row: {
          author_id: string;
          body: string;
          category_id: string;
          created_at: string;
          id: string;
          is_locked: boolean;
          is_pinned: boolean;
          last_activity_at: string;
          replies_count: number;
          title: string;
          updated_at: string;
          votes_count: number;
        };
        Insert: {
          author_id: string;
          body: string;
          category_id: string;
          created_at?: string;
          id?: string;
          is_locked?: boolean;
          is_pinned?: boolean;
          last_activity_at?: string;
          replies_count?: number;
          title: string;
          updated_at?: string;
          votes_count?: number;
        };
        Update: {
          author_id?: string;
          body?: string;
          category_id?: string;
          created_at?: string;
          id?: string;
          is_locked?: boolean;
          is_pinned?: boolean;
          last_activity_at?: string;
          replies_count?: number;
          title?: string;
          updated_at?: string;
          votes_count?: number;
        };
        Relationships: [
          {
            foreignKeyName: "forum_topics_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "forum_categories";
            referencedColumns: ["id"];
          },
        ];
      };
      notifications: {
        Row: {
          body: string | null;
          created_at: string;
          id: string;
          kind: string;
          link: string | null;
          read_at: string | null;
          title: string;
          user_id: string;
        };
        Insert: {
          body?: string | null;
          created_at?: string;
          id?: string;
          kind?: string;
          link?: string | null;
          read_at?: string | null;
          title: string;
          user_id: string;
        };
        Update: {
          body?: string | null;
          created_at?: string;
          id?: string;
          kind?: string;
          link?: string | null;
          read_at?: string | null;
          title?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          avatar_url: string | null;
          created_at: string;
          email: string | null;
          full_name: string | null;
          id: string;
          is_publisher: boolean;
          publisher_name: string | null;
          updated_at: string;
        };
        Insert: {
          avatar_url?: string | null;
          created_at?: string;
          email?: string | null;
          full_name?: string | null;
          id: string;
          is_publisher?: boolean;
          publisher_name?: string | null;
          updated_at?: string;
        };
        Update: {
          avatar_url?: string | null;
          created_at?: string;
          email?: string | null;
          full_name?: string | null;
          id?: string;
          is_publisher?: boolean;
          publisher_name?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      reviews: {
        Row: {
          app_id: string;
          comment: string | null;
          created_at: string;
          id: string;
          rating: number;
          user_id: string;
        };
        Insert: {
          app_id: string;
          comment?: string | null;
          created_at?: string;
          id?: string;
          rating: number;
          user_id: string;
        };
        Update: {
          app_id?: string;
          comment?: string | null;
          created_at?: string;
          id?: string;
          rating?: number;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "reviews_app_id_fkey";
            columns: ["app_id"];
            isOneToOne: false;
            referencedRelation: "apps";
            referencedColumns: ["id"];
          },
        ];
      };
      scan_jobs: {
        Row: {
          attempts: number;
          app_id: string;
          completed_at: string | null;
          external_id: string | null;
          id: string;
          idempotency_key: string | null;
          last_error: string | null;
          next_attempt_at: string | null;
          provider: string;
          requested_at: string;
          result: Json | null;
          status: Database["public"]["Enums"]["scan_status"];
        };
        Insert: {
          attempts?: number;
          app_id: string;
          completed_at?: string | null;
          external_id?: string | null;
          id?: string;
          idempotency_key?: string | null;
          last_error?: string | null;
          next_attempt_at?: string | null;
          provider?: string;
          requested_at?: string;
          result?: Json | null;
          status?: Database["public"]["Enums"]["scan_status"];
        };
        Update: {
          attempts?: number;
          app_id?: string;
          completed_at?: string | null;
          external_id?: string | null;
          id?: string;
          idempotency_key?: string | null;
          last_error?: string | null;
          next_attempt_at?: string | null;
          provider?: string;
          requested_at?: string;
          result?: Json | null;
          status?: Database["public"]["Enums"]["scan_status"];
        };
        Relationships: [
          {
            foreignKeyName: "scan_jobs_app_id_fkey";
            columns: ["app_id"];
            isOneToOne: false;
            referencedRelation: "apps";
            referencedColumns: ["id"];
          },
        ];
      };
      user_roles: {
        Row: {
          created_at: string;
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
      wishlist: {
        Row: {
          app_id: string;
          created_at: string;
          id: string;
          user_id: string;
        };
        Insert: {
          app_id: string;
          created_at?: string;
          id?: string;
          user_id: string;
        };
        Update: {
          app_id?: string;
          created_at?: string;
          id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "wishlist_app_id_fkey";
            columns: ["app_id"];
            isOneToOne: false;
            referencedRelation: "apps";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"];
          _user_id: string;
        };
        Returns: boolean;
      };
      update_publisher_app: {
        Args: {
          _app_id: string;
          _category_id: string;
          _description: string;
          _name: string;
          _tagline: string | null;
          _version: string;
        };
        Returns: Database["public"]["Tables"]["apps"]["Row"];
      };
      record_download: {
        Args: { _app_id: string; _user_id: string | null };
        Returns: undefined;
      };
      record_file_download: {
        Args: { _file_id: string; _user_id: string | null };
        Returns: undefined;
      };
    };
    Enums: {
      app_role: "admin" | "moderator" | "user";
      app_status: "pending" | "approved" | "rejected";
      scan_status: "queued" | "scanning" | "clean" | "flagged" | "failed";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      app_status: ["pending", "approved", "rejected"],
      scan_status: ["queued", "scanning", "clean", "flagged", "failed"],
    },
  },
} as const;
