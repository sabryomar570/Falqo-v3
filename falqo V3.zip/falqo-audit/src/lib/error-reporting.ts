export function reportApplicationError(error: unknown, context: Record<string, unknown> = {}) {
  const message =
    error instanceof Error
      ? error.message
      : error instanceof Response
        ? `Response ${error.status}`
        : String(error);
  console.error("[application-error]", {
    message,
    route: typeof window === "undefined" ? undefined : window.location.pathname,
    ...context,
  });
}
