import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type ForumCategory = Database["public"]["Tables"]["forum_categories"]["Row"];
export type ForumAuthor = { full_name: string | null; avatar_url: string | null };
export type ForumTopic = Database["public"]["Tables"]["forum_topics"]["Row"] & {
  forum_categories?: Pick<ForumCategory, "slug" | "name_ar"> | null;
  author?: ForumAuthor | null;
};
export type ForumReply = Database["public"]["Tables"]["forum_replies"]["Row"] & {
  author?: ForumAuthor | null;
};

async function authorsMap(ids: string[]) {
  const unique = [...new Set(ids)];
  if (unique.length === 0) return {} as Record<string, ForumAuthor>;
  const { data } = await supabase
    .from("profiles")
    .select("id, full_name, avatar_url")
    .in("id", unique);
  const map: Record<string, ForumAuthor> = {};
  for (const row of data ?? []) {
    map[row.id] = { full_name: row.full_name, avatar_url: row.avatar_url };
  }
  return map;
}

export const forumCategoriesQuery = queryOptions({
  queryKey: ["forum", "categories"],
  queryFn: async () => {
    const { data, error } = await supabase.from("forum_categories").select("*").order("sort_order");
    if (error) throw error;
    return (data ?? []) as ForumCategory[];
  },
  staleTime: 1000 * 60 * 10,
});

const topicColumns = "*, forum_categories(slug, name_ar)";

export const forumTopicsQuery = (category: string | undefined, sort: "latest" | "top") =>
  queryOptions({
    queryKey: ["forum", "topics", category ?? "all", sort],
    queryFn: async () => {
      let query = supabase.from("forum_topics").select(topicColumns).limit(50);
      if (category) {
        const { data: cat } = await supabase
          .from("forum_categories")
          .select("id")
          .eq("slug", category)
          .maybeSingle();
        if (!cat) return [] as ForumTopic[];
        query = query.eq("category_id", cat.id);
      }
      query =
        sort === "top"
          ? query
              .order("votes_count", { ascending: false })
              .order("last_activity_at", { ascending: false })
          : query
              .order("is_pinned", { ascending: false })
              .order("last_activity_at", { ascending: false });
      const { data, error } = await query;
      if (error) throw error;
      const topics = (data ?? []) as unknown as ForumTopic[];
      const map = await authorsMap(topics.map((topic) => topic.author_id));
      return topics.map((topic) => ({ ...topic, author: map[topic.author_id] ?? null }));
    },
    staleTime: 1000 * 20,
  });

export const forumTopicQuery = (id: string) =>
  queryOptions({
    queryKey: ["forum", "topic", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("forum_topics")
        .select(topicColumns)
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const topic = data as unknown as ForumTopic;
      const map = await authorsMap([topic.author_id]);
      return { ...topic, author: map[topic.author_id] ?? null };
    },
    staleTime: 1000 * 15,
  });

export const forumRepliesQuery = (topicId: string | undefined) =>
  queryOptions({
    queryKey: ["forum", "replies", topicId],
    enabled: Boolean(topicId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("forum_replies")
        .select("*")
        .eq("topic_id", topicId!)
        .order("created_at");
      if (error) throw error;
      const replies = (data ?? []) as ForumReply[];
      const map = await authorsMap(replies.map((reply) => reply.author_id));
      return replies.map((reply) => ({ ...reply, author: map[reply.author_id] ?? null }));
    },
    staleTime: 1000 * 15,
  });

export const myTopicVotesQuery = queryOptions({
  queryKey: ["forum", "my-votes"],
  queryFn: async () => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [] as string[];
    const { data, error } = await supabase
      .from("forum_topic_votes")
      .select("topic_id")
      .eq("user_id", auth.user.id);
    if (error) throw error;
    return (data ?? []).map((row) => row.topic_id);
  },
  staleTime: 1000 * 20,
});

export async function toggleTopicVote(topicId: string, userId: string, voted: boolean) {
  if (voted) {
    const { error } = await supabase
      .from("forum_topic_votes")
      .delete()
      .eq("topic_id", topicId)
      .eq("user_id", userId);
    if (error) throw error;
    return false;
  }
  const { error } = await supabase
    .from("forum_topic_votes")
    .insert({ topic_id: topicId, user_id: userId });
  if (error) throw error;
  return true;
}
