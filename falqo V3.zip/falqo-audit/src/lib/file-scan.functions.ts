import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const input = z.object({ fileId: z.string().uuid() });
const VT_BASE = "https://www.virustotal.com/api/v3";
const TIMEOUT_MS = 30_000;
type FileScanJob = { id: string; status: string; external_id: string | null };

async function withTimeout<T>(promise: Promise<T>) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error("scanner_timeout")), TIMEOUT_MS);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export const submitSharedFileScan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((value) => input.parse(value))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: owned } = await context.supabase
      .from("files")
      .select("id, owner_id, file_path, file_name")
      .eq("id", data.fileId)
      .maybeSingle();
    const { data: admin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!owned && !admin) throw new Error("Forbidden");
    if (!owned) throw new Error("file_not_found");

    const jobs = supabaseAdmin.from("file_scan_jobs");
    const { data: active } = (await jobs
      .select("id, status, external_id")
      .eq("file_id", data.fileId)
      .in("status", ["queued", "scanning"])
      .order("requested_at", { ascending: false })
      .limit(1)
      .maybeSingle()) as { data: FileScanJob | null };
    if (active)
      return {
        ok: true as const,
        status: active.status as "queued" | "scanning",
        analysisId: active.external_id ?? undefined,
      };

    const apiKey = process.env["VIRUSTOTAL_API_KEY"];
    const { data: job, error: jobError } = (await jobs
      .insert({
        file_id: data.fileId,
        provider: apiKey ? "virustotal" : "manual",
        status: "queued",
      })
      .select("id")
      .single()) as { data: { id: string } | null; error: Error | null };
    if (jobError || !job) throw jobError ?? new Error("scan_job_insert_failed");
    if (!apiKey) return { ok: true as const, status: "queued" as const };

    try {
      const stored = await supabaseAdmin.storage.from("shared-files").download(owned.file_path);
      if (stored.error || !stored.data) throw new Error("file_download_failed");
      const form = new FormData();
      form.append("file", stored.data, owned.file_name);
      const response = await withTimeout(
        fetch(`${VT_BASE}/files`, { method: "POST", headers: { "x-apikey": apiKey }, body: form }),
      );
      if (!response.ok) throw new Error(`provider_http_${response.status}`);
      const payload = (await response.json()) as { data?: { id?: string } };
      if (!payload.data?.id) throw new Error("provider_missing_analysis_id");
      await jobs
        .update({ status: "scanning", external_id: payload.data.id, attempts: 1 })
        .eq("id", job.id);
      await supabaseAdmin.from("files").update({ scan_status: "scanning" }).eq("id", data.fileId);
      return { ok: true as const, status: "scanning" as const, analysisId: payload.data.id };
    } catch (error) {
      const message = error instanceof Error ? error.message : "scanner_error";
      await jobs
        .update({
          status: "failed",
          last_error: message.slice(0, 500),
          completed_at: new Date().toISOString(),
        })
        .eq("id", job.id);
      await supabaseAdmin
        .from("files")
        .update({ scan_status: "failed", scan_report: { error: message.slice(0, 500) } })
        .eq("id", data.fileId);
      console.error("[virustotal] shared file scan failed", error);
      return { ok: false as const, reason: "provider_error" as const };
    }
  });

export const refreshSharedFileScan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((value) => input.parse(value))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: owned } = await context.supabase
      .from("files")
      .select("id")
      .eq("id", data.fileId)
      .maybeSingle();
    const { data: admin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!owned && !admin) throw new Error("Forbidden");
    const apiKey = process.env["VIRUSTOTAL_API_KEY"];
    if (!apiKey) return { ok: false as const, reason: "no_provider" as const };
    const jobs = supabaseAdmin.from("file_scan_jobs");
    const { data: job } = (await jobs
      .select("id, external_id")
      .eq("file_id", data.fileId)
      .eq("provider", "virustotal")
      .order("requested_at", { ascending: false })
      .limit(1)
      .maybeSingle()) as { data: { id: string; external_id: string | null } | null };
    if (!job?.external_id) return { ok: false as const, reason: "no_job" as const };
    try {
      const response = await withTimeout(
        fetch(`${VT_BASE}/analyses/${job.external_id}`, { headers: { "x-apikey": apiKey } }),
      );
      if (!response.ok) throw new Error(`provider_http_${response.status}`);
      const payload = (await response.json()) as {
        data?: { attributes?: { status?: string; stats?: Record<string, number> } };
      };
      const attrs = payload.data?.attributes;
      if (attrs?.status !== "completed") return { ok: true as const, status: "scanning" as const };
      const stats = attrs.stats ?? {};
      const detections = (stats["malicious"] ?? 0) + (stats["suspicious"] ?? 0);
      const status = detections > 0 ? "flagged" : "clean";
      await jobs
        .update({ status, result: { stats, detections }, completed_at: new Date().toISOString() })
        .eq("id", job.id);
      await supabaseAdmin
        .from("files")
        .update({ scan_status: status, scan_report: { stats, detections } })
        .eq("id", data.fileId);
      return { ok: true as const, status: status as "clean" | "flagged" };
    } catch (error) {
      const message = error instanceof Error ? error.message : "scanner_error";
      await jobs
        .update({
          status: "failed",
          last_error: message.slice(0, 500),
          completed_at: new Date().toISOString(),
        })
        .eq("id", job.id);
      await supabaseAdmin
        .from("files")
        .update({ scan_status: "failed", scan_report: { error: message.slice(0, 500) } })
        .eq("id", data.fileId);
      return { ok: false as const, reason: "provider_error" as const };
    }
  });
