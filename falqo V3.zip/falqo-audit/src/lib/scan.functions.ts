import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { SupabaseClient } from "@supabase/supabase-js";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

const appInput = z.object({ appId: z.string().uuid() });
const VT_BASE = "https://www.virustotal.com/api/v3";
const MAX_ATTEMPTS = 3;
const SCAN_TIMEOUT_MS = 30_000;

type ScanResult =
  | {
      ok: true;
      status: "queued" | "scanning" | "clean" | "flagged" | "failed";
      analysisId?: string;
    }
  | {
      ok: false;
      reason:
        "no_provider" | "no_file" | "no_job" | "provider_error" | "forbidden" | "already_scanning";
    };

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error("scanner_timeout")), timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function markScanFailed(
  supabaseAdmin: SupabaseClient<Database>,
  appId: string,
  jobId: string | null,
  error: unknown,
) {
  const message = error instanceof Error ? error.message : "scanner_error";
  if (jobId) {
    await supabaseAdmin
      .from("scan_jobs")
      .update({
        status: "failed",
        last_error: message.slice(0, 500),
        completed_at: new Date().toISOString(),
      })
      .eq("id", jobId);
  }
  await supabaseAdmin
    .from("apps")
    .update({
      scan_status: "failed",
      scan_provider: "virustotal",
      scan_report: { error: message.slice(0, 500) },
    })
    .eq("id", appId);
}

async function assertOwnerOrAdmin(
  context: { supabase: SupabaseClient<Database>; userId: string },
  appId: string,
) {
  const { data: owned } = await context.supabase
    .from("apps")
    .select("id, publisher_id, file_url, file_name, scan_status")
    .eq("id", appId)
    .maybeSingle();
  const { data: isAdmin } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (!owned && !isAdmin) throw new Error("Forbidden");
  return owned;
}

/** Queues an upload for a real provider scan. It never marks a file clean. */
export const submitAppScan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => appInput.parse(input))
  .handler(async ({ data, context }): Promise<ScanResult> => {
    const apiKey = process.env["VIRUSTOTAL_API_KEY"];
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const owned = await assertOwnerOrAdmin(context, data.appId);
    const { data: app } = await supabaseAdmin
      .from("apps")
      .select("id, file_url, file_name, scan_status")
      .eq("id", data.appId)
      .maybeSingle();

    if (!app?.file_url) return { ok: false, reason: "no_file" };
    if (app.scan_status === "scanning") return { ok: false, reason: "already_scanning" };

    const idempotencyKey = `${app.id}:${app.file_url}`;
    const { data: existing } = await supabaseAdmin
      .from("scan_jobs")
      .select("id, status, external_id")
      .eq("idempotency_key", idempotencyKey)
      .in("status", ["scanning", "clean"])
      .maybeSingle();
    if (existing?.status === "clean") {
      return existing.external_id
        ? { ok: true, status: "clean", analysisId: existing.external_id }
        : { ok: true, status: "clean" };
    }
    if (existing?.status === "scanning") return { ok: false, reason: "already_scanning" };

    const { data: job, error: jobError } = await supabaseAdmin
      .from("scan_jobs")
      .insert({
        app_id: app.id,
        provider: apiKey ? "virustotal" : "manual",
        status: "queued",
        idempotency_key: idempotencyKey,
      })
      .select("id")
      .single();
    if (jobError) throw jobError;

    if (!apiKey) {
      await supabaseAdmin
        .from("apps")
        .update({ scan_status: "queued", scan_provider: "manual" })
        .eq("id", app.id);
      return { ok: true, status: "queued" };
    }

    try {
      const file = await supabaseAdmin.storage.from("app-files").download(app.file_url);
      if (file.error || !file.data) throw new Error("file_download_failed");
      const form = new FormData();
      form.append("file", file.data, app.file_name ?? "app.bin");
      const response = await withTimeout(
        fetch(`${VT_BASE}/files`, { method: "POST", headers: { "x-apikey": apiKey }, body: form }),
        SCAN_TIMEOUT_MS,
      );
      if (!response.ok) throw new Error(`provider_http_${response.status}`);
      const payload = (await response.json()) as { data?: { id?: string } };
      const analysisId = payload.data?.id;
      if (!analysisId) throw new Error("provider_missing_analysis_id");

      await supabaseAdmin
        .from("scan_jobs")
        .update({
          status: "scanning",
          external_id: analysisId,
          attempts: 1,
          next_attempt_at: new Date(Date.now() + 15_000).toISOString(),
        })
        .eq("id", job.id);
      await supabaseAdmin
        .from("apps")
        .update({ scan_status: "scanning", scan_provider: "virustotal" })
        .eq("id", app.id);
      return { ok: true, status: "scanning", analysisId };
    } catch (error) {
      await markScanFailed(supabaseAdmin, app.id, job.id, error);
      console.error("[virustotal] scan submission failed", error);
      return { ok: false, reason: "provider_error" };
    }
  });

/** Polls VirusTotal and applies a verdict only after a completed response. */
export const refreshAppScan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => appInput.parse(input))
  .handler(async ({ data, context }): Promise<ScanResult> => {
    const apiKey = process.env["VIRUSTOTAL_API_KEY"];
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await assertOwnerOrAdmin(context, data.appId);
    if (!apiKey) return { ok: false, reason: "no_provider" };

    const { data: job } = await supabaseAdmin
      .from("scan_jobs")
      .select("id, external_id, status, attempts")
      .eq("app_id", data.appId)
      .eq("provider", "virustotal")
      .order("requested_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (!job?.external_id) return { ok: false, reason: "no_job" };

    try {
      const response = await withTimeout(
        fetch(`${VT_BASE}/analyses/${job.external_id}`, { headers: { "x-apikey": apiKey } }),
        SCAN_TIMEOUT_MS,
      );
      if (!response.ok) throw new Error(`provider_http_${response.status}`);
      const payload = (await response.json()) as {
        data?: { attributes?: { status?: string; stats?: Record<string, number> } };
      };
      const attributes = payload.data?.attributes;
      if (attributes?.status !== "completed") return { ok: true, status: "scanning" };

      const stats = attributes.stats ?? {};
      const detections = (stats["malicious"] ?? 0) + (stats["suspicious"] ?? 0);
      const verdict = detections > 0 ? "flagged" : "clean";
      const report = { provider: "virustotal", stats, detections };
      await supabaseAdmin
        .from("scan_jobs")
        .update({
          status: verdict,
          result: report,
          completed_at: new Date().toISOString(),
          last_error: null,
        })
        .eq("id", job.id);
      await supabaseAdmin
        .from("apps")
        .update({
          scan_status: verdict,
          scan_provider: "virustotal",
          scan_report: report,
          scanned_at: new Date().toISOString(),
        })
        .eq("id", data.appId);
      return { ok: true, status: verdict };
    } catch (error) {
      await markScanFailed(supabaseAdmin, data.appId, job.id, error);
      console.error("[virustotal] analysis refresh failed", error);
      return { ok: false, reason: "provider_error" };
    }
  });

/** Allows a publisher/admin to retry a failed scan with a new idempotency key. */
export const retryAppScan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => appInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const app = await assertOwnerOrAdmin(context, data.appId);
    if (!app) throw new Error("Forbidden");
    const { data: latest } = await supabaseAdmin
      .from("scan_jobs")
      .select("attempts, status")
      .eq("app_id", data.appId)
      .order("requested_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if ((latest?.attempts ?? 0) >= MAX_ATTEMPTS)
      return { ok: false as const, reason: "retry_limit" as const };
    await supabaseAdmin
      .from("apps")
      .update({ scan_status: "queued", scan_report: null })
      .eq("id", data.appId);
    return { ok: true as const, status: "queued" as const };
  });
