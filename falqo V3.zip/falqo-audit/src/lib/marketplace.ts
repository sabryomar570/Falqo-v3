import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";

export type Category = {
  id: string;
  slug: string;
  name: string;
  name_ar: string;
  icon: string;
  gradient_from: string;
  gradient_to: string;
  sort_order: number;
};

export type AppStatus = "pending" | "approved" | "rejected";
export type ScanStatus = "queued" | "scanning" | "clean" | "flagged" | "failed";

export type AppRow = {
  id: string;
  publisher_id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string;
  category_id: string | null;
  icon_url: string | null;
  screenshots: string[];
  file_url: string | null;
  file_name: string | null;
  file_size: number;
  version: string;
  platform: string;
  downloads_count: number;
  rating_avg: number;
  rating_count: number;
  status: AppStatus;
  rejection_reason: string | null;
  scan_status: ScanStatus;
  scan_provider: string | null;
  is_featured: boolean;
  is_free: boolean;
  price_cents: number;
  currency: string;
  published_at: string | null;
  created_at: string;
  updated_at: string;
  categories?: Category | null;
};

const APP_SELECT =
  "*, categories:category_id (id, slug, name, name_ar, icon, gradient_from, gradient_to, sort_order)";

export const categoriesQuery = queryOptions({
  queryKey: ["categories"],
  queryFn: async (): Promise<Category[]> => {
    const { data, error } = await supabase.from("categories").select("*").order("sort_order");
    if (error) throw error;
    return (data ?? []) as Category[];
  },
  staleTime: 1000 * 60 * 10,
});

export type BrowseFilters = {
  search?: string;
  category?: string;
  minRating?: number;
  sort?: "newest" | "downloads" | "rating";
  featuredOnly?: boolean;
  limit?: number;
  offset?: number;
};

export function browseAppsQuery(filters: BrowseFilters = {}) {
  return queryOptions({
    queryKey: ["apps", "browse", filters],
    queryFn: async (): Promise<AppRow[]> => {
      let categoryId: string | undefined;
      if (filters.category) {
        const { data: category, error: categoryError } = await supabase
          .from("categories")
          .select("id")
          .eq("slug", filters.category)
          .maybeSingle();
        if (categoryError) throw categoryError;
        categoryId = category?.id;
        if (!categoryId) return [];
      }
      let query = supabase
        .from("apps")
        .select(APP_SELECT)
        .eq("status", "approved")
        .eq("scan_status", "clean");

      if (filters.search) query = query.ilike("name", `%${filters.search}%`);
      if (filters.featuredOnly) query = query.eq("is_featured", true);
      if (filters.minRating) query = query.gte("rating_avg", filters.minRating);
      if (categoryId) query = query.eq("category_id", categoryId);

      if (filters.sort === "downloads")
        query = query.order("downloads_count", { ascending: false });
      else if (filters.sort === "rating") query = query.order("rating_avg", { ascending: false });
      else query = query.order("created_at", { ascending: false });

      const limit = Math.min(Math.max(filters.limit ?? 48, 1), 100);
      const offset = Math.max(filters.offset ?? 0, 0);
      const { data, error } = await query.range(offset, offset + limit - 1);
      if (error) throw error;
      return (data ?? []) as AppRow[];
    },
  });
}

export function appBySlugQuery(slug: string) {
  return queryOptions({
    queryKey: ["apps", "detail", slug],
    queryFn: async (): Promise<AppRow | null> => {
      const { data, error } = await supabase
        .from("apps")
        .select(APP_SELECT)
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return (data as AppRow) ?? null;
    },
  });
}

export type Review = {
  id: string;
  app_id: string;
  user_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  profiles?: { full_name: string | null; avatar_url: string | null } | null;
};

export function reviewsQuery(appId?: string) {
  return queryOptions({
    queryKey: ["reviews", appId],
    queryFn: async (): Promise<Review[]> => {
      const { data, error } = await supabase
        .from("reviews")
        .select("*")
        .eq("app_id", appId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      const rows = (data ?? []) as Omit<Review, "profiles">[];
      if (rows.length === 0) return [];
      const { data: people } = await supabase
        .from("profiles")
        .select("id, full_name, avatar_url")
        .in("id", [...new Set(rows.map((row) => row.user_id))]);
      const byId = new Map((people ?? []).map((person) => [person.id, person]));
      return rows.map((row) => ({ ...row, profiles: byId.get(row.user_id) ?? null }));
    },

    enabled: Boolean(appId),
  });
}

export const myAppsQuery = queryOptions({
  queryKey: ["apps", "mine"],
  queryFn: async (): Promise<AppRow[]> => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [];
    const { data, error } = await supabase
      .from("apps")
      .select(APP_SELECT)
      .eq("publisher_id", auth.user.id)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as AppRow[];
  },
});

export function adminAppsQuery(status?: AppStatus) {
  return queryOptions({
    queryKey: ["apps", "admin", status ?? "all"],
    queryFn: async (): Promise<AppRow[]> => {
      let query = supabase
        .from("apps")
        .select(APP_SELECT)
        .order("created_at", { ascending: false });
      if (status) query = query.eq("status", status);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as AppRow[];
    },
  });
}

export const adminStatsQuery = queryOptions({
  queryKey: ["admin", "stats"],
  queryFn: async () => {
    const [apps, publishers, downloads] = await Promise.all([
      supabase.from("apps").select("id", { count: "exact", head: true }),
      supabase
        .from("profiles")
        .select("id", { count: "exact", head: true })
        .eq("is_publisher", true),
      supabase.from("apps").select("downloads_count"),
    ]);
    const totalDownloads = (downloads.data ?? []).reduce(
      (sum, row: { downloads_count: number }) => sum + Number(row.downloads_count ?? 0),
      0,
    );
    return {
      apps: apps.count ?? 0,
      publishers: publishers.count ?? 0,
      downloads: totalDownloads,
    };
  },
});

export const STATUS_LABEL: Record<AppStatus, string> = {
  pending: "قيد المراجعة",
  approved: "مقبول",
  rejected: "مرفوض",
};

export const SCAN_LABEL: Record<ScanStatus, string> = {
  queued: "في انتظار الفحص",
  scanning: "قيد الفحص",
  clean: "آمن",
  flagged: "تم الحظر",
  failed: "فشل الفحص",
};
