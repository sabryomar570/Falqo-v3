import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";

export type DownloadEvent = {
  id: string;
  app_id: string;
  user_id: string | null;
  app_version: string | null;
  file_size: number | null;
  created_at: string;
};

export type AppDownloadStats = {
  total: number;
  today: number;
  week: number;
  events: DownloadEvent[];
};

/** Real download events for the publisher's own apps (RLS-scoped). */
export function publisherDownloadsQuery(appIds: string[]) {
  const key = [...appIds].sort();
  return queryOptions({
    queryKey: ["publisher", "downloads", key],
    enabled: appIds.length > 0,
    queryFn: async (): Promise<Record<string, AppDownloadStats>> => {
      const { data, error } = await supabase
        .from("downloads")
        .select("id, app_id, user_id, app_version, file_size, created_at")
        .in("app_id", appIds)
        .order("created_at", { ascending: false })
        .limit(500);
      if (error) throw error;

      const now = Date.now();
      const dayAgo = now - 1000 * 60 * 60 * 24;
      const weekAgo = now - 1000 * 60 * 60 * 24 * 7;
      const stats: Record<string, AppDownloadStats> = {};

      for (const appId of appIds) {
        stats[appId] = { total: 0, today: 0, week: 0, events: [] };
      }

      for (const row of (data ?? []) as DownloadEvent[]) {
        const bucket = stats[row.app_id];
        if (!bucket) continue;
        bucket.total += 1;
        const time = new Date(row.created_at).getTime();
        if (time >= dayAgo) bucket.today += 1;
        if (time >= weekAgo) bucket.week += 1;
        if (bucket.events.length < 20) bucket.events.push(row);
      }

      return stats;
    },
    staleTime: 1000 * 30,
  });
}
