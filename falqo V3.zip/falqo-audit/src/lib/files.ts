import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { validateUploadFile } from "@/lib/storage";

export type FileRow = Database["public"]["Tables"]["files"]["Row"];
export const SHARED_BUCKET = "shared-files";

const publicColumns =
  "id, slug, title, description, file_name, file_size, mime_type, downloads_count, scan_status, visibility, created_at, updated_at, owner_id";

export const publicFilesQuery = (search: string) =>
  queryOptions({
    queryKey: ["files", "public", search],
    queryFn: async () => {
      let query = supabase
        .from("files")
        .select(publicColumns)
        .eq("visibility", "public")
        .neq("scan_status", "flagged")
        .order("created_at", { ascending: false })
        .limit(60);
      if (search.trim()) query = query.ilike("title", `%${search.trim()}%`);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as FileRow[];
    },
    staleTime: 1000 * 30,
  });

export const fileBySlugQuery = (slug: string) =>
  queryOptions({
    queryKey: ["files", "detail", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("files")
        .select(publicColumns)
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as FileRow | null;
    },
    staleTime: 1000 * 30,
  });

export const myFilesQuery = queryOptions({
  queryKey: ["files", "mine"],
  queryFn: async () => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [] as FileRow[];
    const { data, error } = await supabase
      .from("files")
      .select("*")
      .eq("owner_id", auth.user.id)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as FileRow[];
  },
  staleTime: 1000 * 15,
});

export function fileSlug(title: string) {
  const base = title
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "");
  return `${base || "file"}-${Math.random().toString(36).slice(2, 7)}`;
}

export async function uploadSharedFile(userId: string, file: File) {
  const { safeName } = validateUploadFile(file, "shared");
  const path = `${userId}/${crypto.randomUUID()}-${safeName}`;
  const { error } = await supabase.storage.from(SHARED_BUCKET).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    ...(file.type ? { contentType: file.type } : {}),
  });
  if (error) throw error;
  return path;
}
