import { supabase } from "@/integrations/supabase/client";

export const BUCKETS = {
  icons: "app-icons",
  screenshots: "app-screenshots",
  files: "app-files",
} as const;

export type BucketName = (typeof BUCKETS)[keyof typeof BUCKETS];
import { validateUploadFile } from "@/lib/upload-validation";
import type { UploadKind } from "@/lib/upload-validation";

export { MAX_UPLOAD_BYTES, sanitizeFilename, validateUploadFile } from "@/lib/upload-validation";
export type { UploadKind } from "@/lib/upload-validation";

export async function getSignedUrl(bucket: BucketName, path: string, expiresIn = 3600) {
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, expiresIn);
  if (error) return null;
  return data.signedUrl;
}

export async function getSignedUrls(bucket: BucketName, paths: string[], expiresIn = 3600) {
  if (paths.length === 0) return [];
  const { data, error } = await supabase.storage.from(bucket).createSignedUrls(paths, expiresIn);
  if (error || !data) return [];
  return data.map((entry) => entry.signedUrl).filter(Boolean) as string[];
}

export async function uploadFile(bucket: BucketName, userId: string, file: File, kind: UploadKind) {
  const { safeName } = validateUploadFile(file, kind);
  const path = `${userId}/${crypto.randomUUID()}-${safeName}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    ...(file.type ? { contentType: file.type } : {}),
  });
  if (error) throw error;
  return path;
}

export function formatBytes(bytes: number) {
  if (!bytes) return "—";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value < 10 && unit > 0 ? 1 : 0)} ${units[unit]}`;
}

export function slugify(name: string) {
  const base = name
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "");
  return `${base || "app"}-${Math.random().toString(36).slice(2, 7)}`;
}
