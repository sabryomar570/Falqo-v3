export type UploadKind = "icon" | "screenshot" | "app" | "shared";

export const MAX_UPLOAD_BYTES = {
  icon: 5 * 1024 * 1024,
  screenshot: 8 * 1024 * 1024,
  app: 250 * 1024 * 1024,
  shared: 50 * 1024 * 1024,
} as const;

const IMAGE_EXTENSIONS = new Set(["png", "jpg", "jpeg", "webp", "gif"]);
const APP_EXTENSIONS = new Set([
  "apk",
  "aab",
  "ipa",
  "zip",
  "tar",
  "gz",
  "tgz",
  "deb",
  "rpm",
  "dmg",
  "exe",
  "msi",
  "bin",
]);
const BLOCKED_EXTENSIONS = new Set([
  "html",
  "htm",
  "js",
  "mjs",
  "cjs",
  "php",
  "phtml",
  "sh",
  "bash",
  "zsh",
  "bat",
  "cmd",
  "ps1",
  "vbs",
  "jar",
]);

function extensionOf(name: string) {
  return name.toLowerCase().split(".").pop() ?? "";
}

export function sanitizeFilename(name: string) {
  const basename = name.replace(/\\/g, "/").split("/").pop() ?? "file";
  return (
    basename
      .normalize("NFKC")
      .replace(/[^a-zA-Z0-9._-]/g, "_")
      .replace(/_+/g, "_")
      .replace(/_+\./g, ".")
      .replace(/\.{2,}/g, ".")
      .replace(/^\.+/, "")
      .slice(0, 120) || "file"
  );
}

export function validateUploadFile(file: File, kind: UploadKind) {
  if (file.size <= 0) throw new Error("empty_file");
  if (file.size > MAX_UPLOAD_BYTES[kind]) throw new Error("file_too_large");
  const extension = extensionOf(file.name);
  if (BLOCKED_EXTENSIONS.has(extension)) throw new Error("blocked_file_type");
  if (
    (kind === "icon" || kind === "screenshot") &&
    (!IMAGE_EXTENSIONS.has(extension) || !file.type.startsWith("image/"))
  )
    throw new Error("invalid_image_type");
  if (kind === "app" && !APP_EXTENSIONS.has(extension)) throw new Error("invalid_app_type");
  return { safeName: sanitizeFilename(file.name), extension };
}
