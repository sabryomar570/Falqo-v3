import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";

const inputSchema = z.object({ slug: z.string().trim().min(1).max(120) });

export const requestAppDownload = createServerFn({ method: "POST" })
  .inputValidator((input) => inputSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: app, error } = await supabaseAdmin
      .from("apps")
      .select("id, name, status, scan_status, file_url, file_name, version")
      .eq("slug", data.slug)
      .maybeSingle();

    if (error) throw new Error("download_lookup_failed");
    if (!app) return { ok: false as const, reason: "not_found" as const };
    if (app.status !== "approved" || app.scan_status !== "clean") {
      return { ok: false as const, reason: "not_available" as const };
    }
    if (!app.file_url) return { ok: false as const, reason: "no_file" as const };

    // Identify the caller when a valid session token is attached.
    let userId: string | null = null;
    const authHeader = getRequestHeader("authorization");
    if (authHeader?.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      if (token.split(".").length === 3) {
        const { data: userData } = await supabaseAdmin.auth.getUser(token);
        userId = userData.user?.id ?? null;
      }
    }

    const signed = await supabaseAdmin.storage.from("app-files").createSignedUrl(app.file_url, 60, {
      download: app.file_name ?? `${app.name}-${app.version}`,
    });

    if (signed.error || !signed.data?.signedUrl) {
      return { ok: false as const, reason: "no_file" as const };
    }

    const { error: recordError } = await supabaseAdmin.rpc("record_download", {
      _app_id: app.id,
      // anonymous downloads are recorded with a null user
      _user_id: userId as unknown as string,
    });
    if (recordError) return { ok: false as const, reason: "not_available" as const };

    return {
      ok: true as const,
      url: signed.data.signedUrl,
      fileName: app.file_name ?? `${app.name}-${app.version}`,
    };
  });
