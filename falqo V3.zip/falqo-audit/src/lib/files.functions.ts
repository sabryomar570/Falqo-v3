import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";

const inputSchema = z.object({ slug: z.string().trim().min(1).max(160) });

/** Issues a short-lived direct download link for a shared file and records the event. */
export const requestSharedFileDownload = createServerFn({ method: "POST" })
  .inputValidator((input) => inputSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: file, error } = await supabaseAdmin
      .from("files")
      .select("id, owner_id, title, file_path, file_name, visibility, scan_status")
      .eq("slug", data.slug)
      .maybeSingle();

    if (error) throw new Error("file_lookup_failed");
    if (!file) return { ok: false as const, reason: "not_found" as const };
    if (file.scan_status !== "clean") {
      return { ok: false as const, reason: "not_available" as const };
    }

    // Identify the caller when a valid session token is attached.
    let userId: string | null = null;
    const authHeader = getRequestHeader("authorization");
    if (authHeader?.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      if (token.split(".").length === 3) {
        const { data: userData } = await supabaseAdmin.auth.getUser(token);
        userId = userData.user?.id ?? null;
      }
    }

    // Private files are only downloadable by their owner.
    if (file.visibility !== "public" && userId !== file.owner_id) {
      return { ok: false as const, reason: "private" as const };
    }

    const signed = await supabaseAdmin.storage
      .from("shared-files")
      .createSignedUrl(file.file_path, 90, { download: file.file_name });

    if (signed.error || !signed.data?.signedUrl) {
      return { ok: false as const, reason: "not_available" as const };
    }

    const { error: recordError } = await supabaseAdmin.rpc("record_file_download", {
      _file_id: file.id,
      _user_id: userId,
    });
    if (recordError) return { ok: false as const, reason: "not_available" as const };

    return {
      ok: true as const,
      url: signed.data.signedUrl,
      fileName: file.file_name,
    };
  });
