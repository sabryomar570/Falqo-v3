import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import type { AppRow } from "@/lib/marketplace";

const APP_SELECT =
  "*, categories:category_id (id, slug, name, name_ar, icon, gradient_from, gradient_to, sort_order)";

/* ---------------- Wishlist ---------------- */

export const wishlistIdsQuery = queryOptions({
  queryKey: ["wishlist", "ids"],
  queryFn: async (): Promise<string[]> => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [];
    const { data, error } = await supabase.from("wishlist").select("app_id");
    if (error) throw error;
    return (data ?? []).map((row: { app_id: string }) => row.app_id);
  },
  staleTime: 1000 * 30,
});

export const wishlistAppsQuery = queryOptions({
  queryKey: ["wishlist", "apps"],
  queryFn: async (): Promise<AppRow[]> => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [];
    const { data, error } = await supabase
      .from("wishlist")
      .select(`app_id, created_at, apps:app_id (${APP_SELECT})`)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? [])
      .map((row: { apps: AppRow | null }) => row.apps)
      .filter((app): app is AppRow => Boolean(app));
  },
});

export async function toggleWishlist(appId: string, wanted: boolean) {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error("سجّل الدخول أولًا");
  if (wanted) {
    const { error } = await supabase
      .from("wishlist")
      .insert({ app_id: appId, user_id: auth.user.id });
    if (error && error.code !== "23505") throw error;
  } else {
    const { error } = await supabase.from("wishlist").delete().eq("app_id", appId);
    if (error) throw error;
  }
}

/* ---------------- Download history ---------------- */

export const myDownloadsQuery = queryOptions({
  queryKey: ["downloads", "mine"],
  queryFn: async (): Promise<{ id: string; created_at: string; app: AppRow | null }[]> => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [];
    const { data, error } = await supabase
      .from("downloads")
      .select(`id, created_at, apps:app_id (${APP_SELECT})`)
      .order("created_at", { ascending: false })
      .limit(60);
    if (error) throw error;
    return (data ?? []).map((row: { id: string; created_at: string; apps: AppRow | null }) => ({
      id: row.id,
      created_at: row.created_at,
      app: row.apps,
    }));
  },
});

/* ---------------- Notifications ---------------- */

export type Notification = {
  id: string;
  kind: string;
  title: string;
  body: string | null;
  link: string | null;
  read_at: string | null;
  created_at: string;
};

export const notificationsQuery = queryOptions({
  queryKey: ["notifications"],
  queryFn: async (): Promise<Notification[]> => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return [];
    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw error;
    return (data ?? []) as Notification[];
  },
  staleTime: 1000 * 20,
});

export async function markNotificationsRead(ids?: string[]) {
  let query = supabase.from("notifications").update({ read_at: new Date().toISOString() });
  if (ids?.length) query = query.in("id", ids);
  else query = query.is("read_at", null);
  const { error } = await query;
  if (error) throw error;
}

export async function deleteNotification(id: string) {
  const { error } = await supabase.from("notifications").delete().eq("id", id);
  if (error) throw error;
}

/* ---------------- Reports ---------------- */

export const REPORT_REASONS = [
  { value: "malware", label: "ملف ضار أو مشبوه" },
  { value: "misleading", label: "وصف مضلل" },
  { value: "copyright", label: "انتهاك حقوق ملكية" },
  { value: "inappropriate", label: "محتوى غير لائق" },
  { value: "other", label: "سبب آخر" },
] as const;

export async function reportApp(input: { appId: string; reason: string; details?: string }) {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error("سجّل الدخول أولًا");
  const { error } = await supabase.from("app_reports").insert({
    app_id: input.appId,
    reporter_id: auth.user.id,
    reason: input.reason,
    details: input.details ?? null,
  });
  if (error) throw error;
}

export const adminReportsQuery = queryOptions({
  queryKey: ["admin", "reports"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("app_reports")
      .select("id, app_id, reason, details, status, created_at, apps:app_id (name, slug)")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw error;
    return (data ?? []) as {
      id: string;
      app_id: string;
      reason: string;
      details: string | null;
      status: string;
      created_at: string;
      apps: { name: string; slug: string } | null;
    }[];
  },
});
