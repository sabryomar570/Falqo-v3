import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { Flag } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { saveIntendedPath, useAuth } from "@/hooks/useAuth";
import { REPORT_REASONS, reportApp } from "@/lib/community";

export function ReportAppDialog({ appId }: { appId: string }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState<string>(REPORT_REASONS[0].value);
  const [details, setDetails] = useState("");

  const submit = useMutation({
    mutationFn: () => {
      const trimmed = details.trim();
      return reportApp({ appId, reason, ...(trimmed ? { details: trimmed } : {}) });
    },
    onSuccess: () => {
      toast.success("وصل بلاغك إلى فريق المراجعة");
      setOpen(false);
      setDetails("");
    },
    onError: () => toast.error("تعذّر إرسال البلاغ"),
  });

  if (!user) {
    return (
      <Button
        variant="ghost"
        size="sm"
        className="text-muted-foreground"
        onClick={() => {
          saveIntendedPath(pathname);
          void navigate({ to: "/auth" });
        }}
      >
        <Flag />
        إبلاغ
      </Button>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="text-muted-foreground">
          <Flag />
          إبلاغ
        </Button>
      </DialogTrigger>
      <DialogContent className="glass-strong rounded-4xl border-glass-border sm:max-w-md">
        <DialogHeader>
          <DialogTitle>الإبلاغ عن التطبيق</DialogTitle>
          <DialogDescription>
            اختر السبب الأقرب للمشكلة. تصل البلاغات إلى فريق المراجعة والأمان.
          </DialogDescription>
        </DialogHeader>

        <RadioGroup value={reason} onValueChange={setReason} className="gap-2">
          {REPORT_REASONS.map((item) => (
            <div
              key={item.value}
              className="flex items-center gap-2.5 rounded-2xl bg-card/60 px-3.5 py-2.5"
            >
              <RadioGroupItem value={item.value} id={`reason-${item.value}`} />
              <Label htmlFor={`reason-${item.value}`} className="text-sm font-medium">
                {item.label}
              </Label>
            </div>
          ))}
        </RadioGroup>

        <Textarea
          value={details}
          maxLength={1000}
          onChange={(event) => setDetails(event.target.value)}
          placeholder="تفاصيل إضافية (اختياري)"
          className="rounded-2xl bg-card/70"
        />

        <Button variant="hero" disabled={submit.isPending} onClick={() => submit.mutate()}>
          إرسال البلاغ
        </Button>
      </DialogContent>
    </Dialog>
  );
}
