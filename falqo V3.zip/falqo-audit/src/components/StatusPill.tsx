import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  ScanLine,
  ShieldAlert,
  ShieldCheck,
  XCircle,
} from "lucide-react";

import { SCAN_LABEL, STATUS_LABEL, type AppStatus, type ScanStatus } from "@/lib/marketplace";
import { cn } from "@/lib/utils";

const base =
  "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold glass-subtle";

export function StatusPill({ status }: { status: AppStatus }) {
  const styles: Record<AppStatus, string> = {
    pending: "text-warning-foreground",
    approved: "text-success-foreground",
    rejected: "text-destructive",
  };
  const Icon = status === "approved" ? CheckCircle2 : status === "rejected" ? XCircle : Clock;
  return (
    <span className={cn(base, styles[status])}>
      <Icon className="size-3.5" />
      {STATUS_LABEL[status]}
    </span>
  );
}

export function ScanPill({ status }: { status: ScanStatus }) {
  const styles: Record<ScanStatus, string> = {
    queued: "text-muted-foreground",
    scanning: "text-primary",
    clean: "text-success-foreground",
    flagged: "text-destructive",
    failed: "text-destructive",
  };
  const Icon =
    status === "clean"
      ? ShieldCheck
      : status === "flagged"
        ? ShieldAlert
        : status === "failed"
          ? AlertTriangle
          : status === "scanning"
            ? ScanLine
            : Clock;
  return (
    <span className={cn(base, styles[status])}>
      <Icon className="size-3.5" />
      {SCAN_LABEL[status]}
    </span>
  );
}
