import { useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Heart,
  LayoutDashboard,
  LogOut,
  Menu,
  Search,
  Shield,
  ShieldCheck,
  User,
  X,
} from "lucide-react";

import { InstallAppButton } from "@/components/InstallAppButton";
import { NotificationBell } from "@/components/NotificationBell";
import { Button } from "@/components/ui/button";
import { useAuth, saveIntendedPath } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "الرئيسية" },
  { to: "/browse", label: "استكشاف" },
  { to: "/files", label: "الملفات" },
  { to: "/community", label: "المجتمع" },
  { to: "/trust-safety", label: "معايير الأمان" },
] as const;

export function SiteHeader() {
  const { user, profile, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 px-3 pt-3 sm:px-5 sm:pt-4">
      <div className="glass-strong mx-auto flex max-w-6xl items-center gap-2 rounded-full px-3 py-2 sm:px-4">
        <Link to="/" className="flex items-center gap-2 px-1.5 sm:px-2">
          <span className="grid size-8 place-items-center rounded-xl bg-gradient-to-b from-primary-glow to-primary text-primary-foreground shadow-[var(--glow-primary)]">
            <ShieldCheck className="size-4" />
          </span>
          <span className="text-lg font-bold tracking-tight">FALQO</span>
        </Link>

        <nav className="mx-1 hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "rounded-full px-3.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
                pathname === item.to && "bg-accent text-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ms-auto flex items-center gap-2">
          <InstallAppButton className="hidden sm:inline-flex" />
          <Button
            variant="ghost"
            size="iconSm"
            aria-label="بحث"
            onClick={() => navigate({ to: "/browse" })}
          >
            <Search />
          </Button>

          {user ? (
            <div className="hidden items-center gap-1.5 md:flex">
              {isAdmin && (
                <Button variant="ghost" size="iconSm" aria-label="لوحة المشرف" asChild>
                  <Link to="/admin">
                    <Shield />
                  </Link>
                </Button>
              )}
              <Button variant="ghost" size="iconSm" aria-label="لوحة الناشر" asChild>
                <Link to="/publisher">
                  <LayoutDashboard />
                </Link>
              </Button>
              <Button variant="ghost" size="iconSm" aria-label="المفضلة" asChild>
                <Link to="/wishlist">
                  <Heart />
                </Link>
              </Button>
              <NotificationBell />
              <Link to="/profile" aria-label="الملف الشخصي">
                {profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt={profile.full_name ?? "الحساب"}
                    className="size-9 rounded-full border border-glass-border object-cover shadow-[var(--shadow-soft)]"
                  />
                ) : (
                  <span className="grid size-9 place-items-center rounded-full bg-muted">
                    <User className="size-4" />
                  </span>
                )}
              </Link>
              <Button
                variant="ghost"
                size="iconSm"
                aria-label="خروج"
                onClick={() => void signOut()}
              >
                <LogOut />
              </Button>
            </div>
          ) : (
            <Button
              variant="hero"
              size="sm"
              className="hidden md:inline-flex"
              onClick={() => {
                saveIntendedPath(pathname);
                navigate({ to: "/auth" });
              }}
            >
              تسجيل الدخول
            </Button>
          )}

          <Button
            variant="ghost"
            size="iconSm"
            className="md:hidden"
            aria-label="القائمة"
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {open && (
        <div className="glass-strong mx-auto mt-2 max-w-6xl rounded-3xl p-3 md:hidden">
          <div className="flex flex-col gap-1">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
              >
                {item.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link
                  to="/publisher"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
                >
                  لوحة الناشر
                </Link>
                <Link
                  to="/wishlist"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
                >
                  المفضلة
                </Link>
                <Link
                  to="/downloads"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
                >
                  تحميلاتي
                </Link>
                <Link
                  to="/notifications"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
                >
                  الإشعارات
                </Link>
                <Link
                  to="/profile"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
                >
                  الملف الشخصي
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setOpen(false)}
                    className="rounded-2xl px-4 py-3 text-sm font-medium hover:bg-accent"
                  >
                    لوحة المشرف
                  </Link>
                )}
                <Button
                  variant="glass"
                  className="mt-1"
                  onClick={() => {
                    setOpen(false);
                    void signOut();
                  }}
                >
                  تسجيل الخروج
                </Button>
              </>
            ) : (
              <Button
                variant="hero"
                className="mt-1"
                onClick={() => {
                  setOpen(false);
                  saveIntendedPath(pathname);
                  navigate({ to: "/auth" });
                }}
              >
                تسجيل الدخول عبر Google
              </Button>
            )}
            <InstallAppButton className="mt-1 w-full" />
          </div>
        </div>
      )}
    </header>
  );
}
