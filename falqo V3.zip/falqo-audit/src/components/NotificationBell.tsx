import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Bell } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { notificationsQuery } from "@/lib/community";

export function NotificationBell() {
  const { user } = useAuth();
  const notifications = useQuery({ ...notificationsQuery, enabled: Boolean(user) });
  const unread = (notifications.data ?? []).filter((item) => !item.read_at).length;

  if (!user) return null;

  return (
    <Button variant="ghost" size="iconSm" aria-label="الإشعارات" asChild>
      <Link to="/notifications" className="relative">
        <Bell />
        {unread > 0 ? (
          <span className="absolute -end-0.5 -top-0.5 grid min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold leading-4 text-primary-foreground">
            {unread > 9 ? "9+" : unread}
          </span>
        ) : null}
      </Link>
    </Button>
  );
}
