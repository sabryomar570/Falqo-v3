import { useQuery } from "@tanstack/react-query";
import { Boxes } from "lucide-react";

import { getSignedUrl, type BucketName } from "@/lib/storage";
import { cn } from "@/lib/utils";

export function useSignedUrl(bucket: BucketName, path?: string | null) {
  return useQuery({
    queryKey: ["signed-url", bucket, path],
    queryFn: () => getSignedUrl(bucket, path!),
    enabled: Boolean(path),
    staleTime: 1000 * 60 * 30,
  });
}

export function SignedImage({
  bucket,
  path,
  alt,
  className,
  fallbackLabel,
}: {
  bucket: BucketName;
  path?: string | null | undefined;
  alt: string;
  className?: string | undefined;
  fallbackLabel?: string | undefined;
}) {
  const { data } = useSignedUrl(bucket, path);

  if (!data) {
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-gradient-to-br from-muted to-secondary text-muted-foreground",
          className,
        )}
        aria-label={fallbackLabel ?? alt}
        title={fallbackLabel ?? alt}
      >
        <Boxes className="size-1/2" aria-hidden />
      </div>
    );
  }

  return <img src={data} alt={alt} loading="lazy" className={className} />;
}
