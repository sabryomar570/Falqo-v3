import type { ReactNode } from "react";

export type LegalSection = { heading: string; body: string[] };

export function LegalPage({
  title,
  intro,
  updated,
  sections,
  footer,
}: {
  title: string;
  intro: string;
  updated?: string;
  sections: LegalSection[];
  footer?: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl px-4 pb-20 pt-12 sm:px-6">
      <h1 className="text-3xl font-extrabold sm:text-4xl">{title}</h1>
      <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">{intro}</p>
      {updated ? <p className="mt-2 text-xs text-muted-foreground">آخر تحديث: {updated}</p> : null}

      <div className="mt-8 space-y-4">
        {sections.map((section) => (
          <section key={section.heading} className="glass rounded-4xl p-6">
            <h2 className="text-lg font-bold">{section.heading}</h2>
            <div className="mt-3 space-y-2">
              {section.body.map((paragraph) => (
                <p key={paragraph} className="text-sm leading-relaxed text-muted-foreground">
                  {paragraph}
                </p>
              ))}
            </div>
          </section>
        ))}
      </div>

      {footer ? <div className="mt-8">{footer}</div> : null}

      <p className="mt-8 text-center text-xs text-muted-foreground">
        هذا نص أولي قابل للتعديل ولا يُغني عن استشارة قانونية.
      </p>
    </div>
  );
}
