import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { toggleWishlist, wishlistIdsQuery } from "@/lib/community";
import { cn } from "@/lib/utils";

export function WishlistButton({ appId, className }: { appId: string; className?: string }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const ids = useQuery({ ...wishlistIdsQuery, enabled: Boolean(user) });
  const saved = (ids.data ?? []).includes(appId);

  const mutation = useMutation({
    mutationFn: () => toggleWishlist(appId, !saved),
    onSuccess: () => {
      toast.success(saved ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة");
      void queryClient.invalidateQueries({ queryKey: ["wishlist"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  if (!user) return null;

  return (
    <Button
      variant="glass"
      size="lg"
      aria-pressed={saved}
      aria-label={saved ? "إزالة من المفضلة" : "إضافة إلى المفضلة"}
      disabled={mutation.isPending}
      onClick={() => mutation.mutate()}
      className={cn("gap-2", className)}
    >
      <Heart
        className={cn(
          "size-4 transition-transform duration-200",
          saved && "fill-current scale-110",
        )}
      />
      {saved ? "في المفضلة" : "أضف للمفضلة"}
    </Button>
  );
}
