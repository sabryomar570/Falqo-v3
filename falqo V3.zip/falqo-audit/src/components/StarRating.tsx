import { Star } from "lucide-react";

import { cn } from "@/lib/utils";

export function StarRating({
  value,
  size = 14,
  className,
}: {
  value: number;
  size?: number | undefined;
  className?: string | undefined;
}) {
  return (
    <div className={cn("flex items-center gap-0.5", className)} dir="ltr">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          style={{ width: size, height: size }}
          className={cn(
            star <= Math.round(value)
              ? "fill-warning text-warning"
              : "fill-transparent text-muted-foreground/50",
          )}
        />
      ))}
    </div>
  );
}

export function StarPicker({
  value,
  onChange,
}: {
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <div className="flex items-center gap-1" dir="ltr">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          aria-label={`${star} نجوم`}
          onClick={() => onChange(star)}
          className="cursor-pointer p-1 transition-transform duration-200 hover:scale-110"
        >
          <Star
            className={cn(
              "size-6",
              star <= value
                ? "fill-warning text-warning"
                : "fill-transparent text-muted-foreground/50",
            )}
          />
        </button>
      ))}
    </div>
  );
}
