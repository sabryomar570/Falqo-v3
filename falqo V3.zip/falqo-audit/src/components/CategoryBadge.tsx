import type { Category } from "@/lib/marketplace";
import { cn } from "@/lib/utils";

export function CategoryBadge({
  category,
  className,
}: {
  category?: Category | null | undefined;
  className?: string | undefined;
}) {
  if (!category) return null;

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-tight",
        className,
      )}
      style={{
        backgroundImage: `linear-gradient(135deg, ${category.gradient_from}1F, ${category.gradient_to}33)`,
        color: category.gradient_from,
        border: `1px solid ${category.gradient_from}2E`,
      }}
    >
      {category.name_ar}
    </span>
  );
}
