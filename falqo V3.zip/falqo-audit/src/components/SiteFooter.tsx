import { Link } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="px-4 pb-8 pt-16 sm:px-6">
      <div className="glass mx-auto max-w-6xl rounded-3xl px-6 py-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-sm">
            <span className="flex items-center gap-2 text-lg font-bold">
              <ShieldCheck className="size-5 text-primary" />
              FALQO
            </span>
            <p className="mt-2 text-sm text-muted-foreground">تطبيقات. ملفات. مجتمع.</p>
          </div>
          <div className="grid gap-6 sm:grid-cols-3">
            <nav className="flex flex-col gap-2 text-sm text-muted-foreground">
              <span className="text-xs font-bold text-foreground">المتجر</span>
              <Link to="/browse" className="hover:text-foreground">
                استكشاف التطبيقات
              </Link>
              <Link to="/publisher" className="hover:text-foreground">
                انشر تطبيقك
              </Link>
              <Link to="/wishlist" className="hover:text-foreground">
                المفضلة
              </Link>
              <Link to="/files" className="hover:text-foreground">
                الملفات
              </Link>
              <Link to="/community" className="hover:text-foreground">
                المجتمع
              </Link>
            </nav>
            <nav className="flex flex-col gap-2 text-sm text-muted-foreground">
              <span className="text-xs font-bold text-foreground">الثقة والأمان</span>
              <Link to="/trust-safety" className="hover:text-foreground">
                معايير الأمان
              </Link>
              <Link to="/community-guidelines" className="hover:text-foreground">
                إرشادات المجتمع
              </Link>
              <Link to="/privacy" className="hover:text-foreground">
                سياسة الخصوصية
              </Link>
              <Link to="/terms" className="hover:text-foreground">
                شروط الاستخدام
              </Link>
            </nav>
            <nav className="flex flex-col gap-2 text-sm text-muted-foreground">
              <span className="text-xs font-bold text-foreground">الدعم</span>
              <Link to="/help" className="hover:text-foreground">
                مركز المساعدة
              </Link>
              <Link to="/contact" className="hover:text-foreground">
                تواصل معنا
              </Link>
            </nav>
          </div>
        </div>
        <p className="mt-8 border-t hairline pt-4 text-xs text-muted-foreground">
          © {new Date().getFullYear()} FALQO. جميع الحقوق محفوظة.
        </p>
      </div>
    </footer>
  );
}
