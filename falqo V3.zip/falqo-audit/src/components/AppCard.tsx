import { Link } from "@tanstack/react-router";
import { Download } from "lucide-react";

import { CategoryBadge } from "@/components/CategoryBadge";
import { SignedImage } from "@/components/SignedImage";
import { StarRating } from "@/components/StarRating";
import { BUCKETS, formatBytes } from "@/lib/storage";
import type { AppRow } from "@/lib/marketplace";

export function AppCard({ app }: { app: AppRow }) {
  return (
    <Link
      to="/app/$slug"
      params={{ slug: app.slug }}
      className="glass lift group flex flex-col gap-4 rounded-3xl p-4"
    >
      <div className="flex items-start gap-3.5">
        <SignedImage
          bucket={BUCKETS.icons}
          path={app.icon_url}
          alt={app.name}
          className="size-16 shrink-0 rounded-2xl object-cover shadow-[var(--shadow-soft)]"
        />
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-[15px] font-semibold">{app.name}</h3>
          <p className="mt-0.5 line-clamp-2 text-[13px] leading-snug text-muted-foreground">
            {app.tagline || app.description}
          </p>
          <div className="mt-2">
            <CategoryBadge category={app.categories} />
          </div>
        </div>
      </div>

      <div className="mt-auto flex items-center justify-between border-t hairline pt-3 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <StarRating value={Number(app.rating_avg)} />
          <span>{Number(app.rating_avg).toFixed(1)}</span>
        </span>
        <span className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <Download className="size-3.5" />
            {app.downloads_count}
          </span>
          <span>{formatBytes(Number(app.file_size))}</span>
        </span>
      </div>
    </Link>
  );
}
