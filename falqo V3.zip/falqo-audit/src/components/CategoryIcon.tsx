import {
  Gamepad2,
  GraduationCap,
  ListChecks,
  MessageCircle,
  Play,
  Sparkles,
  Wrench,
  type LucideIcon,
} from "lucide-react";

import education from "@/assets/categories/education.png";
import entertainment from "@/assets/categories/entertainment.png";
import games from "@/assets/categories/games.png";
import productivity from "@/assets/categories/productivity.png";
import social from "@/assets/categories/social.png";
import tools from "@/assets/categories/tools.png";
import type { Category } from "@/lib/marketplace";
import { cn } from "@/lib/utils";

const ART: Record<string, string> = {
  games,
  productivity,
  education,
  entertainment,
  tools,
  social,
};

const GLYPHS: Record<string, LucideIcon> = {
  Gamepad2,
  ListChecks,
  GraduationCap,
  Play,
  Wrench,
  MessageCircle,
  Sparkles,
};

/** Custom illustrated icon (with gradient tile) used on large surfaces. */
export function CategoryArt({
  category,
  className,
}: {
  category: Category;
  className?: string | undefined;
}) {
  const art = ART[category.slug];
  const Glyph = GLYPHS[category.icon] ?? Sparkles;

  return (
    <span
      className={cn(
        "grid place-items-center overflow-hidden rounded-2xl shadow-[var(--shadow-soft)]",
        className,
      )}
      style={{
        backgroundImage: `linear-gradient(135deg, ${category.gradient_from}26, ${category.gradient_to}40)`,
        border: `1px solid ${category.gradient_from}2E`,
      }}
      aria-hidden
    >
      {art ? (
        <img
          src={art}
          alt=""
          loading="lazy"
          width={512}
          height={512}
          className="size-[78%] object-contain"
        />
      ) : (
        <Glyph className="size-[55%]" style={{ color: category.gradient_from }} />
      )}
    </span>
  );
}

/** Compact vector glyph for chips, lists and badges. */
export function CategoryGlyph({
  category,
  className,
}: {
  category: Category;
  className?: string | undefined;
}) {
  const Glyph = GLYPHS[category.icon] ?? Sparkles;
  return <Glyph className={cn("size-3.5", className)} aria-hidden />;
}
