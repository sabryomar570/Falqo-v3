# FALQO Fix Plan

## Phase 1 — Critical Security

1. Apply hardening migrations in staging.
2. Test `apps` publisher update policy and the `update_publisher_app` allowlist.
3. Test the approval/clean-scan trigger for every invalid transition.
4. Verify bucket privacy, object ownership, upload metadata limits, and signed URL expiry.
5. Run anonymous/user/publisher/admin RLS matrix.

## Phase 2 — Reliability

1. Add a deployed queue/cron consumer for `scan_jobs` and `file_scan_jobs`.
2. Process retries with backoff and a maximum attempt count.
3. Add a scheduled orphan-object cleanup job with a dry-run mode.
4. Add idempotency keys to scan and download operations.

## Phase 3 — Core Functionality

1. Add admin pagination and failed-scan retry controls.
2. Add shared validation schemas for topic, reply, review, report, and file metadata.
3. Add moderation and anti-spam controls for community operations.

## Phase 4 — Performance

1. Replace client-side category filtering with database filtering.
2. Add cursor pagination to apps, files, forum, reports, and dashboards.
3. Reduce broad React Query invalidations and profile N+1 lookups.
4. Fix PWA precache and verify offline navigation.

## Phase 5 — UI/UX

1. Add query-level error/retry states.
2. Add upload progress, preview, and accessible confirmation dialogs.
3. Add per-row admin pending states.
4. Run RTL mobile/tablet/desktop and accessibility checks.

## Phase 6 — Testing and Production

1. Add unit tests for validators and state transitions.
2. Add integration tests for server functions and RPCs.
3. Add E2E flows for user, publisher, admin, downloads, and community.
4. Complete monitoring, security, deployment, and rollback runbooks.
