# FALQO Security Matrix

## Role model

| Role | Expected access |
|---|---|
| Anonymous | Read only approved/clean public apps and clean public files; no writes; may request public downloads through the server function. |
| Normal user | Own profile, wishlist, reviews, reports, topics, replies, votes, and private files; no moderation or publisher state control. |
| Publisher | Normal user access plus own app submission metadata and own app/file dashboards; cannot set approval, scan verdict, featured state, counters, ownership, or publication time. |
| Admin | Moderation, review decisions, scan remediation, report resolution, and operational inspection. |

## Matrix to execute in staging

| Resource/operation | Anonymous | User | Publisher | Admin | Expected control |
|---|---:|---:|---:|---:|---|
| Read approved clean apps | Allow | Allow | Allow | Allow | RLS public-live policy |
| Read pending/rejected other apps | Deny | Deny | Deny | Allow | owner/admin policies |
| Insert app with own publisher id | Deny | Allow only if publisher flow permits | Allow | Allow | authenticated + ownership |
| Change app status | Deny | Deny | Deny | Allow | admin policy + publication trigger |
| Change scan verdict | Deny | Deny | Deny | Allow | admin/provider path |
| Change downloads counter | Deny | Deny | Deny | Service function only | no direct client update |
| Read own wishlist | Deny | Own only | Own only | Own/admin policy | RLS |
| Read own downloads | Deny | Own only | Own/own-app only | Allow | RLS |
| Read private file metadata | Deny | Owner only | Owner only | Allow | RLS |
| Download private file | Deny | Owner only | Owner only | As policy | server identity check |
| Create topic/reply/vote | Deny | Own identity only | Own identity only | Allow/moderate | ownership + locked topic |
| Resolve report | Deny | Deny | Deny | Allow | admin RLS |
| Read notifications | Deny | Own only | Own only | Own/admin policy | RLS |

## Required evidence

Run each operation with separate sessions for the four roles. Record SQL result, HTTP result, and expected/actual access in `audit/E2E_RESULTS.md`. Never use a service-role key in browser code or expose it in test output.
