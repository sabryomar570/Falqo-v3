# FALQO E2E Results

## Local verification

| Check | Result | Notes |
|---|---|---|
| `npm run lint` | PASS with 10 warnings | Warnings are existing Fast Refresh export warnings; no errors. |
| `npx tsc --noEmit` | PASS | No TypeScript errors. |
| `npm run build` | PASS | Production build completes. |
| Unit tests | PASS | Vitest: 1 file, 4 tests passed. |
| E2E browser tests | Not run | Requires configured Supabase/Auth test environment. |

## External verification required

- Auth registration/login/logout/refresh with a staging Supabase project.
- RLS matrix with anonymous, user, publisher, and admin users.
- Storage bucket privacy, object ownership, MIME/size policies, and signed URL expiry.
- VirusTotal provider submission, timeout, retry, refresh, and failure behavior.
- User → browse → search → app → download flow.
- Publisher → upload → scan → admin review → approve/reject flow.
- Community topic → reply → vote → edit/delete permissions flow.

Do not mark an external scenario as passed without a timestamped result and sanitized logs.
