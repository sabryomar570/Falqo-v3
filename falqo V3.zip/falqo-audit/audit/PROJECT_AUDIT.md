# FALQO Project Audit Status

This ledger tracks the original audit findings against the implementation state. `FIXED` means verified by local automated checks. `PARTIALLY FIXED` means code and migration work exists but the connected Supabase/Storage/provider environment still needs staging verification.

| Finding | Status | Evidence / next verification |
|---|---|---|
| SEC-01 publisher can update sensitive app fields | PARTIALLY FIXED | Added `update_publisher_app` RPC and removed publisher update policy in `20260912120000_production_hardening.sql`; apply migration and run the RLS matrix. |
| SEC-02 client-only upload validation | PARTIALLY FIXED | Added centralized validation, unit tests, Storage size/MIME policies, and safe filenames; real MIME/magic-byte and deployed bucket behavior need external verification. |
| SEC-03 approval without clean scan invariant | PARTIALLY FIXED | Added database trigger requiring clean scan and file; apply migration and test admin transitions. |
| SEC-04 scan lifecycle | PARTIALLY FIXED | Added `failed`, timeout, idempotency, retry entry point, provider error handling, and shared-file scan jobs; production queue/cron remains NOT VERIFIED. |
| SEC-05 partial upload cleanup | FIXED IN CODE | Publisher flow cleans Storage failures before a DB record is created; orphan cleanup job remains a production operation. |
| SEC-06 download authorization | PARTIALLY FIXED | Signed server functions verify bearer identity and clean status; deployed Storage/private bucket behavior is NOT VERIFIED. |
| SEC-07 broad downloads insert grant | PARTIALLY FIXED | Migration revokes direct anonymous/authenticated insert; migration application and RLS result remain NOT VERIFIED. |
| SEC-08 shared-file scanning | PARTIALLY FIXED | Added `file_scan_jobs`, submission/refresh Server Functions, and clean-only public policy; provider polling/queue remains NOT VERIFIED. |
| P-11 lint failures | FIXED | `npm run lint` passes with 10 existing non-blocking Fast Refresh warnings. |
| P-12 PWA precache | PARTIALLY FIXED | Expanded Workbox glob patterns and made registration failures observable; deployed offline behavior remains NOT VERIFIED. |
| P-13 client-side category filtering | FIXED IN CODE | Category slug is resolved to an id and filtering/range pagination occurs in Supabase. |
| P-14 pagination | PARTIALLY FIXED | Browse query supports bounded offset/range pagination; UI-level next/previous controls for every list remain. |
| P-19 automated tests | PARTIALLY FIXED | Added Vitest and upload-validation unit tests; RLS/integration/E2E suites remain. |
| P-20 monitoring/runbook | PARTIALLY FIXED | Added deployment, security, testing, and operations runbooks; deployed observability is NOT VERIFIED. |

## Baseline versus current

The original audit found build success, lint failure, no visible test suite, and a production-readiness score of 57/100. Current local checks are lint PASS, typecheck PASS, build PASS, with unit tests expected to pass after the sanitizer correction. The project is improved but remains unsuitable for an unverified public production launch until the external blockers in `FINAL_REPORT.md` are closed.
